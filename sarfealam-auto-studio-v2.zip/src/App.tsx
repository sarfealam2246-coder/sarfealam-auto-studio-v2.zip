import { useCallback, useEffect, useRef, useState } from 'react';
import { TopBar } from './components/TopBar';
import {
  DisplayViewport,
  type BroadcastSessionData,
} from './components/DisplayViewport';
import { FileDrawer } from './components/FileDrawer';
import { CodePanel, type PendingAIEditState } from './components/CodePanel';
import { SecretsPanel } from './components/SecretsPanel';
import { VaultPanel } from './components/VaultPanel';
import { CameraVisionPanel } from './components/CameraVisionPanel';
import { MemoryRulesModal } from './components/MemoryRulesModal';
import { BotMeshModal } from './components/BotMeshModal';
import { ProjectsModal } from './components/ProjectsModal';
import { AdminExportPanel } from './components/AdminExportPanel';
import { CommandCenter } from './components/CommandCenter';
import { BottomActionBar } from './components/BottomActionBar';
import { studioBus } from './services/eventBus';
import {
  countConfiguredKeys,
  detectProviderFromKey,
  getDefaultModelForProvider,
  getProviderDisplayName,
  hydrateKeyPool,
  loadSecrets,
  saveSecrets,
  syncLegacyFieldsFromKeyPool,
  testConfiguredApiKeys,
} from './services/secretsService';
import {
  fetchLiveWebResearchContext,
  shouldRunLiveWebResearch,
} from './services/liveWebResearchService';
import {
  addMemoryRuleUnique,
  loadMemoryRules,
  saveMemoryRules,
} from './services/memoryService';
import {
  advanceStage,
  parseStageNumber,
  pauseStudioPipeline,
  resumeStudioPipeline,
  setStudioPipelineStage,
  syncPipelineFromWorld,
} from './services/pipelineController';
import {
  clearKeyCooldown,
  clearProviderCooldown,
  markKeyCooldown,
  markProviderCooldown,
  routeStudioCommand,
} from './services/aiRouter';
import { executeUIActions, type UIAction } from './services/uiActuators';
import {
  geminiLiveService,
  type LiveTranscriptEvent,
} from './services/geminiLiveService';
import {
  setCloudTtsSpeed,
  speakStudioReply,
  stopStudioSpeech,
} from './services/cloudTtsService';
import { startDictation, stopDictation } from './services/dictationService';
import {
  clearAssetVaultCache,
  huntStudioAssets,
  type AssetHuntResult,
} from './services/assetHunterService';
import { cloneGitHubRepo } from './services/githubCloneService';
import { applyAIFileEdit } from './services/aiFileEditorService';
import { generatePro3DGameFiles } from './services/game3dBuilderService';
import { generateCommercialAppFiles } from './services/commercialAppBuilderService';
import { generateBroadcastScript } from './services/broadcastStudioService';
import {
  deleteDynamicSkill,
  fetchAnyApi,
  loadDynamicSkills,
  loadSubBotRuns,
  saveDynamicSkills,
  spawnSubBot,
  type DynamicSkill,
  type FetchAnyApiResult,
  type SubBotRun,
} from './services/botMeshService';
import {
  clearActiveJob,
  createActiveJob,
  loadUnfinishedJob,
  patchActiveJob,
  type ActiveStudioJob,
} from './services/jobPersistenceService';
import {
  checkAndHealGitHubRun,
  recordPreviewErrorMemory,
  type CheckAndHealGitHubRunResult,
} from './services/selfHealingService';
import { isPreviewTelemetryMessage } from './services/previewErrorSpy';
import {
  createBlankProject,
  deleteProjectById,
  getActiveProjectId,
  loadAllProjects,
  saveProjectRecord,
  setActiveProjectId,
  type StudioProjectRecord,
} from './services/projectStoreService';
import {
  detectArchitectPlanIntent,
  generateLockedStepPlan,
} from './services/jarvisArchitectService';
import {
  runBuiltInStudioBuilder,
  type BuilderStageUpdate,
} from './services/studioBuilderService';
import {
  downloadProjectZip,
  type ZipDownloadResult,
} from './services/zipExportService';
import type { AtomicPushToGitHubResult } from './services/githubExportService';
import type {
  ApiKeyProvider,
  AssetCategory,
  BotId,
  BuilderCheckpoint,
  DisplayMode,
  Language,
  LockedStepPlanItem,
  PanelId,
  PreferredBrain,
  PreviewVerifyState,
  StudioAssetItem,
  StudioMode,
  StudioSecrets,
  TargetEngine,
  UserMemoryRule,
  VirtualFile,
  VoicePersona,
  VoicePhase,
  WorldState,
} from './types/studio';

const STORAGE_KEY = 'sarfealam_autostudio_world_v1';
const VOICE_REPLY_KEY = 'sarfealam_voice_reply_enabled_v1';
const HANDS_FREE_LOOP_KEY = 'sarfealam_hands_free_loop_v1';

function isSameAssetItem(a: StudioAssetItem, b: StudioAssetItem): boolean {
  return a.id === b.id || (Boolean(a.url) && a.url === b.url);
}

function buildAssetsManifestJson(selectedAssets: StudioAssetItem[]): string {
  const categories = Array.from(new Set(selectedAssets.map((a) => a.category)));
  const payload = {
    studio: 'Sarfealam Auto-Studio',
    schemaVersion: 1,
    updatedAt: new Date().toISOString(),
    count: selectedAssets.length,
    categories:
      categories.length > 0
        ? categories
        : ['vehicles', 'characters', 'village_world', 'textures_pbr', 'audio_sfx'],
    assets: selectedAssets.map((item) => ({
      id: item.id,
      name: item.name,
      category: item.category,
      source: item.source,
      url: item.url,
      ...(item.previewUrl ? { previewUrl: item.previewUrl } : {}),
      ...(item.format ? { format: item.format } : {}),
      ...(item.license ? { license: item.license } : {}),
    })),
  };
  return `${JSON.stringify(payload, null, 2)}\n`;
}

function syncAssetsManifestFile(
  files: VirtualFile[],
  selectedAssets: StudioAssetItem[],
  now: number
): VirtualFile[] {
  const manifestPath = 'assets/manifest.json';
  const content = buildAssetsManifestJson(selectedAssets);
  const exists = files.some((f) => f.path === manifestPath);

  if (exists) {
    return files.map((f) =>
      f.path === manifestPath
        ? { ...f, content, updatedAt: now, generatedBy: 'asset' }
        : f
    );
  }

  return [
    ...files,
    {
      path: manifestPath,
      language: 'json',
      content,
      updatedAt: now,
      generatedBy: 'asset',
    },
  ];
}

function createStarterFiles(now: number): VirtualFile[] {
  return [
    {
      path: 'src/App.tsx',
      language: 'tsx',
      updatedAt: now,
      generatedBy: 'code',
      content: `import React from 'react';

export function StudioEntry() {
  return (
    <main className="min-h-screen bg-[#F3F6FB] text-[#0F172A] p-4">
      <h1 className="text-lg font-bold">Sarfealam Auto-Studio</h1>
      <p className="text-sm text-slate-500 mt-1">
        Zero-server Capacitor 6 mobile workspace ready.
      </p>
    </main>
  );
}
`,
    },
    {
      path: 'src/main.ts',
      language: 'ts',
      updatedAt: now,
      generatedBy: 'code',
      content: `export const STUDIO_CONFIG = {
  appId: 'com.sarfealam.autostudio',
  version: '0.2.0',
  runtime: 'capacitor-6',
  targetViewport: 360,
} as const;

export function bootStudio(): string {
  return \`Booted \${STUDIO_CONFIG.appId} (\${STUDIO_CONFIG.runtime})\`;
}
`,
    },
    {
      path: 'assets/manifest.json',
      language: 'json',
      updatedAt: now,
      generatedBy: 'asset',
      content: `{
  "studio": "Sarfealam Auto-Studio",
  "schemaVersion": 1,
  "packs": [],
  "categories": [
    "vehicles",
    "characters",
    "village_world",
    "textures_pbr",
    "audio_sfx"
  ]
}
`,
    },
    {
      path: 'docs/index.html',
      language: 'html',
      updatedAt: now,
      generatedBy: 'code',
      content: `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sarfealam Auto-Studio Preview</title>
  </head>
  <body>
    <div id="studio-stage">Display A Ready</div>
  </body>
</html>
`,
    },
  ];
}

function inferLanguage(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'tsx' || ext === 'ts') return ext;
  if (ext === 'jsx' || ext === 'js') return ext;
  if (ext === 'json') return 'json';
  if (ext === 'html' || ext === 'htm') return 'html';
  if (ext === 'css') return 'css';
  if (ext === 'md') return 'markdown';
  if (ext === 'gd') return 'gdscript';
  if (ext === 'dart') return 'dart';
  if (ext === 'cs') return 'csharp';
  return 'text';
}

function createInitialWorldState(): WorldState {
  const now = Date.now();
  return {
    projectName: 'Sarfealam Auto-Studio',
    language: 'en',
    mode: 'jarvis',
    targetEngine: 'auto',
    paused: false,
    liveActive: false,
    currentStage: '1. Shell',
    activePanel: 'none',
    displayMode: 'expanded',
    voicePersona: 'Aoede',
    voiceSpeed: 1.0,
    bots: {
      asset: {
        id: 'asset',
        label: 'Asset',
        status: 'idle',
        progress: 0,
        message: 'Asset bot standby for Step 4+',
        updatedAt: now,
      },
      code: {
        id: 'code',
        label: 'Code',
        status: 'ready',
        progress: 100,
        message: 'Display A, File Drawer & Code Panel active',
        updatedAt: now,
      },
      vision: {
        id: 'vision',
        label: 'Vision',
        status: 'idle',
        progress: 0,
        message: 'Camera vision standby',
        updatedAt: now,
      },
      github: {
        id: 'github',
        label: 'GitHub',
        status: 'idle',
        progress: 0,
        message: 'Repository sync standby',
        updatedAt: now,
      },
    },
    selectedAssets: [],
    files: createStarterFiles(now),
    memoryRules: loadMemoryRules(),
    messages: [
      {
        id: 'welcome-step-1',
        role: 'jarvis',
        text: 'Welcome to Sarfealam Auto-Studio. Display A Viewport, Collapsible File Drawer, and Code Editor are wired to WorldState.',
        timestamp: now,
        language: 'en',
      },
    ],
    secrets: loadSecrets(),
    lastUpdated: now,
  };
}

function loadWorldState(): WorldState {
  const fallback = createInitialWorldState();
  const persistedSecrets = loadSecrets();
  const persistedMemory = loadMemoryRules();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<WorldState>;
    const hydratedFiles =
      Array.isArray(parsed.files) && parsed.files.length > 0
        ? parsed.files
        : fallback.files;
    const hydratedMemory =
      persistedMemory.length > 0
        ? persistedMemory
        : Array.isArray(parsed.memoryRules)
          ? saveMemoryRules(parsed.memoryRules)
          : fallback.memoryRules;

    return {
      ...fallback,
      ...parsed,
      bots: {
        ...fallback.bots,
        ...(parsed.bots ?? {}),
      },
      secrets: persistedSecrets,
      selectedAssets: Array.isArray(parsed.selectedAssets)
        ? parsed.selectedAssets
        : fallback.selectedAssets,
      files: hydratedFiles,
      memoryRules: hydratedMemory,
      messages:
        Array.isArray(parsed.messages) && parsed.messages.length > 0
          ? parsed.messages
          : fallback.messages,
    };
  } catch {
    return fallback;
  }
}

function buildProjectRecordFromWorld(
  id: string,
  state: WorldState,
  updatedAt = Date.now()
): StudioProjectRecord {
  return {
    id,
    name: state.projectName || 'Sarfealam Auto-Studio',
    targetEngine: state.targetEngine,
    currentStage: state.currentStage,
    files: state.files,
    selectedAssets: state.selectedAssets,
    messages: state.messages,
    updatedAt,
  };
}

function pickEntryFilePath(files: VirtualFile[]): string | null {
  if (files.length === 0) return null;
  const rootIndex = files.find((f) => f.path.toLowerCase() === 'index.html');
  const docsIndex = files.find((f) => f.path.toLowerCase() === 'docs/index.html');
  const entry =
    rootIndex && docsIndex
      ? rootIndex.updatedAt >= docsIndex.updatedAt
        ? rootIndex
        : docsIndex
      : rootIndex ??
        docsIndex ??
        files.find((f) => f.path.toLowerCase().endsWith('.html')) ??
        files[0];
  return entry?.path ?? null;
}

export default function App() {
  const [world, setWorld] = useState<WorldState>(() => ({
    ...loadWorldState(),
    liveActive: false,
  }));
  const [activeProjectId, setActiveProjectIdState] = useState<string>(
    () => getActiveProjectId() || 'proj-default'
  );
  const [projects, setProjects] = useState<StudioProjectRecord[]>(() => [
    buildProjectRecordFromWorld(
      getActiveProjectId() || 'proj-default',
      world,
      world.lastUpdated
    ),
  ]);
  const [projectsModalOpen, setProjectsModalOpen] = useState(false);
  const [activeFilePath, setActiveFilePath] = useState<string | null>(
    () => world.files[0]?.path ?? null
  );
  const [isThinking, setIsThinking] = useState(false);
  const [liveConnectionLabel, setLiveConnectionLabel] = useState<string>('JARVIS · Ready');
  const [voicePhase, setVoicePhase] = useState<VoicePhase>('idle');
  const [liveModel, setLiveModel] = useState<string | null>(null);
  const [voiceReplyEnabled, setVoiceReplyEnabled] = useState<boolean>(() => {
    try {
      const saved = window.localStorage.getItem(VOICE_REPLY_KEY);
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });
  const [handsFreeLoop, setHandsFreeLoop] = useState<boolean>(() => {
    try {
      return window.localStorage.getItem(HANDS_FREE_LOOP_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [isDictating, setIsDictating] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isCloudSpeaking, setIsCloudSpeaking] = useState(false);
  const [memoryModalOpen, setMemoryModalOpen] = useState(false);
  const [vaultQuery, setVaultQuery] = useState('');
  const [vaultCategories, setVaultCategories] = useState<AssetCategory[]>([]);
  const [isHuntingAssets, setIsHuntingAssets] = useState(false);
  const [vaultResult, setVaultResult] = useState<AssetHuntResult | null>(null);
  const [candidateAssets, setCandidateAssets] = useState<StudioAssetItem[]>([]);
  const [isCloningRepo, setIsCloningRepo] = useState(false);
  const [cloneNotice, setCloneNotice] = useState<{ ok: boolean; text: string } | null>(
    null
  );
  const [pendingAIEdit, setPendingAIEdit] = useState<PendingAIEditState | null>(null);
  const [isAIEditing, setIsAIEditing] = useState(false);
  const [aiEditError, setAiEditError] = useState<string | null>(null);
  const [queuedBuilderPrompt, setQueuedBuilderPrompt] = useState<string | null>(null);
  const [isBuildingStep, setIsBuildingStep] = useState(false);
  const [builderStage, setBuilderStage] = useState<BuilderStageUpdate | null>(null);
  const [builderStageTrail, setBuilderStageTrail] = useState<string[]>([]);
  const [builderResultNote, setBuilderResultNote] = useState<{
    ok: boolean;
    text: string;
  } | null>(null);
  const [builderCheckpoints, setBuilderCheckpoints] = useState<BuilderCheckpoint[]>([]);
  const [previewVerifyState, setPreviewVerifyState] = useState<PreviewVerifyState>({
    status: 'idle',
    attempt: 0,
    maxAttempts: 2,
    message: '',
  });
  const [isBuilding3DGame, setIsBuilding3DGame] = useState(false);
  const [isBuildingCommercialApp, setIsBuildingCommercialApp] = useState(false);
  const [isCreatingBroadcast, setIsCreatingBroadcast] = useState(false);
  const [broadcastSession, setBroadcastSession] =
    useState<BroadcastSessionData | null>(null);
  const [botMeshModalOpen, setBotMeshModalOpen] = useState(false);
  const [dynamicSkills, setDynamicSkills] = useState<DynamicSkill[]>(() =>
    loadDynamicSkills()
  );
  const [subBotRuns, setSubBotRuns] = useState<SubBotRun[]>(() =>
    loadSubBotRuns()
  );
  const [isSpawningSubBot, setIsSpawningSubBot] = useState(false);
  const [isFetchingApi, setIsFetchingApi] = useState(false);
  const [lastApiResult, setLastApiResult] = useState<FetchAnyApiResult | null>(
    null
  );
  const [recoverableJob, setRecoverableJob] = useState<ActiveStudioJob | null>(
    () => loadUnfinishedJob()
  );
  const [isAutoResuming, setIsAutoResuming] = useState(false);

  const worldRef = useRef<WorldState>(world);
  const activeProjectIdRef = useRef<string>(activeProjectId);
  const projectsRef = useRef<StudioProjectRecord[]>(projects);
  const projectsHydratedRef = useRef<boolean>(false);
  const candidateAssetsRef = useRef<StudioAssetItem[]>(candidateAssets);
  const queuedBuilderPromptRef = useRef<string | null>(queuedBuilderPrompt);
  const awaitingPreviewVerifyRef = useRef<{
    active: boolean;
    buildCompletedAt: number;
    attempt: number;
    originalPrompt: string;
    healingInFlight: boolean;
  }>({
    active: false,
    buildCompletedAt: 0,
    attempt: 0,
    originalPrompt: '',
    healingInFlight: false,
  });
  const runBuilderOrchestratorRef = useRef<(prompt: string) => void>(() => {});
  const huntSeqRef = useRef<number>(0);
  const voiceReplyRef = useRef<boolean>(voiceReplyEnabled);
  const handsFreeLoopRef = useRef<boolean>(handsFreeLoop);
  const isThinkingRef = useRef<boolean>(isThinking);
  const lastInputWasVoiceRef = useRef<boolean>(false);
  const speechStoppedManuallyRef = useRef<boolean>(false);
  const handsFreeRearmTimerRef = useRef<number | null>(null);
  const prevPausedRef = useRef<boolean>(world.paused);
  const liveUserMsgIdRef = useRef<string | null>(null);
  const liveAssistantMsgIdRef = useRef<string | null>(null);
  const livePendingActionLabelsRef = useRef<string[]>([]);
  const isTestingApisRef = useRef<boolean>(false);

  useEffect(() => {
    worldRef.current = world;
    syncPipelineFromWorld(world.currentStage, world.paused);
  }, [world]);

  useEffect(() => {
    activeProjectIdRef.current = activeProjectId;
  }, [activeProjectId]);

  useEffect(() => {
    projectsRef.current = projects;
  }, [projects]);

  // Hydrate Multi-Project IndexedDB VFS on startup (keeping secrets/memoryRules/skills global)
  useEffect(() => {
    let cancelled = false;

    void loadAllProjects().then(async (loaded) => {
      if (cancelled) return;

      if (loaded.length > 0) {
        const savedId = getActiveProjectId();
        const target =
          loaded.find((p) => p.id === savedId) ?? loaded[0];

        setProjects(loaded);
        setActiveProjectIdState(target.id);
        setActiveProjectId(target.id);
        setWorld((prev) => ({
          ...prev,
          projectName: target.name,
          targetEngine: target.targetEngine,
          currentStage: target.currentStage,
          files: target.files.length > 0 ? target.files : prev.files,
          selectedAssets: target.selectedAssets,
          messages: target.messages.length > 0 ? target.messages : prev.messages,
          lastUpdated: target.updatedAt,
        }));
        setActiveFilePath(pickEntryFilePath(target.files));
      } else {
        const initialRecord = buildProjectRecordFromWorld(
          activeProjectIdRef.current,
          worldRef.current,
          worldRef.current.lastUpdated || Date.now()
        );
        await saveProjectRecord(initialRecord);
        if (cancelled) return;
        setActiveProjectId(initialRecord.id);
        setProjects([initialRecord]);
      }

      projectsHydratedRef.current = true;
    });

    return () => {
      cancelled = true;
    };
  }, []);

  // Debounced IndexedDB VFS persistence for the active project
  useEffect(() => {
    if (!projectsHydratedRef.current) return;

    const timerId = window.setTimeout(() => {
      const id = activeProjectIdRef.current;
      const record = buildProjectRecordFromWorld(id, worldRef.current, Date.now());
      void saveProjectRecord(record);
      setProjects((prev) => {
        const others = prev.filter((p) => p.id !== id);
        return [record, ...others].sort((a, b) => b.updatedAt - a.updatedAt);
      });
    }, 250);

    return () => window.clearTimeout(timerId);
  }, [
    activeProjectId,
    world.projectName,
    world.targetEngine,
    world.currentStage,
    world.files,
    world.selectedAssets,
    world.messages,
  ]);

  useEffect(() => {
    candidateAssetsRef.current = candidateAssets;
  }, [candidateAssets]);

  // Log a crisp system status chip whenever paused toggles (button, text, or Live Voice)
  useEffect(() => {
    if (prevPausedRef.current === world.paused) return;
    prevPausedRef.current = world.paused;

    const stageNum = parseStageNumber(world.currentStage);
    const now = Date.now();
    patchActiveJob({
      paused: world.paused,
      stage: world.currentStage,
      status: world.paused ? 'paused' : 'building',
    });
    const chipText = world.paused
      ? world.language === 'hi'
        ? `स्टेज ${stageNum} पर रुका हुआ — इंस्पेक्ट मोड (वॉइस लाइव है)`
        : `Paused at Stage ${stageNum} — Inspect Mode (Voice stays live)`
      : world.language === 'hi'
        ? `स्टेज ${stageNum} से जारी हुआ`
        : `Resumed at Stage ${stageNum}`;

    setWorld((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          id: `pipe-${world.paused ? 'pause' : 'resume'}-${now}`,
          role: 'system',
          text: chipText,
          timestamp: now,
        },
      ],
      lastUpdated: now,
    }));
  }, [world.paused, world.currentStage, world.language]);

  useEffect(() => {
    voiceReplyRef.current = voiceReplyEnabled;
    try {
      window.localStorage.setItem(VOICE_REPLY_KEY, String(voiceReplyEnabled));
    } catch {
      // ignore storage errors
    }
  }, [voiceReplyEnabled]);

  useEffect(() => {
    handsFreeLoopRef.current = handsFreeLoop;
    try {
      window.localStorage.setItem(HANDS_FREE_LOOP_KEY, String(handsFreeLoop));
    } catch {
      // ignore storage errors
    }
  }, [handsFreeLoop]);

  useEffect(() => {
    isThinkingRef.current = isThinking;
  }, [isThinking]);

  // Clean up Live WebSocket, Cloud TTS, Hands-Free timer, and Dictation on unmount
  useEffect(() => {
    return () => {
      if (handsFreeRearmTimerRef.current !== null) {
        window.clearTimeout(handsFreeRearmTimerRef.current);
        handsFreeRearmTimerRef.current = null;
      }
      geminiLiveService.disconnect();
      stopStudioSpeech();
      stopDictation();
    };
  }, []);

  // Keep activeFilePath valid whenever world.files changes
  useEffect(() => {
    if (world.files.length === 0) {
      if (activeFilePath !== null) setActiveFilePath(null);
      return;
    }
    if (!activeFilePath || !world.files.some((f) => f.path === activeFilePath)) {
      setActiveFilePath(world.files[0].path);
    }
  }, [world.files, activeFilePath]);

  // Persist WorldState to localStorage cleanly
  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(world));
    } catch {
      // Ignore storage quota errors gracefully
    }
  }, [world]);

  // Subscribe to typed studioBus events
  useEffect(() => {
    const unsubBot = studioBus.on('bot:progress', ({ botId, status, progress, message }) => {
      setWorld((prev) => ({
        ...prev,
        bots: {
          ...prev.bots,
          [botId]: {
            ...prev.bots[botId],
            status,
            progress,
            message,
            updatedAt: Date.now(),
          },
        },
        lastUpdated: Date.now(),
      }));
    });

    const unsubPanel = studioBus.on('ui:panel', ({ panel }) => {
      setWorld((prev) => ({
        ...prev,
        activePanel: panel,
        lastUpdated: Date.now(),
      }));
    });

    const unsubVoice = studioBus.on(
      'voice:state',
      ({ active, phase, model, persona, speed }) => {
        const nextPhase: VoicePhase = phase ?? (active ? 'listening' : 'idle');
        setVoicePhase(nextPhase);
        setIsCloudSpeaking(!active && nextPhase === 'speaking');

        if (model !== undefined) {
          setLiveModel(model);
        } else if (!active) {
          setLiveModel(null);
        }
        setWorld((prev) => ({
          ...prev,
          liveActive: active,
          voicePersona: persona ?? prev.voicePersona,
          voiceSpeed: speed ?? prev.voiceSpeed,
          lastUpdated: Date.now(),
        }));
      }
    );

    const unsubWorld = studioBus.on('world:update', ({ patch }) => {
      setWorld((prev) => ({
        ...prev,
        ...patch,
        lastUpdated: Date.now(),
      }));
    });

    return () => {
      unsubBot();
      unsubPanel();
      unsubVoice();
      unsubWorld();
    };
  }, []);

  const handleLanguageChange = useCallback((language: Language) => {
    studioBus.emit('world:update', { patch: { language }, source: 'topbar' });
  }, []);

  const handleModeChange = useCallback((mode: StudioMode) => {
    studioBus.emit('world:update', { patch: { mode }, source: 'topbar' });
  }, []);

  const handleEngineChange = useCallback((targetEngine: TargetEngine) => {
    studioBus.emit('world:update', { patch: { targetEngine }, source: 'topbar' });
  }, []);

  const handleDisplayModeChange = useCallback((displayMode: DisplayMode) => {
    studioBus.emit('world:update', { patch: { displayMode }, source: 'display-viewport' });
  }, []);

  const handleStageChange = useCallback((currentStage: string) => {
    const stageNum = parseStageNumber(currentStage);
    setStudioPipelineStage(stageNum);
  }, []);

  const handleAdvanceStage = useCallback(() => {
    void advanceStage(worldRef.current.currentStage);
  }, []);

  const handleSelectPanel = useCallback((panel: PanelId) => {
    studioBus.emit('ui:panel', { panel });
  }, []);

  const handleSelectFileAndOpenCode = useCallback((path: string) => {
    setActiveFilePath(path);
    studioBus.emit('ui:panel', { panel: 'code' });
  }, []);

  const handleCreateFile = useCallback(
    (path: string) => {
      const now = Date.now();
      const lang = inferLanguage(path);
      const newFile: VirtualFile = {
        path,
        language: lang,
        updatedAt: now,
        generatedBy: 'user',
        content:
          lang === 'json'
            ? '{\n  "name": "new-config"\n}\n'
            : lang === 'html'
              ? '<!doctype html>\n<html lang="en">\n  <body></body>\n</html>\n'
              : `// ${path}\nexport {};\n`,
      };
      studioBus.emit('world:update', {
        patch: { files: [...world.files, newFile] },
        source: 'file-drawer',
      });
      setActiveFilePath(path);
      studioBus.emit('ui:panel', { panel: 'code' });
    },
    [world.files]
  );

  const handleDeleteFile = useCallback(
    (path: string) => {
      const nextFiles = world.files.filter((f) => f.path !== path);
      studioBus.emit('world:update', {
        patch: { files: nextFiles },
        source: 'file-drawer',
      });
      if (activeFilePath === path) {
        setActiveFilePath(nextFiles[0]?.path ?? null);
      }
    },
    [world.files, activeFilePath]
  );

  const handleSaveFile = useCallback(
    (path: string, content: string) => {
      const now = Date.now();
      const nextFiles = world.files.map((f) =>
        f.path === path ? { ...f, content, updatedAt: now } : f
      );
      studioBus.emit('world:update', {
        patch: { files: nextFiles },
        source: 'code-panel',
      });
      studioBus.emit('bot:progress', {
        botId: 'code',
        status: 'ready',
        progress: 100,
        message: `Saved ${path}`,
      });
    },
    [world.files]
  );

  const handleSaveSecrets = useCallback(
    (updated: StudioSecrets) => {
      const prevVaultUrl = worldRef.current.secrets.assetVaultUrl;
      const saved = saveSecrets(updated);
      clearProviderCooldown();
      if (saved.assetVaultUrl !== prevVaultUrl) {
        clearAssetVaultCache();
      }
      const count = countConfiguredKeys(saved);
      const now = Date.now();
      const note = {
        id: `sec-${now}`,
        role: 'system' as const,
        text:
          world.language === 'hi'
            ? `वॉल्ट सुरक्षित रूप से सहेजा गया (${count} कुंजियाँ लॉक की गईं)।`
            : `Secrets vault locked locally (${count} key${count === 1 ? '' : 's'} configured).`,
        timestamp: now,
      };
      studioBus.emit('world:update', {
        patch: {
          secrets: saved,
          messages: [...world.messages, note],
        },
        source: 'secrets-panel',
      });
    },
    [world.language, world.messages]
  );

  const handlePreferredBrainChange = useCallback((preferredBrain: PreferredBrain) => {
    const saved = saveSecrets({
      ...worldRef.current.secrets,
      preferredBrain,
    });
    studioBus.emit('world:update', {
      patch: { secrets: saved },
      source: 'brain-switcher',
    });
  }, []);

  const handleTestApis = useCallback(async () => {
    if (isTestingApisRef.current) return;
    isTestingApisRef.current = true;

    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'working',
      progress: 50,
      message: 'Testing Smart Key Pool in parallel...',
    });

    try {
      const current = worldRef.current;
      const report = await testConfiguredApiKeys(current.secrets);
      const now = Date.now();

      const existingPool = hydrateKeyPool(
        current.secrets,
        Array.isArray(current.secrets.keyPool)
      );
      const nextPool = existingPool.map((entry) => {
        const res = report.byEntryId[entry.id];
        if (!res) return entry;
        if (res.ok) {
          clearKeyCooldown(entry.id);
          clearProviderCooldown(entry.provider);
          return {
            ...entry,
            statusLabel:
              res.modelCount > 0 ? `Active ✓ · ${res.modelCount}` : 'Active ✓',
            cooldownUntil: undefined,
          };
        }
        if (/(503|429|Timeout)/i.test(res.statusLabel)) {
          markKeyCooldown(entry.id);
          return {
            ...entry,
            statusLabel: res.statusLabel,
            cooldownUntil: now + 60_000,
          };
        }
        return {
          ...entry,
          statusLabel: res.statusLabel,
          cooldownUntil: undefined,
        };
      });

      const enabledByProvider = new Map<ApiKeyProvider, typeof nextPool>();
      for (const e of nextPool) {
        if (!e.enabled) continue;
        const arr = enabledByProvider.get(e.provider) ?? [];
        arr.push(e);
        enabledByProvider.set(e.provider, arr);
      }
      enabledByProvider.forEach((entries, prov) => {
        if (entries.every((e) => (e.cooldownUntil ?? 0) > now)) {
          markProviderCooldown(prov);
        }
      });

      const updatedSecrets = saveSecrets(
        syncLegacyFieldsFromKeyPool(
          {
            ...current.secrets,
            keyPool: nextPool,
            nvidiaModelsList: report.nvidiaModelsList,
          },
          nextPool
        )
      );

      const summaryText =
        report.totalCount === 0
          ? current.language === 'hi'
            ? 'Live API Check: अभी कोई AI API key सेव नहीं है। नीचे "Secrets" से Gemini, NVIDIA, Groq, Cloudflare, OpenRouter या Cohere जोड़ें।'
            : 'Live API Check: No AI API keys configured yet. Add Gemini, NVIDIA, Groq, Cloudflare, OpenRouter, or Cohere in Secrets.'
          : [
              `Live API Check (${report.activeCount}/${report.totalCount} Active):`,
              ...report.entries.map((item) =>
                item.ok
                  ? `• ${item.label}: Active ✓${item.modelCount > 0 ? ` (${item.modelCount} models)` : ''} · ${item.latencyMs}ms`
                  : `• ${item.label}: ${item.statusLabel} · ${item.latencyMs}ms`
              ),
            ].join('\n');

      setWorld((prev) => ({
        ...prev,
        secrets: updatedSecrets,
        messages: [
          ...prev.messages,
          {
            id: `api-test-${now}`,
            role: 'jarvis',
            text: summaryText,
            timestamp: now,
            language: prev.language,
            botRef: 'code',
            providerUsed: 'API Tester',
          },
        ],
        lastUpdated: now,
      }));

      studioBus.emit('bot:progress', {
        botId: 'code',
        status: 'ready',
        progress: 100,
        message:
          report.totalCount === 0
            ? 'API Check: 0 keys set'
            : `API Check: ${report.activeCount}/${report.totalCount} active`,
      });
    } finally {
      isTestingApisRef.current = false;
    }
  }, []);

  const handleSearchAssets = useCallback(
    (query: string, categories?: AssetCategory[]) => {
      const seq = ++huntSeqRef.current;
      const cleanQuery = query.trim();
      setVaultQuery(cleanQuery);
      if (categories && categories.length > 0) {
        setVaultCategories(categories);
      }
      setIsHuntingAssets(true);

      void huntStudioAssets({
        query: cleanQuery,
        categories,
        assetVaultUrl: worldRef.current.secrets.assetVaultUrl,
      })
        .then((res) => {
          if (huntSeqRef.current !== seq) return;
          setVaultResult(res);
          setCandidateAssets(res.items);
        })
        .finally(() => {
          if (huntSeqRef.current === seq) {
            setIsHuntingAssets(false);
          }
        });
    },
    []
  );

  const commitSelectedAssets = useCallback(
    (nextSelected: StudioAssetItem[], botMessage: string) => {
      const now = Date.now();
      setWorld((prev) => ({
        ...prev,
        selectedAssets: nextSelected,
        files: syncAssetsManifestFile(prev.files, nextSelected, now),
        lastUpdated: now,
      }));
      studioBus.emit('bot:progress', {
        botId: 'asset',
        status: 'ready',
        progress: 100,
        message: botMessage,
      });
    },
    []
  );

  const handleKeepAsset = useCallback(
    (item: StudioAssetItem) => {
      const current = worldRef.current.selectedAssets;
      const alreadyKept = current.some((sel) => isSameAssetItem(sel, item));
      const nextSelected = alreadyKept
        ? current
        : [...current, { ...item, selected: true, addedAt: Date.now() }];
      commitSelectedAssets(
        nextSelected,
        `Kept "${item.name}" (${nextSelected.length} in manifest)`
      );
    },
    [commitSelectedAssets]
  );

  const handleRemoveSelectedAsset = useCallback(
    (item: StudioAssetItem) => {
      const current = worldRef.current.selectedAssets;
      const nextSelected = current.filter((sel) => !isSameAssetItem(sel, item));
      commitSelectedAssets(
        nextSelected,
        `Removed "${item.name}" (${nextSelected.length} in manifest)`
      );
    },
    [commitSelectedAssets]
  );

  const handleRejectAsset = useCallback(
    (item: StudioAssetItem) => {
      setCandidateAssets((prev) => prev.filter((c) => !isSameAssetItem(c, item)));
      const current = worldRef.current.selectedAssets;
      if (current.some((sel) => isSameAssetItem(sel, item))) {
        const nextSelected = current.filter((sel) => !isSameAssetItem(sel, item));
        commitSelectedAssets(
          nextSelected,
          `Rejected "${item.name}" (${nextSelected.length} in manifest)`
        );
      } else {
        studioBus.emit('bot:progress', {
          botId: 'asset',
          status: 'ready',
          progress: 100,
          message: `Rejected "${item.name}"`,
        });
      }
    },
    [commitSelectedAssets]
  );

  const handleSelectAssetCommand = useCallback(
    (target: string, decision: 'keep' | 'reject'): string => {
      const candidates = candidateAssetsRef.current;
      const selected = worldRef.current.selectedAssets;
      const rawLow = target.trim().toLowerCase().replace(/^#/, '');
      const ordinalLookup: Record<string, string> = {
        first: '1',
        '1st': '1',
        one: '1',
        pehla: '1',
        pehle: '1',
        पहला: '1',
        second: '2',
        '2nd': '2',
        two: '2',
        dusra: '2',
        doosra: '2',
        दूसरा: '2',
        third: '3',
        '3rd': '3',
        three: '3',
        teesra: '3',
        tisra: '3',
        तीसरा: '3',
        fourth: '4',
        '4th': '4',
        four: '4',
        chautha: '4',
        fifth: '5',
        '5th': '5',
        five: '5',
        paanchwa: '5',
        last: 'last',
        aakhri: 'last',
        all: 'all',
        sab: 'all',
        sabhi: 'all',
        saare: 'all',
        सब: 'all',
      };
      const low = ordinalLookup[rawLow] ?? rawLow;

      if (low === 'all') {
        if (decision === 'keep') {
          if (candidates.length === 0) return 'No candidates to keep';
          const merged = [...selected];
          for (const item of candidates) {
            if (!merged.some((sel) => isSameAssetItem(sel, item))) {
              merged.push({ ...item, selected: true, addedAt: Date.now() });
            }
          }
          commitSelectedAssets(
            merged,
            `Kept all ${candidates.length} assets (${merged.length} in manifest)`
          );
          return `Kept All (${candidates.length})`;
        } else {
          if (candidates.length > 0) {
            const count = candidates.length;
            setCandidateAssets([]);
            studioBus.emit('bot:progress', {
              botId: 'asset',
              status: 'ready',
              progress: 100,
              message: `Cleared ${count} candidate assets`,
            });
            return `Rejected All (${count})`;
          }
          if (selected.length > 0) {
            commitSelectedAssets([], 'Cleared selected assets');
            return 'Cleared Selected Assets';
          }
          return 'No assets to reject';
        }
      }

      const pool =
        candidates.length > 0
          ? candidates
          : decision === 'reject'
            ? selected
            : [];

      if (pool.length === 0) {
        return decision === 'keep'
          ? 'No candidates available to keep'
          : 'No assets available to reject';
      }

      let matchedItem: StudioAssetItem | undefined;
      if (low === 'last') {
        matchedItem = pool[pool.length - 1];
      } else if (/^\d+$/.test(low)) {
        const idx = Number(low) - 1;
        if (idx >= 0 && idx < pool.length) {
          matchedItem = pool[idx];
        }
      } else {
        matchedItem = pool.find(
          (item) =>
            item.name.toLowerCase().includes(low) ||
            item.category.toLowerCase().includes(low) ||
            (item.tags ?? []).some((t) => t.toLowerCase().includes(low))
        );
      }

      if (!matchedItem) {
        return `Asset "${target}" not found`;
      }

      if (decision === 'keep') {
        handleKeepAsset(matchedItem);
        return `Kept · ${matchedItem.name}`;
      } else {
        handleRejectAsset(matchedItem);
        return `Rejected · ${matchedItem.name}`;
      }
    },
    [commitSelectedAssets, handleKeepAsset, handleRejectAsset]
  );

  const handleCloneRepo = useCallback(async (repoInput: string) => {
    const trimmed = repoInput.trim();
    if (!trimmed) return;

    setIsCloningRepo(true);
    setCloneNotice(null);

    try {
      const res = await cloneGitHubRepo(
        trimmed,
        worldRef.current.secrets.githubToken
      );

      if (!res.ok) {
        const errText = res.error || 'Unable to clone GitHub repository.';
        setCloneNotice({ ok: false, text: errText });
        const now = Date.now();
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `gh-err-${now}`,
              role: 'system',
              text: `GitHub Clone failed (${res.repo || trimmed}): ${errText}`,
              timestamp: now,
              botRef: 'github',
            },
          ],
          lastUpdated: now,
        }));
        return;
      }

      const now = Date.now();
      const nextFiles =
        worldRef.current.selectedAssets.length > 0
          ? syncAssetsManifestFile(
              res.files,
              worldRef.current.selectedAssets,
              now
            )
          : res.files;

      const entryFile =
        nextFiles.find((f) => f.path.toLowerCase() === 'docs/index.html') ??
        nextFiles.find((f) => f.path.toLowerCase() === 'index.html') ??
        nextFiles.find((f) => f.path.toLowerCase().endsWith('.html')) ??
        nextFiles[0];

      setPendingAIEdit(null);
      setAiEditError(null);
      setActiveFilePath(entryFile?.path ?? null);

      const okMsg =
        worldRef.current.language === 'hi'
          ? `${res.repo}@${res.branch} से ${res.files.length} फ़ाइलें क्लोन की गईं।`
          : `Cloned ${res.files.length} files from ${res.repo}@${res.branch}.`;
      setCloneNotice({ ok: true, text: okMsg });

      setWorld((prev) => ({
        ...prev,
        projectName: res.repo,
        files: nextFiles,
        displayMode: 'expanded',
        messages: [
          ...prev.messages,
          {
            id: `gh-ok-${now}`,
            role: 'system',
            text: okMsg,
            timestamp: now,
            botRef: 'github',
          },
        ],
        lastUpdated: now,
      }));
    } finally {
      setIsCloningRepo(false);
    }
  }, []);

  const handleBuild3DGame = useCallback(async (themeOverride?: string) => {
    if (isBuilding3DGame) return;
    setIsBuilding3DGame(true);

    try {
      const current = worldRef.current;
      const theme = themeOverride?.trim() || 'Village 3D Drive';
      const targetRepo =
        current.secrets.targetRepo?.trim() ||
        (current.secrets.githubOwner && current.secrets.githubRepo
          ? `${current.secrets.githubOwner}/${current.secrets.githubRepo}`
          : '');
      createActiveJob({
        title: `3D Game Build (${theme})`,
        stage: current.currentStage,
        paused: current.paused,
        targetRepo,
        status: 'building',
      });

      const generated = await generatePro3DGameFiles({
        title:
          current.projectName && current.projectName !== 'Sarfealam Auto-Studio'
            ? current.projectName
            : `${theme} 3D`,
        theme,
        selectedAssets: current.selectedAssets,
        appsSupabaseUrl: current.secrets.appsSupabaseUrl,
        appsSupabaseAnonKey: current.secrets.appsSupabaseAnonKey,
      });

      const stageResult = await advanceStage(worldRef.current.currentStage);
      const now = Date.now();

      setWorld((prev) => {
        const mergedFiles = [...prev.files];
        for (const genFile of generated.files) {
          const existingIdx = mergedFiles.findIndex(
            (f) => f.path.toLowerCase() === genFile.path.toLowerCase()
          );
          if (existingIdx >= 0) {
            mergedFiles[existingIdx] = genFile;
          } else {
            mergedFiles.unshift(genFile);
          }
        }

        const msgText =
          prev.language === 'hi'
            ? `प्रो 3D Three.js गेम (${generated.theme}) तैयार है और Display A में लॉन्च हो गया (${generated.injectedAssetsCount} वॉल्ट एसेट जुड़े, स्टेज ${stageResult.stageLabel})।`
            : `Pro 3D Three.js game (${generated.theme}) built and launched in Display A (${generated.injectedAssetsCount} Vault assets wired, Stage ${stageResult.stageLabel}).`;

        return {
          ...prev,
          files: mergedFiles,
          currentStage: stageResult.stageLabel,
          displayMode: 'expanded',
          activePanel: 'none',
          messages: [
            ...prev.messages,
            {
              id: `game3d-${now}`,
              role: 'system',
              text: msgText,
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        };
      });

      setActiveFilePath(generated.entryPath);
      patchActiveJob({
        stage: stageResult.stageLabel,
        paused: false,
        status: 'completed',
      });
      setRecoverableJob(null);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      const now = Date.now();
      const errText =
        err instanceof Error ? err.message : 'Unable to generate 3D game runtime.';
      patchActiveJob({ status: 'failed' });
      studioBus.emit('bot:progress', {
        botId: 'code',
        status: 'error',
        progress: 0,
        message: errText,
      });
      setWorld((prev) => ({
        ...prev,
        messages: [
          ...prev.messages,
          {
            id: `game3d-err-${now}`,
            role: 'system',
            text: `3D Game Builder error: ${errText}`,
            timestamp: now,
            botRef: 'code',
          },
        ],
        lastUpdated: now,
      }));
    } finally {
      setIsBuilding3DGame(false);
    }
  }, [isBuilding3DGame]);

  const handleBuildCommercialApp = useCallback(
    async (categoryOverride?: string, promptOverride?: string) => {
      if (isBuildingCommercialApp) return;
      setIsBuildingCommercialApp(true);

      try {
        const current = worldRef.current;
        const targetRepo =
          current.secrets.targetRepo?.trim() ||
          (current.secrets.githubOwner && current.secrets.githubRepo
            ? `${current.secrets.githubOwner}/${current.secrets.githubRepo}`
            : '');
        createActiveJob({
          title: `Commercial App (${categoryOverride || 'auto'})`,
          stage: current.currentStage,
          paused: current.paused,
          targetRepo,
          status: 'building',
        });

        const generated = await generateCommercialAppFiles({
          category: categoryOverride,
          prompt: promptOverride,
          selectedAssets: current.selectedAssets,
          secrets: current.secrets,
          memoryRules: current.memoryRules,
        });

        const stageResult = await advanceStage(worldRef.current.currentStage);
        const now = Date.now();

        setWorld((prev) => {
          const mergedFiles = [...prev.files];
          for (const genFile of generated.files) {
            const existingIdx = mergedFiles.findIndex(
              (f) => f.path.toLowerCase() === genFile.path.toLowerCase()
            );
            if (existingIdx >= 0) {
              mergedFiles[existingIdx] = genFile;
            } else {
              mergedFiles.unshift(genFile);
            }
          }

          const msgText =
            prev.language === 'hi'
              ? `कमर्शियल ऐप "${generated.appName}" (${generated.category}) तैयार है और Display A में लाइव लॉन्च हो गया (${generated.injectedAssetsCount} एसेट्स, ${
                  generated.supabaseWired ? 'Apps Supabase जुड़ा' : 'लोकल डेमो मोड'
                })।`
              : `Commercial app "${generated.appName}" (${generated.category}) built and launched in Display A (${generated.injectedAssetsCount} assets, ${
                  generated.supabaseWired ? 'Apps Supabase wired' : 'Local Demo Mode'
                }).`;

          return {
            ...prev,
            projectName: generated.appName,
            files: mergedFiles,
            currentStage: stageResult.stageLabel,
            displayMode: 'expanded',
            activePanel: 'none',
            messages: [
              ...prev.messages,
              {
                id: `commapp-${now}`,
                role: 'system',
                text: msgText,
                timestamp: now,
                botRef: 'code',
              },
            ],
            lastUpdated: now,
          };
        });

        setActiveFilePath(generated.entryPath);
        patchActiveJob({
          title: `Commercial App (${generated.appName})`,
          stage: stageResult.stageLabel,
          paused: false,
          status: 'completed',
        });
        setRecoverableJob(null);
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        const now = Date.now();
        const errText =
          err instanceof Error
            ? err.message
            : 'Unable to generate commercial app.';
        patchActiveJob({ status: 'failed' });
        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'error',
          progress: 0,
          message: errText,
        });
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `commapp-err-${now}`,
              role: 'system',
              text: `Commercial App Builder error: ${errText}`,
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsBuildingCommercialApp(false);
      }
    },
    [isBuildingCommercialApp]
  );

  const handleCreateBroadcast = useCallback(
    async (topicOverride?: string) => {
      if (isCreatingBroadcast) return;
      setIsCreatingBroadcast(true);

      try {
        const current = worldRef.current;
        const topic =
          topicOverride?.trim() ||
          (current.projectName && current.projectName !== 'Sarfealam Auto-Studio'
            ? current.projectName
            : 'Sarfealam Auto-Studio Launch');

        const script = await generateBroadcastScript({
          topic,
          language: current.language,
          secrets: current.secrets,
          memoryRules: current.memoryRules,
        });

        const now = Date.now();
        setBroadcastSession({
          id: now,
          topic: script.topic,
          language: script.language,
          lines: script.lines,
          providerUsed: script.providerUsed,
        });

        setWorld((prev) => ({
          ...prev,
          displayMode: 'expanded',
          activePanel: 'none',
          messages: [
            ...prev.messages,
            {
              id: `bcast-${now}`,
              role: 'system',
              text:
                prev.language === 'hi'
                  ? `2-वॉइस ब्रॉडकास्ट "${script.topic}" Display A में चालू हो गया (Aoede ↔ Charon, ${script.lines.length} लाइनें)।`
                  : `2-Voice Broadcast "${script.topic}" launched in Display A (Aoede ↔ Charon, ${script.lines.length} lines).`,
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsCreatingBroadcast(false);
      }
    },
    [isCreatingBroadcast]
  );

  const handleSpawnSubBot = useCallback(
    async (role: string, task: string) => {
      if (isSpawningSubBot) return;
      setIsSpawningSubBot(true);
      try {
        const result = await spawnSubBot({
          role,
          task,
          state: worldRef.current,
          onAppendMessage: (msg) => {
            setWorld((prev) => ({
              ...prev,
              messages: [...prev.messages, msg],
              lastUpdated: Date.now(),
            }));
          },
        });
        setSubBotRuns((prev) => [result.run, ...prev].slice(0, 20));
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        const now = Date.now();
        const reason =
          err instanceof Error ? err.message : 'Sub-Bot execution failed.';
        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'error',
          progress: 0,
          message: reason,
        });
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `subbot-err-${now}`,
              role: 'system',
              text: `Sub-Bot (${role}) error: ${reason}`,
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsSpawningSubBot(false);
      }
    },
    [isSpawningSubBot]
  );

  const handleFetchAnyApi = useCallback(
    async (opts: {
      name: string;
      url: string;
      method?: 'GET' | 'POST';
      saveSkill?: boolean;
    }) => {
      if (isFetchingApi) return;
      setIsFetchingApi(true);
      try {
        const result = await fetchAnyApi({
          name: opts.name,
          url: opts.url,
          method: opts.method ?? 'GET',
          saveSkill: opts.saveSkill ?? true,
          secrets: worldRef.current.secrets,
        });
        setLastApiResult(result);
        if (result.skills) {
          setDynamicSkills(result.skills);
        }

        const now = Date.now();
        const summaryText = result.ok
          ? `[API Skill · ${result.name}] HTTP ${result.status} (${result.durationMs}ms)${
              result.savedSkill ? ' · Saved to Dynamic Skills' : ''
            }\n${result.preview.slice(0, 280)}`
          : `[API Skill · ${result.name}] Failed: ${result.error || 'Request error'}`;

        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `api-skill-${now}`,
              role: 'system',
              text: summaryText,
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsFetchingApi(false);
      }
    },
    [isFetchingApi]
  );

  const handleDeleteDynamicSkill = useCallback((id: string) => {
    setDynamicSkills((prev) => deleteDynamicSkill(prev, id));
  }, []);

  const handleSyncSkillsComplete = useCallback((synced: DynamicSkill[]) => {
    setDynamicSkills(saveDynamicSkills(synced));
  }, []);

  const handleRunAIEdit = useCallback(
    async (instruction: string) => {
      if (isAIEditing) return;
      setIsAIEditing(true);
      setAiEditError(null);

      try {
        const res = await applyAIFileEdit({
          instruction,
          files: worldRef.current.files,
          activeFilePath,
          state: worldRef.current,
        });

        if (!res.ok) {
          setAiEditError(res.error || res.summary);
          return;
        }

        const now = Date.now();
        // Preserve the earliest backup if edits are already staged and not yet kept
        setPendingAIEdit((prevPending) => ({
          backupFiles: prevPending ? prevPending.backupFiles : res.backupFiles,
          changedPaths: Array.from(
            new Set([
              ...(prevPending?.changedPaths ?? []),
              ...res.changedPaths,
            ])
          ),
          summary: res.summary,
          providerUsed: res.providerUsed,
        }));

        if (res.changedPaths[0]) {
          setActiveFilePath(res.changedPaths[0]);
        }

        setWorld((prev) => ({
          ...prev,
          files: res.nextFiles,
          messages: [
            ...prev.messages,
            {
              id: `aiedit-${now}`,
              role: 'jarvis',
              text: `[AI File Editor] ${res.summary} (${res.changedPaths.join(', ')})`,
              timestamp: now,
              language: prev.language,
              botRef: 'code',
              providerUsed: res.providerUsed,
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsAIEditing(false);
      }
    },
    [activeFilePath, isAIEditing]
  );

  const handleKeepAllEdits = useCallback(() => {
    if (!pendingAIEdit) return;
    const count = pendingAIEdit.changedPaths.length;
    setPendingAIEdit(null);
    setAiEditError(null);
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'ready',
      progress: 100,
      message: `Kept ${count} AI-edited file${count === 1 ? '' : 's'}`,
    });
  }, [pendingAIEdit]);

  const handleRevertAIEdit = useCallback(() => {
    if (!pendingAIEdit) return;
    const restored = pendingAIEdit.backupFiles;
    setPendingAIEdit(null);
    setAiEditError(null);
    const now = Date.now();
    setWorld((prev) => ({
      ...prev,
      files: restored,
      messages: [
        ...prev.messages,
        {
          id: `aiedit-rev-${now}`,
          role: 'system',
          text:
            prev.language === 'hi'
              ? 'AI फ़ाइल बदलाव रीवर्ट कर दिए गए।'
              : 'Reverted staged AI file edits cleanly.',
          timestamp: now,
          botRef: 'code',
        },
      ],
      lastUpdated: now,
    }));
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'ready',
      progress: 100,
      message: 'Reverted AI edits',
    });
  }, [pendingAIEdit]);

  const handleFixPreviewError = useCallback(
    async (errorMessage: string) => {
      if (isAIEditing) return;
      setIsAIEditing(true);
      setAiEditError(null);

      try {
        const current = worldRef.current;
        const entryPath = pickEntryFilePath(current.files) ?? activeFilePath;
        const fixInstruction = [
          `Fix the Display A live preview runtime error in ${entryPath || 'index.html'}:`,
          `Error: ${errorMessage}`,
          'Return a complete, self-contained fix that renders cleanly inside a sandboxed srcDoc iframe and Android WebView without using importmap or esm.sh.',
        ].join('\n');

        const res = await applyAIFileEdit({
          instruction: fixInstruction,
          files: current.files,
          activeFilePath: entryPath,
          state: current,
        });

        const now = Date.now();
        if (!res.ok) {
          const errText = res.error || res.summary;
          setAiEditError(errText);
          setWorld((prev) => ({
            ...prev,
            messages: [
              ...prev.messages,
              {
                id: `fixerr-fail-${now}`,
                role: 'system',
                text: `Preview Fix Error failed: ${errText}`,
                timestamp: now,
                botRef: 'code',
              },
            ],
            lastUpdated: now,
          }));
          return;
        }

        setPendingAIEdit((prevPending) => ({
          backupFiles: prevPending ? prevPending.backupFiles : res.backupFiles,
          changedPaths: Array.from(
            new Set([
              ...(prevPending?.changedPaths ?? []),
              ...res.changedPaths,
            ])
          ),
          summary: res.summary,
          providerUsed: res.providerUsed,
        }));

        if (res.changedPaths[0]) {
          setActiveFilePath(res.changedPaths[0]);
        }

        setWorld((prev) => ({
          ...prev,
          files: res.nextFiles,
          displayMode: 'expanded',
          messages: [
            ...prev.messages,
            {
              id: `fixerr-ok-${now}`,
              role: 'jarvis',
              text: `[Auto-Fix Preview] ${res.summary} (${res.changedPaths.join(', ')})`,
              timestamp: now,
              language: prev.language,
              botRef: 'code',
              providerUsed: res.providerUsed,
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsAIEditing(false);
      }
    },
    [activeFilePath, isAIEditing]
  );

  const handleCreateProject = useCallback((name?: string) => {
    const now = Date.now();
    const outgoing = buildProjectRecordFromWorld(
      activeProjectIdRef.current,
      worldRef.current,
      now
    );
    void saveProjectRecord(outgoing);

    const fallbackName = `Project ${projectsRef.current.length + 1}`;
    const nextProject = createBlankProject(name?.trim() || fallbackName);
    void saveProjectRecord(nextProject);

    setActiveProjectId(nextProject.id);
    setActiveProjectIdState(nextProject.id);
    setProjects((prev) => {
      const others = prev.filter(
        (p) => p.id !== outgoing.id && p.id !== nextProject.id
      );
      return [nextProject, outgoing, ...others];
    });

    setPendingAIEdit(null);
    setAiEditError(null);
    setBuilderCheckpoints([]);
    setBuilderResultNote(null);
    setBuilderStage(null);
    setBuilderStageTrail([]);
    awaitingPreviewVerifyRef.current.active = false;
    awaitingPreviewVerifyRef.current.healingInFlight = false;
    setPreviewVerifyState({ status: 'idle', attempt: 0, maxAttempts: 2, message: '' });
    setBroadcastSession(null);
    setCandidateAssets([]);
    setCloneNotice(null);
    setActiveFilePath(pickEntryFilePath(nextProject.files));

    setWorld((prev) => ({
      ...prev,
      projectName: nextProject.name,
      targetEngine: nextProject.targetEngine,
      currentStage: nextProject.currentStage,
      paused: false,
      files: nextProject.files,
      selectedAssets: nextProject.selectedAssets,
      messages: nextProject.messages,
      displayMode: 'expanded',
      activePanel: 'none',
      lastUpdated: nextProject.updatedAt,
    }));

    setProjectsModalOpen(false);
  }, []);

  const handleSwitchProject = useCallback((projectId: string) => {
    if (projectId === activeProjectIdRef.current) {
      setProjectsModalOpen(false);
      return;
    }

    const target = projectsRef.current.find((p) => p.id === projectId);
    if (!target) return;

    const outgoing = buildProjectRecordFromWorld(
      activeProjectIdRef.current,
      worldRef.current,
      Date.now()
    );
    void saveProjectRecord(outgoing);

    setProjects((prev) =>
      prev
        .map((p) => (p.id === outgoing.id ? outgoing : p))
        .sort((a, b) => b.updatedAt - a.updatedAt)
    );
    setActiveProjectId(target.id);
    setActiveProjectIdState(target.id);

    setPendingAIEdit(null);
    setAiEditError(null);
    setBuilderCheckpoints([]);
    setBuilderResultNote(null);
    setBuilderStage(null);
    setBuilderStageTrail([]);
    awaitingPreviewVerifyRef.current.active = false;
    awaitingPreviewVerifyRef.current.healingInFlight = false;
    setPreviewVerifyState({ status: 'idle', attempt: 0, maxAttempts: 2, message: '' });
    setBroadcastSession(null);
    setCandidateAssets([]);
    setCloneNotice(null);
    setActiveFilePath(pickEntryFilePath(target.files));

    setWorld((prev) => ({
      ...prev,
      projectName: target.name,
      targetEngine: target.targetEngine,
      currentStage: target.currentStage,
      paused: false,
      files: target.files.length > 0 ? target.files : prev.files,
      selectedAssets: target.selectedAssets,
      messages: target.messages.length > 0 ? target.messages : prev.messages,
      displayMode: 'expanded',
      activePanel: 'none',
      lastUpdated: Date.now(),
    }));

    setProjectsModalOpen(false);
  }, []);

  const handleDeleteProject = useCallback((projectId: string) => {
    const currentList = projectsRef.current;
    if (currentList.length <= 1) return;

    const remaining = currentList.filter((p) => p.id !== projectId);
    if (remaining.length === 0) return;

    void deleteProjectById(projectId);
    setProjects(remaining);

    if (projectId === activeProjectIdRef.current) {
      const nextTarget = remaining[0];
      setActiveProjectId(nextTarget.id);
      setActiveProjectIdState(nextTarget.id);
      setPendingAIEdit(null);
      setAiEditError(null);
      setBuilderCheckpoints([]);
      setBuilderResultNote(null);
      setBuilderStage(null);
      setBuilderStageTrail([]);
      awaitingPreviewVerifyRef.current.active = false;
      awaitingPreviewVerifyRef.current.healingInFlight = false;
      setPreviewVerifyState({ status: 'idle', attempt: 0, maxAttempts: 2, message: '' });
      setBroadcastSession(null);
      setCandidateAssets([]);
      setCloneNotice(null);
      setActiveFilePath(pickEntryFilePath(nextTarget.files));

      setWorld((prev) => ({
        ...prev,
        projectName: nextTarget.name,
        targetEngine: nextTarget.targetEngine,
        currentStage: nextTarget.currentStage,
        paused: false,
        files: nextTarget.files.length > 0 ? nextTarget.files : prev.files,
        selectedAssets: nextTarget.selectedAssets,
        messages:
          nextTarget.messages.length > 0 ? nextTarget.messages : prev.messages,
        displayMode: 'expanded',
        activePanel: 'none',
        lastUpdated: Date.now(),
      }));
    }
  }, []);

  const handleLiveTranscript = useCallback((evt: LiveTranscriptEvent) => {
    const clean = evt.text.trim();
    if (!clean) return;
    const now = Date.now();

    if (evt.role === 'user') {
      const existingId = liveUserMsgIdRef.current;
      if (existingId) {
        setWorld((prev) => ({
          ...prev,
          messages: prev.messages.map((m) =>
            m.id === existingId ? { ...m, text: clean, timestamp: now } : m
          ),
          lastUpdated: now,
        }));
      } else {
        const newId = `live-u-${now}`;
        liveUserMsgIdRef.current = newId;
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: newId,
              role: 'user',
              text: clean,
              timestamp: now,
              language: prev.language,
            },
          ],
          lastUpdated: now,
        }));
      }
      if (evt.isFinal) {
        liveUserMsgIdRef.current = null;
      }
      return;
    }

    const pendingActions = livePendingActionLabelsRef.current;
    const existingId = liveAssistantMsgIdRef.current;
    if (existingId) {
      setWorld((prev) => ({
        ...prev,
        messages: prev.messages.map((m) =>
          m.id === existingId
            ? {
                ...m,
                text: clean,
                timestamp: now,
                providerUsed: evt.modelLabel,
                actionLabels:
                  pendingActions.length > 0
                    ? Array.from(new Set([...(m.actionLabels ?? []), ...pendingActions]))
                    : m.actionLabels,
              }
            : m
        ),
        lastUpdated: now,
      }));
    } else {
      const newId = `live-j-${now}`;
      liveAssistantMsgIdRef.current = newId;
      setWorld((prev) => ({
        ...prev,
        messages: [
          ...prev.messages,
          {
            id: newId,
            role: 'jarvis',
            text: clean,
            timestamp: now,
            language: prev.language,
            providerUsed: evt.modelLabel,
            actionLabels: pendingActions.length > 0 ? [...pendingActions] : undefined,
          },
        ],
        lastUpdated: now,
      }));
    }

    if (evt.isFinal) {
      liveAssistantMsgIdRef.current = null;
      livePendingActionLabelsRef.current = [];
    }
  }, []);

  const handleLiveToolActions = useCallback(
    (actions: UIAction[]): string[] => {
      const labels = executeUIActions(
        actions,
        setWorld,
        worldRef.current.files,
        setActiveFilePath,
        handleSearchAssets,
        handleSelectAssetCommand,
        (repoUrl) => {
          void handleCloneRepo(repoUrl);
        },
        (theme) => {
          void handleBuild3DGame(theme);
        },
        (category, prompt) => {
          void handleBuildCommercialApp(category, prompt);
        },
        (topic) => {
          void handleCreateBroadcast(topic);
        },
        (role, task) => {
          void handleSpawnSubBot(role, task);
        },
        (name, url) => {
          void handleFetchAnyApi({ name, url, method: 'GET', saveSkill: true });
        },
        () => {
          void handleTestApis();
        },
        (prompt) => {
          runBuilderOrchestratorRef.current(prompt);
        }
      );
      if (labels.length > 0) {
        livePendingActionLabelsRef.current = [
          ...livePendingActionLabelsRef.current,
          ...labels,
        ];
      }
      return labels;
    },
    [
      handleBuild3DGame,
      handleBuildCommercialApp,
      handleCloneRepo,
      handleCreateBroadcast,
      handleFetchAnyApi,
      handleSearchAssets,
      handleSelectAssetCommand,
      handleSpawnSubBot,
      handleTestApis,
    ]
  );

  const startGeminiLiveSession = useCallback(
    async (personaOverride?: VoicePersona, speedOverride?: number) => {
      const current = worldRef.current;
      const hydratedPool = hydrateKeyPool(
        current.secrets,
        Array.isArray(current.secrets.keyPool)
      );
      const enabledGeminiKeys = hydratedPool
        .filter((e) => e.enabled && e.provider === 'gemini' && e.apiKey.trim())
        .map((e) => e.apiKey.trim());

      if (enabledGeminiKeys.length === 0) {
        const now = Date.now();
        const notice =
          current.language === 'hi'
            ? 'Gemini Live के लिए कोई Gemini Key सेव नहीं है। आप बिना Gemini के भी Mic + Hands-Free Loop के साथ Groq/NVIDIA/Cloudflare पर बात कर सकते हैं, या नीचे "Secrets" टैप करके Gemini Key जोड़ें।'
            : 'No Gemini API Key saved for Gemini Live. You can still talk hands-free on Groq/NVIDIA/Cloudflare using Mic + Hands-Free Loop, or tap "Secrets" below to add a Gemini key.';
        setWorld((prev) => ({
          ...prev,
          liveActive: false,
          messages: [
            ...prev.messages,
            {
              id: `live-nokey-${now}`,
              role: 'system',
              text: notice,
              timestamp: now,
            },
          ],
          lastUpdated: now,
        }));
        return;
      }

      liveUserMsgIdRef.current = null;
      liveAssistantMsgIdRef.current = null;
      livePendingActionLabelsRef.current = [];

      const persona = personaOverride ?? current.voicePersona;
      const speed = speedOverride ?? current.voiceSpeed;

      try {
        const connectedModel = await geminiLiveService.connect({
          apiKey: enabledGeminiKeys[0],
          apiKeys: enabledGeminiKeys,
          keyPool: hydratedPool,
          preferredModel: current.secrets.geminiLiveModel,
          voicePersona: persona,
          voiceSpeed: speed,
          language: current.language,
          files: current.files,
          memoryRules: current.memoryRules,
          onTranscript: handleLiveTranscript,
          onToolActions: handleLiveToolActions,
          onError: (reason) => {
            const now = Date.now();
            setWorld((prev) => ({
              ...prev,
              liveActive: false,
              messages: [
                ...prev.messages,
                {
                  id: `live-err-${now}`,
                  role: 'system',
                  text: `Gemini Live ended: ${reason}`,
                  timestamp: now,
                },
              ],
              lastUpdated: now,
            }));
          },
        });

        const now = Date.now();
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `live-on-${now}`,
              role: 'system',
              text:
                prev.language === 'hi'
                  ? `Gemini Live (${connectedModel}) जुड़ा · आवाज़: ${persona} · स्पीड: ${speed}x`
                  : `Gemini Live (${connectedModel}) connected · Voice: ${persona} · Speed: ${speed}x`,
              timestamp: now,
            },
          ],
          lastUpdated: now,
        }));
      } catch (err) {
        const now = Date.now();
        const reason =
          err instanceof Error ? err.message : 'Unable to connect to Gemini Live.';
        setWorld((prev) => ({
          ...prev,
          liveActive: false,
          messages: [
            ...prev.messages,
            {
              id: `live-fail-${now}`,
              role: 'system',
              text:
                prev.language === 'hi'
                  ? `Gemini Live कनेक्ट नहीं हो सका: ${reason}`
                  : `Gemini Live failed to connect: ${reason}`,
              timestamp: now,
            },
          ],
          lastUpdated: now,
        }));
      }
    },
    [handleLiveToolActions, handleLiveTranscript]
  );

  const handleTogglePause = useCallback(() => {
    // STRICT NON-DESTRUCTIVE PAUSE RULE:
    // Hold exact currentStage without disconnecting geminiLiveService,
    // without wiping files/assets, and without clearing secrets/memoryRules.
    if (worldRef.current.paused) {
      resumeStudioPipeline(worldRef.current.currentStage);
    } else {
      pauseStudioPipeline(worldRef.current.currentStage);
    }
  }, []);

  const clearHandsFreeRearmTimer = useCallback(() => {
    if (handsFreeRearmTimerRef.current !== null) {
      window.clearTimeout(handsFreeRearmTimerRef.current);
      handsFreeRearmTimerRef.current = null;
    }
  }, []);

  const handleToggleLive = useCallback(() => {
    clearHandsFreeRearmTimer();
    lastInputWasVoiceRef.current = false;
    speechStoppedManuallyRef.current = true;
    stopStudioSpeech();
    if (isDictating) {
      stopDictation();
      setIsDictating(false);
      setInterimTranscript('');
    }
    if (worldRef.current.liveActive || geminiLiveService.isConnected()) {
      geminiLiveService.disconnect();
      liveUserMsgIdRef.current = null;
      liveAssistantMsgIdRef.current = null;
      const now = Date.now();
      setWorld((prev) => ({
        ...prev,
        liveActive: false,
        messages: [
          ...prev.messages,
          {
            id: `live-off-${now}`,
            role: 'system',
            text:
              prev.language === 'hi'
                ? 'Gemini Live बंद कर दिया गया।'
                : 'Gemini Live voice disconnected.',
            timestamp: now,
          },
        ],
        lastUpdated: now,
      }));
      return;
    }
    void startGeminiLiveSession();
  }, [clearHandsFreeRearmTimer, isDictating, startGeminiLiveSession]);

  const handleVoiceChange = useCallback(
    (persona: VoicePersona, speed: number) => {
      const personaChanged = persona !== worldRef.current.voicePersona;
      geminiLiveService.setSpeed(speed);
      setCloudTtsSpeed(speed);

      studioBus.emit('voice:state', {
        active: worldRef.current.liveActive,
        phase: geminiLiveService.isConnected()
          ? geminiLiveService.getPhase()
          : voicePhase,
        model: geminiLiveService.isConnected() ? liveModel : null,
        persona,
        speed,
      });

      if (personaChanged && geminiLiveService.isConnected()) {
        void startGeminiLiveSession(persona, speed);
      }
    },
    [liveModel, startGeminiLiveSession, voicePhase]
  );

  const handleToggleVoiceReply = useCallback(() => {
    const next = !voiceReplyRef.current;
    if (!next) {
      clearHandsFreeRearmTimer();
      speechStoppedManuallyRef.current = true;
      stopStudioSpeech();
    }
    setVoiceReplyEnabled(next);
  }, [clearHandsFreeRearmTimer]);

  const handleToggleHandsFreeLoop = useCallback(() => {
    const next = !handsFreeLoopRef.current;
    if (!next) {
      clearHandsFreeRearmTimer();
      lastInputWasVoiceRef.current = false;
    } else if (!voiceReplyRef.current) {
      // Automatically turn Voice Reply ON when user enables Hands-Free Loop
      setVoiceReplyEnabled(true);
    }
    setHandsFreeLoop(next);
  }, [clearHandsFreeRearmTimer]);

  const handleStopSpeech = useCallback(() => {
    clearHandsFreeRearmTimer();
    speechStoppedManuallyRef.current = true;
    lastInputWasVoiceRef.current = false;
    stopStudioSpeech();
    setIsCloudSpeaking(false);
  }, [clearHandsFreeRearmTimer]);

  const handleAddMemoryRule = useCallback(
    (ruleText: string, category?: UserMemoryRule['category']) => {
      const { rules: updated } = addMemoryRuleUnique(
        worldRef.current.memoryRules,
        ruleText,
        category
      );
      studioBus.emit('world:update', {
        patch: { memoryRules: updated },
        source: 'memory-modal',
      });
    },
    []
  );

  const handleToggleMemoryRule = useCallback((id: string) => {
    const updated = saveMemoryRules(
      worldRef.current.memoryRules.map((r) =>
        r.id === id ? { ...r, enabled: !r.enabled } : r
      )
    );
    studioBus.emit('world:update', {
      patch: { memoryRules: updated },
      source: 'memory-modal',
    });
  }, []);

  const handleDeleteMemoryRule = useCallback((id: string) => {
    const updated = saveMemoryRules(
      worldRef.current.memoryRules.filter((r) => r.id !== id)
    );
    studioBus.emit('world:update', {
      patch: { memoryRules: updated },
      source: 'memory-modal',
    });
  }, []);

  const handleSyncMemoryComplete = useCallback((syncedRules: UserMemoryRule[]) => {
    const persisted = saveMemoryRules(syncedRules);
    studioBus.emit('world:update', {
      patch: { memoryRules: persisted },
      source: 'memory-sync',
    });
  }, []);

  const handleBotTap = useCallback(
    (botId: BotId) => {
      const current = world.bots[botId];
      const nextStatus = current.status === 'ready' ? 'idle' : 'ready';
      studioBus.emit('bot:progress', {
        botId,
        status: nextStatus,
        progress: nextStatus === 'ready' ? 100 : 0,
        message:
          nextStatus === 'ready'
            ? `${current.label} slot armed via studioBus`
            : `${current.label} slot on standby`,
      });
    },
    [world.bots]
  );

  const beginDictationSessionRef = useRef<() => void>(() => {});

  const handleSendMessage = useCallback(
    async (text: string, fromVoiceDictation = false) => {
      if (isThinkingRef.current) return;
      clearHandsFreeRearmTimer();
      lastInputWasVoiceRef.current = fromVoiceDictation;
      speechStoppedManuallyRef.current = false;

      const currentWorld = worldRef.current;
      const now = Date.now();
      const userMsg = {
        id: `u-${now}`,
        role: 'user' as const,
        text,
        timestamp: now,
        language: currentWorld.language,
      };

      const snapshot: WorldState = {
        ...currentWorld,
        messages: [...currentWorld.messages, userMsg],
      };

      setWorld((prev) => ({
        ...prev,
        messages: [...prev.messages, userMsg],
        lastUpdated: now,
      }));

      setIsThinking(true);
      studioBus.emit('bot:progress', {
        botId: 'code',
        status: 'working',
        progress: 35,
        message: 'Routing JARVIS command...',
      });

      try {
        // 0. Smart Chat-Paste Auto-Routing (API Keys, GitHub PAT, Supabase URL, 3D/Image URLs)
        const trimmedPaste = text.trim();
        const isSingleTokenPaste = !/\s/.test(trimmedPaste) && trimmedPaste.length >= 16;
        if (isSingleTokenPaste) {
          const isGithubPat = /^(ghp_|github_pat_)/i.test(trimmedPaste);
          const isSupabaseUrl = /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(trimmedPaste);
          const isDirectAssetUrl =
            /^https?:\/\//i.test(trimmedPaste) &&
            /\.(glb|gltf|png|jpg|jpeg|webp|svg|hdr|mp3|wav)(\?.*)?$/i.test(trimmedPaste);
          const detectedProvider =
            !isGithubPat && !isSupabaseUrl && !isDirectAssetUrl
              ? detectProviderFromKey(trimmedPaste)
              : 'custom';

          if (isGithubPat || isSupabaseUrl || isDirectAssetUrl || detectedProvider !== 'custom') {
            const latest = worldRef.current;
            let confirmHi = '';
            let confirmEn = '';
            let actionBadge = 'Auto-Saved';

            if (isGithubPat) {
              const updatedSecrets = { ...latest.secrets, githubToken: trimmedPaste };
              saveSecrets(updatedSecrets);
              setWorld((prev) => ({ ...prev, secrets: updatedSecrets, lastUpdated: Date.now() }));
              confirmHi = 'आपका GitHub PAT टोकन अपने आप Secrets में सेव हो गया है! अब आप 1 क्लिक में APK पुश कर सकते हो।';
              confirmEn = 'Saved your GitHub PAT automatically to Secrets. Ready for 1-click APK push.';
              actionBadge = 'GitHub PAT Saved';
              setLiveConnectionLabel('Chat → Secrets (GitHub PAT)');
            } else if (isSupabaseUrl) {
              const updatedSecrets = { ...latest.secrets, appsSupabaseUrl: trimmedPaste };
              saveSecrets(updatedSecrets);
              setWorld((prev) => ({ ...prev, secrets: updatedSecrets, lastUpdated: Date.now() }));
              confirmHi = 'आपका Supabase URL अपने आप Apps DB Secrets में सेव हो गया है!';
              confirmEn = 'Saved your Supabase URL automatically to Apps DB Secrets.';
              actionBadge = 'Supabase URL Saved';
              setLiveConnectionLabel('Chat → Secrets (Supabase)');
            } else if (isDirectAssetUrl) {
              const fileName = trimmedPaste.split('/').pop()?.split('?')[0] || 'custom-asset';
              const newAsset = {
                id: `pasted-${Date.now()}`,
                name: fileName,
                category: 'vehicles' as const,
                source: 'Chat Paste',
                url: trimmedPaste,
                format: fileName.split('.').pop()?.toUpperCase() || 'ASSET',
                selected: true,
                addedAt: Date.now(),
              };
              setWorld((prev) => ({
                ...prev,
                selectedAssets: [...prev.selectedAssets, newAsset],
                lastUpdated: Date.now(),
              }));
              confirmHi = `आपका एसेट (${fileName}) अपने आप प्रोजेक्ट Assets में जुड़ गया है! Builder अब इसे सीधे इस्तेमाल करेगा।`;
              confirmEn = `Added ${fileName} automatically to your project Assets for the Builder.`;
              actionBadge = 'Asset Attached';
              setLiveConnectionLabel('Chat → Assets Vault');
            } else {
              const existingPool = hydrateKeyPool(latest.secrets, Array.isArray(latest.secrets.keyPool));
              const newEntry = {
                id: `key-${Date.now()}`,
                provider: detectedProvider,
                label: getProviderDisplayName(detectedProvider),
                apiKey: trimmedPaste,
                model: getDefaultModelForProvider(detectedProvider),
                enabled: true,
              };
              const nextPool = [...existingPool, newEntry];
              const synced = syncLegacyFieldsFromKeyPool({ ...latest.secrets, keyPool: nextPool });
              saveSecrets(synced);
              setWorld((prev) => ({ ...prev, secrets: synced, lastUpdated: Date.now() }));
              confirmHi = `आपकी ${getProviderDisplayName(detectedProvider)} API Key अपने आप पहचान कर Secrets Pool में सेव कर दी गई है!`;
              confirmEn = `Auto-detected and saved your ${getProviderDisplayName(detectedProvider)} API Key to the Smart Key Pool.`;
              actionBadge = `${getProviderDisplayName(detectedProvider)} Key Saved`;
              setLiveConnectionLabel(`Chat → Secrets (${getProviderDisplayName(detectedProvider)})`);
            }

            const replyText = currentWorld.language === 'hi' ? confirmHi : confirmEn;
            setWorld((prev) => ({
              ...prev,
              messages: [
                ...prev.messages,
                {
                  id: `j-paste-${Date.now()}`,
                  role: 'jarvis',
                  text: replyText,
                  timestamp: Date.now(),
                  language: currentWorld.language,
                  providerUsed: 'Auto-Router',
                  actionLabels: [actionBadge],
                },
              ],
              lastUpdated: Date.now(),
            }));
            if (voiceReplyRef.current && !geminiLiveService.isConnected()) {
              const st = worldRef.current;
              void speakStudioReply(replyText, {
                geminiKey: st.secrets.geminiApiKey,
                keyPool: hydrateKeyPool(st.secrets, Array.isArray(st.secrets.keyPool)),
                ttsModel: st.secrets.geminiTtsModel,
                voicePersona: st.voicePersona,
                voiceSpeed: st.voiceSpeed,
                language: st.language,
              });
            }
            return;
          }
        }

        // Fuel-Independent JARVIS Architect Step-Plan Interception (EN/HI)
        if (detectArchitectPlanIntent(text)) {
          studioBus.emit('bot:progress', {
            botId: 'code',
            status: 'working',
            progress: 55,
            message: 'JARVIS Architect locking sequential steps...',
          });

          const planRes = await generateLockedStepPlan({
            goal: text,
            language: currentWorld.language,
            state: snapshot,
          });

          const replyText = planRes.errorNote
            ? `${planRes.reply}\n(${planRes.errorNote})`
            : planRes.reply;

          const assistantMsg = {
            id: `j-plan-${Date.now()}`,
            role: 'jarvis' as const,
            text: replyText,
            timestamp: Date.now(),
            language: currentWorld.language,
            botRef: 'code' as const,
            providerUsed: planRes.providerUsed,
            actionLabels: [`Locked ${planRes.steps.length} Steps`],
            stepPlan: planRes.steps,
          };

          setWorld((prev) => ({
            ...prev,
            messages: [...prev.messages, assistantMsg],
            lastUpdated: Date.now(),
          }));

          studioBus.emit('bot:progress', {
            botId: 'code',
            status: 'ready',
            progress: 100,
            message: `Architect locked ${planRes.steps.length} steps`,
          });

          if (voiceReplyRef.current && !geminiLiveService.isConnected()) {
            const latest = worldRef.current;
            const hydratedPool = hydrateKeyPool(
              latest.secrets,
              Array.isArray(latest.secrets.keyPool)
            );
            void speakStudioReply(planRes.reply, {
              geminiKey: latest.secrets.geminiApiKey,
              keyPool: hydratedPool,
              ttsModel: latest.secrets.geminiTtsModel,
              voicePersona: latest.voicePersona,
              voiceSpeed: latest.voiceSpeed,
              language: latest.language,
            });
          }
          return;
        }

        let liveWebContext = '';
        if (shouldRunLiveWebResearch(text)) {
          setLiveConnectionLabel('JARVIS → Live Web Research');
          liveWebContext = await fetchLiveWebResearchContext(text);
        }
        setLiveConnectionLabel('JARVIS → Multi-AI Brain');
        const result = await routeStudioCommand(text, snapshot, liveWebContext);

        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'working',
          progress: 80,
          message: 'Executing UI actuators...',
        });

        const executedLabels = executeUIActions(
          result.actions,
          setWorld,
          snapshot.files,
          setActiveFilePath,
          handleSearchAssets,
          handleSelectAssetCommand,
          (repoUrl) => {
            void handleCloneRepo(repoUrl);
          },
          (theme) => {
            setLiveConnectionLabel('JARVIS → NVIDIA 480B → Display A');
            const customPrompt = [
              `Build an interactive, playable 3D Three.js WebGL preview directly in index.html for: ${theme || text}.`,
              `Follow the user's exact request: "${text}".`,
              'Include touch steering/controls, gears, accelerator/brake, Web Audio engine/click sound, and clean HUD. Classic Three.js UMD script only (zero importmap, zero esm.sh).',
            ].join('\n');
            runBuilderOrchestratorRef.current(customPrompt);
            void handleSpawnSubBot('Physics Tuner', `Tune controls, physics, and mobile 360px layout for: ${theme || text}`);
          },
          (category, prompt) => {
            setLiveConnectionLabel('JARVIS → NVIDIA 480B → Display A');
            const customPrompt = [
              `Build an interactive, working commercial mobile app preview (${category}) directly in index.html.`,
              `Follow the user's exact request: "${prompt || text}".`,
              'Ensure crisp 360px mobile UI, interactive buttons/tabs, realistic sample flows, and zero runtime errors.',
            ].join('\n');
            runBuilderOrchestratorRef.current(customPrompt);
            void handleSpawnSubBot('UI Polish', `Audit 360px mobile UI polish and flows for: ${prompt || text}`);
          },
          (topic) => {
            void handleCreateBroadcast(topic);
          },
          (role, task) => {
            void handleSpawnSubBot(role, task);
          },
          (name, url) => {
            void handleFetchAnyApi({ name, url, method: 'GET', saveSkill: true });
          },
          () => {
            void handleTestApis();
          },
          (prompt) => {
            runBuilderOrchestratorRef.current(prompt);
          }
        );

        const replyText = result.errorNote
          ? `${result.reply}\n(${result.errorNote})`
          : result.reply;

        const assistantMsg = {
          id: `j-${Date.now()}`,
          role: 'jarvis' as const,
          text: replyText,
          timestamp: Date.now(),
          language: currentWorld.language,
          botRef: 'code' as const,
          providerUsed: result.providerUsed,
          actionLabels: executedLabels,
        };

        setWorld((prev) => ({
          ...prev,
          messages: [...prev.messages, assistantMsg],
          lastUpdated: Date.now(),
        }));

        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'ready',
          progress: 100,
          message: `Responded via ${result.providerUsed}`,
        });

        // Auto-speak non-Live replies via independent Key-Rotating Aoede Studio Voice
        if (voiceReplyRef.current && !geminiLiveService.isConnected()) {
          const latest = worldRef.current;
          const hydratedPool = hydrateKeyPool(
            latest.secrets,
            Array.isArray(latest.secrets.keyPool)
          );
          const shouldRearmAfterSpeech =
            handsFreeLoopRef.current &&
            voiceReplyRef.current &&
            lastInputWasVoiceRef.current;

          void speakStudioReply(result.reply, {
            geminiKey: latest.secrets.geminiApiKey,
            keyPool: hydratedPool,
            ttsModel: latest.secrets.geminiTtsModel,
            voicePersona: latest.voicePersona,
            voiceSpeed: latest.voiceSpeed,
            language: latest.language,
          }).then(() => {
            if (
              shouldRearmAfterSpeech &&
              handsFreeLoopRef.current &&
              voiceReplyRef.current &&
              lastInputWasVoiceRef.current &&
              !speechStoppedManuallyRef.current &&
              !geminiLiveService.isConnected() &&
              !isThinkingRef.current
            ) {
              clearHandsFreeRearmTimer();
              handsFreeRearmTimerRef.current = window.setTimeout(() => {
                handsFreeRearmTimerRef.current = null;
                if (
                  handsFreeLoopRef.current &&
                  voiceReplyRef.current &&
                  !speechStoppedManuallyRef.current &&
                  !geminiLiveService.isConnected() &&
                  !isThinkingRef.current
                ) {
                  beginDictationSessionRef.current();
                }
              }, 300);
            }
          });
        }
      } catch (err) {
        const fallbackMsg = {
          id: `j-${Date.now()}`,
          role: 'jarvis' as const,
          text:
            err instanceof Error
              ? `Router error: ${err.message}`
              : 'Router encountered an unexpected error.',
          timestamp: Date.now(),
          language: currentWorld.language,
          providerUsed: 'Local',
        };
        setWorld((prev) => ({
          ...prev,
          messages: [...prev.messages, fallbackMsg],
          lastUpdated: Date.now(),
        }));
        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'ready',
          progress: 100,
          message: 'Ready (fallback)',
        });
      } finally {
        setIsThinking(false);
      }
    },
    [
      clearHandsFreeRearmTimer,
      handleBuild3DGame,
      handleBuildCommercialApp,
      handleCloneRepo,
      handleCreateBroadcast,
      handleFetchAnyApi,
      handleSearchAssets,
      handleSelectAssetCommand,
      handleSpawnSubBot,
      handleTestApis,
    ]
  );

  const beginDictationSession = useCallback(() => {
    clearHandsFreeRearmTimer();
    const current = worldRef.current;
    setIsDictating(true);
    setInterimTranscript('');

    void startDictation({
      language: current.language,
      isLiveActive: current.liveActive || geminiLiveService.isConnected(),
      stopLiveFirst: () => {
        geminiLiveService.disconnect();
      },
      onInterim: (partial) => {
        setInterimTranscript(partial);
      },
      onFinal: (transcript) => {
        setIsDictating(false);
        setInterimTranscript('');
        if (transcript.trim()) {
          void handleSendMessage(transcript.trim(), true);
        }
      },
      onError: (errorMsg) => {
        setIsDictating(false);
        setInterimTranscript('');
        const isTransientSilence =
          /no-speech|कोई आवाज़ सुनाई नहीं दी|aborted/i.test(errorMsg);
        if (
          handsFreeLoopRef.current &&
          isTransientSilence &&
          !speechStoppedManuallyRef.current &&
          !geminiLiveService.isConnected() &&
          !isThinkingRef.current
        ) {
          clearHandsFreeRearmTimer();
          handsFreeRearmTimerRef.current = window.setTimeout(() => {
            handsFreeRearmTimerRef.current = null;
            if (
              handsFreeLoopRef.current &&
              !speechStoppedManuallyRef.current &&
              !geminiLiveService.isConnected() &&
              !isThinkingRef.current
            ) {
              beginDictationSessionRef.current();
            }
          }, 650);
          return;
        }
        lastInputWasVoiceRef.current = false;
        const now = Date.now();
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `dict-err-${now}`,
              role: 'system',
              text: errorMsg,
              timestamp: now,
            },
          ],
          lastUpdated: now,
        }));
      },
    }).then((started) => {
      if (!started) {
        setIsDictating(false);
      }
    });
  }, [clearHandsFreeRearmTimer, handleSendMessage]);

  useEffect(() => {
    beginDictationSessionRef.current = beginDictationSession;
  }, [beginDictationSession]);

  const handleToggleDictation = useCallback(() => {
    clearHandsFreeRearmTimer();
    if (isDictating) {
      lastInputWasVoiceRef.current = false;
      speechStoppedManuallyRef.current = true;
      stopDictation();
      setIsDictating(false);
      setInterimTranscript('');
      return;
    }

    beginDictationSession();
  }, [beginDictationSession, clearHandsFreeRearmTimer, isDictating]);

  const handleReplayMessage = useCallback((msgText: string) => {
    const latest = worldRef.current;
    speechStoppedManuallyRef.current = false;
    const hydratedPool = hydrateKeyPool(
      latest.secrets,
      Array.isArray(latest.secrets.keyPool)
    );
    void speakStudioReply(msgText, {
      geminiKey: latest.secrets.geminiApiKey,
      keyPool: hydratedPool,
      ttsModel: latest.secrets.geminiTtsModel,
      voicePersona: latest.voicePersona,
      voiceSpeed: latest.voiceSpeed,
      language: latest.language,
    });
  }, []);

  const handleApproveGate = useCallback((msgId: string, nextPrompt: string) => {
    setWorld((prev) => ({
      ...prev,
      messages: prev.messages.map((m) =>
        m.id === msgId && m.approveGate
          ? { ...m, approveGate: { ...m.approveGate, resolved: true } }
          : m
      ),
      lastUpdated: Date.now(),
    }));
    setLiveConnectionLabel('Approved → NVIDIA 480B → Display A');
    runBuilderOrchestratorRef.current(nextPrompt);
  }, []);

  const handleRequestGateChange = useCallback((msgId: string) => {
    setWorld((prev) => ({
      ...prev,
      messages: [
        ...prev.messages.map((m) =>
          m.id === msgId && m.approveGate
            ? { ...m, approveGate: { ...m.approveGate, resolved: true } }
            : m
        ),
        {
          id: `j-change-${Date.now()}`,
          role: 'jarvis',
          text:
            prev.language === 'hi'
              ? 'ठीक है सर! बताइए इस स्टेप में क्या बदलना है (रंग, कंट्रोल, स्पीड या डिज़ाइन)—मैं तुरंत अपडेट कर देता हूँ।'
              : 'Got it! Tell me what you want changed in this step and I will update it right away.',
          timestamp: Date.now(),
          language: prev.language,
          providerUsed: 'JARVIS',
        },
      ],
      lastUpdated: Date.now(),
    }));
  }, []);

  // 15-second Hands-Free Watchdog: auto-recovers mic if Hands-Free stalls silently
  useEffect(() => {
    if (!handsFreeLoop) return;
    const interval = window.setInterval(() => {
      if (
        handsFreeLoopRef.current &&
        !speechStoppedManuallyRef.current &&
        !isThinkingRef.current &&
        !isDictating &&
        !isCloudSpeaking &&
        !geminiLiveService.isConnected()
      ) {
        beginDictationSessionRef.current();
      }
    }, 15_000);
    return () => window.clearInterval(interval);
  }, [handsFreeLoop, isDictating, isCloudSpeaking]);

  const handleSendStepToBuilder = useCallback((step: LockedStepPlanItem) => {
    setQueuedBuilderPrompt(step.lockedPrompt);
    setBuilderResultNote(null);
    studioBus.emit('builder:queue', {
      prompt: step.lockedPrompt,
      stepNumber: step.stepNumber,
      title: step.title,
    });
    studioBus.emit('ui:panel', { panel: 'code' });
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'ready',
      progress: 100,
      message: `Queued Step ${step.stepNumber} for Builder`,
    });
  }, []);

  useEffect(() => {
    queuedBuilderPromptRef.current = queuedBuilderPrompt;
  }, [queuedBuilderPrompt]);

  const handleRunStudioBuilder = useCallback(
    async (prompt: string) => {
      const clean = prompt.trim();
      if (!clean || isBuildingStep) return;

      awaitingPreviewVerifyRef.current = {
        active: false,
        buildCompletedAt: 0,
        attempt: 0,
        originalPrompt: clean,
        healingInFlight: false,
      };
      setPreviewVerifyState({
        status: 'idle',
        attempt: 0,
        maxAttempts: 2,
        message: '',
      });
      setIsBuildingStep(true);
      setBuilderResultNote(null);
      setBuilderStage({
        stage: 'reading',
        label: 'Reading files',
        progress: 10,
      });
      setBuilderStageTrail(['Reading files']);

      try {
        const current = worldRef.current;
        const result = await runBuiltInStudioBuilder({
          prompt: clean,
          files: current.files,
          selectedAssets: current.selectedAssets,
          state: current,
          onStageUpdate: (update) => {
            setBuilderStage(update);
            if (
              update.stage === 'reading' ||
              update.stage === 'coding' ||
              update.stage === 'staging'
            ) {
              setBuilderStageTrail((prev) =>
                prev.includes(update.label) ? prev : [...prev, update.label]
              );
            }
          },
        });

        const now = Date.now();
        if (!result.ok) {
          const errText = result.error || result.summary;
          setBuilderResultNote({ ok: false, text: errText });
          setWorld((prev) => ({
            ...prev,
            messages: [
              ...prev.messages,
              {
                id: `builder-err-${now}`,
                role: 'system',
                text: `[Studio Builder] ${errText}`,
                timestamp: now,
                botRef: 'code',
              },
            ],
            lastUpdated: now,
          }));
          return;
        }

        if (result.checkpoint) {
          const cp = result.checkpoint;
          setBuilderCheckpoints((prev) => [cp, ...prev].slice(0, 8));
        }

        setQueuedBuilderPrompt(null);
        setPendingAIEdit(null);
        setAiEditError(null);

        const preferredFile =
          result.updatedFiles.find((f) => f.path.toLowerCase().endsWith('.html'))
            ?.path ?? result.updatedFiles[0]?.path;
        if (preferredFile) {
          setActiveFilePath(preferredFile);
        }

        const secs = Math.max(1, Math.round(result.durationMs / 1000));
        const fileList = result.updatedFiles.map((f) => f.path).join(', ');
        const noteText = `${result.summary} (${result.updatedFiles.length} file${
          result.updatedFiles.length === 1 ? '' : 's'
        } · ${secs}s · ${result.providerUsed})`;
        setBuilderResultNote({ ok: true, text: noteText });

        // Arm Autonomous Display A Self-Heal verification window
        awaitingPreviewVerifyRef.current = {
          active: true,
          buildCompletedAt: Date.now(),
          attempt: 0,
          originalPrompt: clean,
          healingInFlight: false,
        };
        setPreviewVerifyState({
          status: 'verifying',
          attempt: 0,
          maxAttempts: 2,
          message: 'Verifying Display A preview...',
        });

        setWorld((prev) => ({
          ...prev,
          files: result.nextFiles,
          displayMode: 'expanded',
          messages: [
            ...prev.messages,
            {
              id: `builder-ok-${now}`,
              role: 'jarvis',
              text: `[Studio Builder] ${result.summary}\nFiles: ${fileList}`,
              timestamp: now,
              language: prev.language,
              botRef: 'code',
              providerUsed: result.providerUsed,
              actionLabels: [
                `Built ${result.updatedFiles.length} File${
                  result.updatedFiles.length === 1 ? '' : 's'
                }`,
                'Checkpoint Saved',
              ],
              approveGate: {
                label:
                  prev.language === 'hi'
                    ? 'Approve & अगला स्टेप'
                    : 'Approve & Next Step',
                nextPrompt: `Continue to the next locked incremental step on top of the existing project files without breaking what works. Improve visuals, controls, polish, and features cleanly.`,
                resolved: false,
              },
            },
          ],
          lastUpdated: now,
        }));
      } finally {
        setIsBuildingStep(false);
      }
    },
    [isBuildingStep]
  );

  // Autonomous Display A Self-Heal Loop: listens to previewErrorSpy telemetry after a Studio Builder build
  useEffect(() => {
    const MAX_AUTO_HEAL_ATTEMPTS = 2;
    const SELF_HEAL_WINDOW_MS = 3_000;

    const handlePreviewTelemetry = (event: MessageEvent) => {
      if (!isPreviewTelemetryMessage(event.data)) return;
      const pending = awaitingPreviewVerifyRef.current;
      if (!pending.active || pending.healingInFlight) return;

      const payload = event.data;

      if (payload.type === 'ok') {
        pending.active = false;
        setPreviewVerifyState({
          status: 'verified',
          attempt: pending.attempt,
          maxAttempts: MAX_AUTO_HEAL_ATTEMPTS,
          message: 'Preview Verified ✓',
        });
        setBuilderResultNote((prev) =>
          prev && prev.ok
            ? {
                ok: true,
                text: prev.text.includes('Preview Verified ✓')
                  ? prev.text
                  : `Preview Verified ✓ · ${prev.text}`,
              }
            : { ok: true, text: 'Preview Verified ✓' }
        );
        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'ready',
          progress: 100,
          message: 'Preview Verified ✓',
        });
        return;
      }

      if (payload.type === 'error') {
        const elapsedSinceBuild = Date.now() - pending.buildCompletedAt;
        if (elapsedSinceBuild > SELF_HEAL_WINDOW_MS) {
          pending.active = false;
          return;
        }

        const capturedError =
          payload.message?.trim() || 'Runtime/WebGL error detected in Display A preview.';

        // Persist error pattern into sarfealam_error_memory_v2 so builder avoids repeating it
        recordPreviewErrorMemory({
          projectName: worldRef.current.projectName,
          errorMessage: capturedError,
        });

        if (pending.attempt >= MAX_AUTO_HEAL_ATTEMPTS) {
          pending.active = false;
          setPreviewVerifyState({
            status: 'failed',
            attempt: MAX_AUTO_HEAL_ATTEMPTS,
            maxAttempts: MAX_AUTO_HEAL_ATTEMPTS,
            message: `Auto-Heal stopped after ${MAX_AUTO_HEAL_ATTEMPTS}/${MAX_AUTO_HEAL_ATTEMPTS} attempts: ${capturedError}`,
          });
          setBuilderResultNote({
            ok: false,
            text: `Self-Heal stopped (2/2): ${capturedError}`,
          });
          return;
        }

        const nextAttempt = pending.attempt + 1;
        pending.attempt = nextAttempt;
        pending.healingInFlight = true;

        setIsBuildingStep(true);
        setPreviewVerifyState({
          status: 'healing',
          attempt: nextAttempt,
          maxAttempts: MAX_AUTO_HEAL_ATTEMPTS,
          message: `Auto-Healing Attempt ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}...`,
        });
        setBuilderStage({
          stage: 'coding',
          label: `Auto-Healing Attempt ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}`,
          detail: capturedError,
          progress: 40,
        });
        setBuilderStageTrail([
          `Auto-Healing Attempt ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}`,
        ]);

        const healPrompt = [
          `AUTONOMOUS DISPLAY A SELF-HEAL (Attempt ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}):`,
          `The freshly built Display A preview threw this exact runtime/WebGL error within 3s of load:`,
          `ERROR: ${capturedError}`,
          '',
          `Original step goal: ${pending.originalPrompt}`,
          '',
          'Fix the root cause cleanly across the affected WorldState.files without breaking working features.',
          'NEVER use <script type="importmap"> or esm.sh; ensure classic Three.js UMD script if 3D is used, ensure zero uncaught exceptions, and render visible non-empty DOM/Canvas content immediately.',
        ].join('\n');

        void (async () => {
          try {
            const latest = worldRef.current;
            const healRes = await runBuiltInStudioBuilder({
              prompt: healPrompt,
              files: latest.files,
              selectedAssets: latest.selectedAssets,
              state: latest,
              onStageUpdate: (update) => {
                setBuilderStage(update);
                if (
                  update.stage === 'reading' ||
                  update.stage === 'coding' ||
                  update.stage === 'staging'
                ) {
                  setBuilderStageTrail((prev) =>
                    prev.includes(update.label) ? prev : [...prev, update.label]
                  );
                }
              },
            });

            const now = Date.now();
            if (!healRes.ok) {
              pending.active = false;
              pending.healingInFlight = false;
              const failMsg = healRes.error || healRes.summary;
              setPreviewVerifyState({
                status: 'failed',
                attempt: nextAttempt,
                maxAttempts: MAX_AUTO_HEAL_ATTEMPTS,
                message: failMsg,
              });
              setBuilderResultNote({
                ok: false,
                text: `Auto-Heal ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS} failed: ${failMsg}`,
              });
              return;
            }

            if (healRes.checkpoint) {
              const cp = healRes.checkpoint;
              setBuilderCheckpoints((prev) => [cp, ...prev].slice(0, 8));
            }

            recordPreviewErrorMemory({
              projectName: latest.projectName,
              errorMessage: capturedError,
              fixSummary: healRes.summary,
            });

            const preferredFile =
              healRes.updatedFiles.find((f) =>
                f.path.toLowerCase().endsWith('.html')
              )?.path ?? healRes.updatedFiles[0]?.path;
            if (preferredFile) {
              setActiveFilePath(preferredFile);
            }

            setBuilderResultNote({
              ok: true,
              text: `Auto-Heal ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS} applied · ${healRes.summary}`,
            });

            // Rearm verification for the healed Display A iframe
            awaitingPreviewVerifyRef.current = {
              active: true,
              buildCompletedAt: Date.now(),
              attempt: nextAttempt,
              originalPrompt: pending.originalPrompt,
              healingInFlight: false,
            };
            setPreviewVerifyState({
              status: 'verifying',
              attempt: nextAttempt,
              maxAttempts: MAX_AUTO_HEAL_ATTEMPTS,
              message: `Verifying Self-Heal ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}...`,
            });

            setWorld((prev) => ({
              ...prev,
              files: healRes.nextFiles,
              displayMode: 'expanded',
              messages: [
                ...prev.messages,
                {
                  id: `autoheal-${nextAttempt}-${now}`,
                  role: 'jarvis',
                  text: `[Auto-Heal ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}] Fixed preview error (${capturedError.slice(
                    0,
                    90
                  )}): ${healRes.summary}`,
                  timestamp: now,
                  language: prev.language,
                  botRef: 'code',
                  providerUsed: healRes.providerUsed,
                  actionLabels: [
                    `Self-Heal ${nextAttempt}/${MAX_AUTO_HEAL_ATTEMPTS}`,
                    'Error Memory Updated',
                  ],
                },
              ],
              lastUpdated: now,
            }));
          } finally {
            setIsBuildingStep(false);
          }
        })();
      }
    };

    window.addEventListener('message', handlePreviewTelemetry);
    return () => window.removeEventListener('message', handlePreviewTelemetry);
  }, []);

  const handleOrchestratorRunBuilder = useCallback(
    (prompt: string) => {
      const effectivePrompt =
        prompt.trim() || queuedBuilderPromptRef.current?.trim() || '';
      studioBus.emit('ui:panel', { panel: 'code' });

      if (!effectivePrompt) {
        const now = Date.now();
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `builder-noqueue-${now}`,
              role: 'system',
              text:
                prev.language === 'hi'
                  ? 'बिल्डर खुल गया है — कोई क्यू किया हुआ स्टेप नहीं मिला। कृपया प्रॉम्प्ट पेस्ट करें या पहले JARVIS से "steps banao" कहें।'
                  : 'Opened Built-in Studio Builder — no queued step found yet. Paste a prompt or ask JARVIS to "make step by step plan" first.',
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        }));
        return;
      }

      setQueuedBuilderPrompt(effectivePrompt);
      void handleRunStudioBuilder(effectivePrompt);
    },
    [handleRunStudioBuilder]
  );

  useEffect(() => {
    runBuilderOrchestratorRef.current = handleOrchestratorRunBuilder;
  }, [handleOrchestratorRunBuilder]);

  const handleRestoreBuilderCheckpoint = useCallback(
    (checkpointId: string) => {
      const target = builderCheckpoints.find((cp) => cp.id === checkpointId);
      if (!target) return;

      const restoredFiles = target.files.map((f) => ({ ...f }));
      const now = Date.now();
      awaitingPreviewVerifyRef.current.active = false;
      awaitingPreviewVerifyRef.current.healingInFlight = false;
      setPreviewVerifyState({
        status: 'idle',
        attempt: 0,
        maxAttempts: 2,
        message: '',
      });
      setPendingAIEdit(null);
      setAiEditError(null);
      setActiveFilePath(pickEntryFilePath(restoredFiles));
      setBuilderResultNote({
        ok: true,
        text:
          worldRef.current.language === 'hi'
            ? `चेकपॉइंट "${target.label}" रीस्टोर किया गया (${restoredFiles.length} फ़ाइलें)।`
            : `Restored checkpoint "${target.label}" (${restoredFiles.length} files).`,
      });

      setWorld((prev) => ({
        ...prev,
        files: restoredFiles,
        displayMode: 'expanded',
        messages: [
          ...prev.messages,
          {
            id: `builder-restore-${now}`,
            role: 'system',
            text:
              prev.language === 'hi'
                ? `[Studio Builder] चेकपॉइंट रीस्टोर हुआ: ${target.label}`
                : `[Studio Builder] Restored checkpoint: ${target.label} (${restoredFiles.length} files).`,
            timestamp: now,
            botRef: 'code',
          },
        ],
        lastUpdated: now,
      }));

      studioBus.emit('bot:progress', {
        botId: 'code',
        status: 'ready',
        progress: 100,
        message: `Restored: ${target.label}`,
      });
    },
    [builderCheckpoints]
  );

  const handleDownloadProjectZip = useCallback((): ZipDownloadResult => {
    const current = worldRef.current;
    const res = downloadProjectZip(current.projectName, current.files);
    if (res.ok) {
      studioBus.emit('bot:progress', {
        botId: 'code',
        status: 'ready',
        progress: 100,
        message: `Downloaded ${res.fileName} (${res.fileCount} files)`,
      });
    }
    return res;
  }, []);

  const handlePreviewDisplayA = useCallback(() => {
    studioBus.emit('world:update', {
      patch: { displayMode: 'expanded' },
      source: 'studio-builder-preview',
    });
    studioBus.emit('ui:panel', { panel: 'none' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleVisionMessage = useCallback((text: string, providerUsed: string) => {
    const now = Date.now();
    setWorld((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          id: `vis-${now}`,
          role: 'jarvis',
          text,
          timestamp: now,
          language: prev.language,
          botRef: 'vision',
          providerUsed,
        },
      ],
      lastUpdated: now,
    }));
  }, []);

  const handleApproveOk = useCallback(() => {
    const now = Date.now();
    // 1. Approve pending staged AI file edits if present
    if (pendingAIEdit) {
      const count = pendingAIEdit.changedPaths.length;
      handleKeepAllEdits();
      setWorld((prev) => ({
        ...prev,
        messages: [
          ...prev.messages,
          {
            id: `ok-edits-${now}`,
            role: 'system',
            text:
              prev.language === 'hi'
                ? `OK · ${count} AI फ़ाइल बदलाव मंज़ूर किए गए।`
                : `OK · Approved ${count} pending AI file edit${count === 1 ? '' : 's'}.`,
            timestamp: now,
            botRef: 'code',
          },
        ],
        lastUpdated: now,
      }));
      return;
    }

    // 2. Approve pending hunted candidate assets when Vault is open
    if (worldRef.current.activePanel === 'vault' && candidateAssetsRef.current.length > 0) {
      const summary = handleSelectAssetCommand('all', 'keep');
      setWorld((prev) => ({
        ...prev,
        messages: [
          ...prev.messages,
          {
            id: `ok-assets-${now}`,
            role: 'system',
            text: `OK · ${summary}`,
            timestamp: now,
            botRef: 'asset',
          },
        ],
        lastUpdated: now,
      }));
      return;
    }

    // 3. Otherwise advance the active 5-stage pipeline cleanly
    void advanceStage(worldRef.current.currentStage).then((stageRes) => {
      const ts = Date.now();
      setWorld((prev) => ({
        ...prev,
        currentStage: stageRes.stageLabel,
        messages: [
          ...prev.messages,
          {
            id: `ok-stage-${ts}`,
            role: 'system',
            text:
              prev.language === 'hi'
                ? `OK · पाइपलाइन स्टेज आगे बढ़ा: ${stageRes.stageLabel}`
                : `OK · Advanced pipeline to Stage ${stageRes.stageLabel}.`,
            timestamp: ts,
            botRef: 'code',
          },
        ],
        lastUpdated: ts,
      }));
    });
  }, [handleKeepAllEdits, handleSelectAssetCommand, pendingAIEdit]);

  const handleAdminPushComplete = useCallback(
    (result: AtomicPushToGitHubResult) => {
      const now = Date.now();
      setRecoverableJob(loadUnfinishedJob());
      if (!result.ok) {
        setWorld((prev) => ({
          ...prev,
          messages: [
            ...prev.messages,
            {
              id: `export-err-${now}`,
              role: 'system',
              text: `GitHub 1-Commit Export failed: ${result.error || 'Unknown error'}`,
              timestamp: now,
              botRef: 'github',
            },
          ],
          lastUpdated: now,
        }));
        return;
      }

      setWorld((prev) => {
        const mergedFiles = [...prev.files];
        const generatedList = [
          result.generatedAdminFile,
          result.workflowFile,
        ].filter((f): f is VirtualFile => Boolean(f));

        for (const genFile of generatedList) {
          const idx = mergedFiles.findIndex(
            (f) => f.path.toLowerCase() === genFile.path.toLowerCase()
          );
          if (idx >= 0) {
            mergedFiles[idx] = genFile;
          } else {
            mergedFiles.push(genFile);
          }
        }

        return {
          ...prev,
          files: mergedFiles,
          currentStage: '5. Package',
          messages: [
            ...prev.messages,
            {
              id: `export-ok-${now}`,
              role: 'system',
              text:
                prev.language === 'hi'
                  ? `1-कमिट एक्सपोर्ट सफल (${result.commitSha.slice(0, 7)}) · ${result.filesPushed} फ़ाइलें ${result.repo}@${result.branch} पर पुश की गईं।`
                  : `1-Commit Export pushed (${result.commitSha.slice(0, 7)}) · ${result.filesPushed} files to ${result.repo}@${result.branch}.`,
              timestamp: now,
              botRef: 'github',
            },
          ],
          lastUpdated: now,
        };
      });
    },
    []
  );

  const handleAdminHealComplete = useCallback(
    (result: CheckAndHealGitHubRunResult) => {
      const now = Date.now();
      setRecoverableJob(loadUnfinishedJob());
      setWorld((prev) => ({
        ...prev,
        files:
          result.status === 'healed' ? result.healedFiles : prev.files,
        messages: [
          ...prev.messages,
          {
            id: `heal-res-${now}`,
            role: 'system',
            text: `[Self-Heal] ${result.summary}`,
            timestamp: now,
            botRef: 'github',
          },
        ],
        lastUpdated: now,
      }));
    },
    []
  );

  const handleGoHome = useCallback(() => {
    studioBus.emit('ui:panel', { panel: 'none' });
    studioBus.emit('world:update', {
      patch: {
        displayMode: 'expanded',
      },
      source: 'home-button',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleDismissRecoverableJob = useCallback(() => {
    clearActiveJob();
    setRecoverableJob(null);
  }, []);

  const handleAutoResumeJob = useCallback(async () => {
    if (!recoverableJob || isAutoResuming) return;
    setIsAutoResuming(true);
    try {
      const stageNum = parseStageNumber(recoverableJob.stage);
      setStudioPipelineStage(stageNum);
      if (worldRef.current.paused) {
        resumeStudioPipeline(recoverableJob.stage);
      }

      const now = Date.now();
      // Preserve all WorldState.files and selectedAssets cleanly while resuming
      if (
        recoverableJob.targetRepo &&
        (recoverableJob.status === 'exporting' ||
          recoverableJob.status === 'polling' ||
          recoverableJob.status === 'healing')
      ) {
        const healRes = await checkAndHealGitHubRun({
          targetRepo: recoverableJob.targetRepo,
          githubPat: worldRef.current.secrets.githubToken,
          files: worldRef.current.files,
          state: worldRef.current,
        });

        setWorld((prev) => ({
          ...prev,
          files:
            healRes.status === 'healed' ? healRes.healedFiles : prev.files,
          currentStage: recoverableJob.stage,
          paused: false,
          messages: [
            ...prev.messages,
            {
              id: `resume-job-${now}`,
              role: 'system',
              text: `[Auto-Resume · ${recoverableJob.title}] ${healRes.summary}`,
              timestamp: now,
              botRef: 'github',
            },
          ],
          lastUpdated: now,
        }));

        if (healRes.status === 'success' || healRes.status === 'healed') {
          clearActiveJob();
          setRecoverableJob(null);
        } else {
          setRecoverableJob(loadUnfinishedJob());
        }
      } else {
        setWorld((prev) => ({
          ...prev,
          currentStage: recoverableJob.stage,
          paused: false,
          messages: [
            ...prev.messages,
            {
              id: `resume-job-${now}`,
              role: 'system',
              text:
                prev.language === 'hi'
                  ? `ऑटो-रिज़्यूम पूरा: "${recoverableJob.title}" (${recoverableJob.stage}) — सभी ${prev.files.length} फ़ाइलें और ${prev.selectedAssets.length} एसेट सुरक्षित हैं।`
                  : `Auto-Resumed "${recoverableJob.title}" at ${recoverableJob.stage} — all ${prev.files.length} files & ${prev.selectedAssets.length} assets preserved.`,
              timestamp: now,
              botRef: 'code',
            },
          ],
          lastUpdated: now,
        }));
        clearActiveJob();
        setRecoverableJob(null);
      }
    } finally {
      setIsAutoResuming(false);
    }
  }, [isAutoResuming, recoverableJob]);

  const activeFile =
    world.files.find((f) => f.path === activeFilePath) ?? world.files[0] ?? null;

  return (
    <div className="min-h-[100dvh] w-full max-w-[100vw] overflow-x-hidden flex flex-col">
      <TopBar
        language={world.language}
        mode={world.mode}
        targetEngine={world.targetEngine}
        projectsCount={projects.length}
        onLanguageChange={handleLanguageChange}
        onModeChange={handleModeChange}
        onEngineChange={handleEngineChange}
        onOpenProjects={() => setProjectsModalOpen(true)}
      />

      <main className="flex-1 w-full max-w-5xl mx-auto px-2.5 sm:px-5 pt-3 pb-[118px] sm:pb-[126px]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-start">
          <div className="lg:col-span-5 min-w-0 flex flex-col gap-3">
            <DisplayViewport
              displayMode={world.displayMode}
              currentStage={world.currentStage}
              targetEngine={world.targetEngine}
              language={world.language}
              projectName={world.projectName}
              paused={world.paused}
              liveActive={world.liveActive}
              activeFile={activeFile}
              files={world.files}
              filesCount={world.files.length}
              assetsCount={world.selectedAssets.length}
              candidateAssets={candidateAssets}
              selectedAssets={world.selectedAssets}
              geminiApiKey={world.secrets.geminiApiKey}
              keyPool={world.secrets.keyPool}
              geminiTtsModel={world.secrets.geminiTtsModel}
              voiceSpeed={world.voiceSpeed}
              broadcastSession={broadcastSession}
              onDisplayModeChange={handleDisplayModeChange}
              onStageChange={handleStageChange}
              onAdvanceStage={handleAdvanceStage}
              onOpenCode={() => handleSelectPanel('code')}
              onBuild3DGame={() => {
                void handleBuild3DGame();
              }}
              isBuilding3DGame={isBuilding3DGame}
              onBuildCommercialApp={() => {
                void handleBuildCommercialApp();
              }}
              isBuildingCommercialApp={isBuildingCommercialApp}
              onCreateBroadcast={() => {
                void handleCreateBroadcast();
              }}
              isCreatingBroadcast={isCreatingBroadcast}
              onFixPreviewError={(errMsg) => {
                void handleFixPreviewError(errMsg);
              }}
              isFixingPreviewError={isAIEditing}
              previewVerifyState={previewVerifyState}
              liveConnectionLabel={liveConnectionLabel}
              onKeepAsset={handleKeepAsset}
              onRejectAsset={handleRejectAsset}
              onRemoveSelectedAsset={handleRemoveSelectedAsset}
            />

            <FileDrawer
              files={world.files}
              activeFilePath={activeFilePath}
              language={world.language}
              isCloning={isCloningRepo}
              cloneNotice={cloneNotice}
              onSelectFile={handleSelectFileAndOpenCode}
              onCreateFile={handleCreateFile}
              onDeleteFile={handleDeleteFile}
              onCloneRepo={(repoUrl) => {
                void handleCloneRepo(repoUrl);
              }}
            />
          </div>

          <div className="lg:col-span-7 min-w-0">
            <CommandCenter
              language={world.language}
              mode={world.mode}
              paused={world.paused}
              liveActive={world.liveActive}
              voicePhase={voicePhase}
              liveModel={liveModel}
              isThinking={isThinking}
              voiceReplyEnabled={voiceReplyEnabled}
              handsFreeLoop={handsFreeLoop}
              isDictating={isDictating}
              interimTranscript={interimTranscript}
              isCloudSpeaking={isCloudSpeaking}
              memoryCount={world.memoryRules.length}
              skillsCount={dynamicSkills.length}
              preferredBrain={world.secrets.preferredBrain ?? 'auto'}
              recoverableJob={recoverableJob}
              isAutoResuming={isAutoResuming}
              bots={world.bots}
              voicePersona={world.voicePersona}
              voiceSpeed={world.voiceSpeed}
              messages={world.messages}
              onToggleLive={handleToggleLive}
              onToggleVoiceReply={handleToggleVoiceReply}
              onToggleHandsFreeLoop={handleToggleHandsFreeLoop}
              onStopSpeech={handleStopSpeech}
              onToggleDictation={handleToggleDictation}
              onOpenMemory={() => setMemoryModalOpen(true)}
              onOpenBotMesh={() => setBotMeshModalOpen(true)}
              onPreferredBrainChange={handlePreferredBrainChange}
              onAutoResumeJob={() => {
                void handleAutoResumeJob();
              }}
              onDismissRecoverableJob={handleDismissRecoverableJob}
              onBotTap={handleBotTap}
              onVoiceChange={handleVoiceChange}
              onSendMessage={(msg) => {
                void handleSendMessage(msg, false);
              }}
              onSendStepToBuilder={handleSendStepToBuilder}
              onReplayMessage={handleReplayMessage}
              onApproveGate={handleApproveGate}
              onRequestGateChange={handleRequestGateChange}
            />
          </div>
        </div>
      </main>

      <CodePanel
        open={world.activePanel === 'code'}
        projectName={world.projectName}
        files={world.files}
        activeFilePath={activeFilePath}
        language={world.language}
        pendingAIEdit={pendingAIEdit}
        isAIEditing={isAIEditing}
        aiEditError={aiEditError}
        queuedBuilderPrompt={queuedBuilderPrompt}
        isBuildingStep={isBuildingStep}
        builderStage={builderStage}
        builderStageTrail={builderStageTrail}
        builderResultNote={builderResultNote}
        builderCheckpoints={builderCheckpoints}
        previewVerifyState={previewVerifyState}
        onClearQueuedBuilderPrompt={() => setQueuedBuilderPrompt(null)}
        onRunStudioBuilder={(prompt) => {
          void handleRunStudioBuilder(prompt);
        }}
        onRestoreCheckpoint={handleRestoreBuilderCheckpoint}
        onDownloadZip={handleDownloadProjectZip}
        onPreviewDisplayA={handlePreviewDisplayA}
        onSelectFile={setActiveFilePath}
        onSaveFile={handleSaveFile}
        onRunAIEdit={(instruction) => {
          void handleRunAIEdit(instruction);
        }}
        onKeepAllEdits={handleKeepAllEdits}
        onRevertAIEdit={handleRevertAIEdit}
        onClose={() => handleSelectPanel('none')}
      />

      <SecretsPanel
        open={world.activePanel === 'secrets'}
        secrets={world.secrets}
        language={world.language}
        onSave={handleSaveSecrets}
        onClose={() => handleSelectPanel('none')}
      />

      <VaultPanel
        open={world.activePanel === 'vault'}
        language={world.language}
        query={vaultQuery}
        selectedCategories={vaultCategories}
        isHunting={isHuntingAssets}
        result={vaultResult}
        candidateAssets={candidateAssets}
        selectedAssets={world.selectedAssets}
        vaultUrl={world.secrets.assetVaultUrl}
        onHunt={handleSearchAssets}
        onCategoriesChange={setVaultCategories}
        onKeepAsset={handleKeepAsset}
        onRejectAsset={handleRejectAsset}
        onRemoveSelectedAsset={handleRemoveSelectedAsset}
        onClose={() => handleSelectPanel('none')}
      />

      <CameraVisionPanel
        open={world.activePanel === 'camera'}
        language={world.language}
        secrets={world.secrets}
        memoryRules={world.memoryRules}
        liveActive={world.liveActive}
        onVisionMessage={handleVisionMessage}
        onOpenSecrets={() => handleSelectPanel('secrets')}
        onClose={() => handleSelectPanel('none')}
      />

      <AdminExportPanel
        open={world.activePanel === 'admin'}
        language={world.language}
        projectName={world.projectName}
        secrets={world.secrets}
        files={world.files}
        selectedAssets={world.selectedAssets}
        world={world}
        recoverableJob={recoverableJob}
        isAutoResuming={isAutoResuming}
        onAutoResumeJob={() => {
          void handleAutoResumeJob();
        }}
        onDismissRecoverableJob={handleDismissRecoverableJob}
        onOpenSecrets={() => handleSelectPanel('secrets')}
        onPushComplete={handleAdminPushComplete}
        onHealComplete={handleAdminHealComplete}
        onClose={() => handleSelectPanel('none')}
      />

      <MemoryRulesModal
        open={memoryModalOpen}
        rules={world.memoryRules}
        secrets={world.secrets}
        language={world.language}
        onAddRule={handleAddMemoryRule}
        onToggleRule={handleToggleMemoryRule}
        onDeleteRule={handleDeleteMemoryRule}
        onSyncComplete={handleSyncMemoryComplete}
        onClose={() => setMemoryModalOpen(false)}
      />

      <BotMeshModal
        open={botMeshModalOpen}
        language={world.language}
        paused={world.paused}
        secrets={world.secrets}
        skills={dynamicSkills}
        subBotRuns={subBotRuns}
        isSpawningSubBot={isSpawningSubBot}
        isFetchingApi={isFetchingApi}
        lastApiResult={lastApiResult}
        onSpawnSubBot={handleSpawnSubBot}
        onFetchApi={handleFetchAnyApi}
        onDeleteSkill={handleDeleteDynamicSkill}
        onSyncSkillsComplete={handleSyncSkillsComplete}
        onClose={() => setBotMeshModalOpen(false)}
      />

      <ProjectsModal
        open={projectsModalOpen}
        projects={projects}
        activeProjectId={activeProjectId}
        language={world.language}
        onCreateProject={handleCreateProject}
        onSwitchProject={handleSwitchProject}
        onDeleteProject={handleDeleteProject}
        onClose={() => setProjectsModalOpen(false)}
      />

      <BottomActionBar
        language={world.language}
        activePanel={world.activePanel}
        paused={world.paused}
        liveActive={world.liveActive}
        world={world}
        onSelectPanel={handleSelectPanel}
        onTogglePause={handleTogglePause}
        onToggleLive={handleToggleLive}
        onApproveOk={handleApproveOk}
        onOpenApk={() => handleSelectPanel('admin')}
        onGoHome={handleGoHome}
      />
    </div>
  );
}
