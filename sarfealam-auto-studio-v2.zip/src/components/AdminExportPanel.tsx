import { useEffect, useMemo, useState } from 'react';
import {
  ShieldCheck,
  X,
  CheckCircle2,
  AlertTriangle,
  KeyRound,
  Rocket,
  Wrench,
  Download,
  ExternalLink,
  QrCode,
  Eye,
  EyeOff,
  Loader2,
  Copy,
  Check,
  RotateCcw,
  Lock,
  Archive,
} from 'lucide-react';
import {
  atomicPushToGitHub,
  type AtomicPushToGitHubResult,
} from '../services/githubExportService';
import {
  checkAndHealGitHubRun,
  loadErrorMemory,
  type CheckAndHealGitHubRunResult,
} from '../services/selfHealingService';
import { parseGitHubRepoInput } from '../services/githubCloneService';
import { downloadProjectZip } from '../services/zipExportService';
import type { ActiveStudioJob } from '../services/jobPersistenceService';
import type {
  Language,
  StudioAssetItem,
  StudioSecrets,
  VirtualFile,
  WorldState,
} from '../types/studio';

const OWNER_PIN_STORAGE_KEY = 'sarfealam_owner_admin_pin_v2';
const RELEASE_META_STORAGE_KEY = 'sarfealam_release_meta_v2';

interface AdminExportPanelProps {
  open: boolean;
  language: Language;
  projectName: string;
  secrets: StudioSecrets;
  files: VirtualFile[];
  selectedAssets: StudioAssetItem[];
  world: WorldState;
  recoverableJob: ActiveStudioJob | null;
  isAutoResuming: boolean;
  onAutoResumeJob: () => void;
  onDismissRecoverableJob: () => void;
  onOpenSecrets: () => void;
  onPushComplete: (result: AtomicPushToGitHubResult) => void;
  onHealComplete: (result: CheckAndHealGitHubRunResult) => void;
  onClose: () => void;
}

type QrTarget = 'web' | 'admin' | 'apk';

function loadSavedPin(): string {
  try {
    const raw = window.localStorage.getItem(OWNER_PIN_STORAGE_KEY);
    if (raw && /^\d{4,6}$/.test(raw.trim())) {
      return raw.trim();
    }
  } catch {
    // ignore storage errors
  }
  return '2026';
}

function loadSavedVersion(): string {
  try {
    const raw = window.localStorage.getItem(RELEASE_META_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as { version?: string };
      if (typeof parsed.version === 'string' && parsed.version.trim()) {
        return parsed.version.trim();
      }
    }
  } catch {
    // ignore
  }
  return '1.0.0';
}

function resolveTargetRepo(secrets: StudioSecrets): string {
  if (secrets.targetRepo?.trim()) return secrets.targetRepo.trim();
  const owner = secrets.githubOwner?.trim() ?? '';
  const repo = secrets.githubRepo?.trim() ?? '';
  return owner && repo ? `${owner}/${repo}` : '';
}

function resolveActiveHtmlFile(files: VirtualFile[]): VirtualFile | null {
  const rootIndex = files.find((f) => f.path.toLowerCase() === 'index.html');
  const docsIndex = files.find(
    (f) => f.path.toLowerCase() === 'docs/index.html'
  );
  if (rootIndex && docsIndex) {
    return rootIndex.updatedAt >= docsIndex.updatedAt ? rootIndex : docsIndex;
  }
  return rootIndex ?? docsIndex ?? null;
}

export function AdminExportPanel({
  open,
  language,
  projectName,
  secrets,
  files,
  selectedAssets,
  world,
  recoverableJob,
  isAutoResuming,
  onAutoResumeJob,
  onDismissRecoverableJob,
  onOpenSecrets,
  onPushComplete,
  onHealComplete,
  onClose,
}: AdminExportPanelProps) {
  const [appName, setAppName] = useState(projectName || 'Sarfealam App');
  const [version, setVersion] = useState(() => loadSavedVersion());
  const [ownerPin, setOwnerPin] = useState(() => loadSavedPin());
  const [showPin, setShowPin] = useState(false);

  const [isPushing, setIsPushing] = useState(false);
  const [isHealing, setIsHealing] = useState(false);
  const [pushResult, setPushResult] =
    useState<AtomicPushToGitHubResult | null>(null);
  const [healResult, setHealResult] =
    useState<CheckAndHealGitHubRunResult | null>(null);
  const [downloadNote, setDownloadNote] = useState<string | null>(null);
  const [zipJustSaved, setZipJustSaved] = useState(false);

  const [qrOpen, setQrOpen] = useState(false);
  const [qrTarget, setQrTarget] = useState<QrTarget>('web');
  const [qrImgFailed, setQrImgFailed] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  useEffect(() => {
    if (projectName && projectName.trim()) {
      setAppName(projectName.trim());
    }
  }, [projectName]);

  useEffect(() => {
    const cleaned = ownerPin.replace(/\D/g, '').slice(0, 6);
    if (cleaned.length >= 4) {
      try {
        window.localStorage.setItem(OWNER_PIN_STORAGE_KEY, cleaned);
      } catch {
        // ignore storage quota errors
      }
    }
  }, [ownerPin]);

  useEffect(() => {
    if (version.trim()) {
      try {
        window.localStorage.setItem(
          RELEASE_META_STORAGE_KEY,
          JSON.stringify({ version: version.trim() })
        );
      } catch {
        // ignore
      }
    }
  }, [version]);

  const targetRepo = resolveTargetRepo(secrets);
  const parsedRepo = useMemo(
    () => parseGitHubRepoInput(targetRepo),
    [targetRepo]
  );

  // Pre-Flight 5-Pill Readiness Check
  const preflightItems = useMemo(() => {
    const hasAiKey = Boolean(
      secrets.geminiApiKey?.trim() ||
        secrets.groqApiKey?.trim() ||
        secrets.nvidiaApiKey?.trim() ||
        secrets.openRouterApiKey?.trim() ||
        secrets.cohereApiKey?.trim()
    );
    const hasGithubPat = Boolean(secrets.githubToken?.trim() && parsedRepo);
    const hasAssetVault = Boolean(
      secrets.assetVaultUrl?.trim() || selectedAssets.length > 0
    );
    // STRICT ISOLATION: Apps Supabase ONLY (never Studio Supabase)
    const hasAppsSupabase = Boolean(
      secrets.appsSupabaseUrl?.trim() && secrets.appsSupabaseAnonKey?.trim()
    );
    const hasIndexHtml = Boolean(resolveActiveHtmlFile(files));

    return [
      { id: 'ai', label: 'AI Keys', ready: hasAiKey },
      { id: 'github', label: 'GitHub PAT', ready: hasGithubPat },
      { id: 'vault', label: 'Asset Vault', ready: hasAssetVault },
      { id: 'apps-supa', label: 'Apps Supabase', ready: hasAppsSupabase },
      { id: 'html', label: 'index.html', ready: hasIndexHtml },
    ];
  }, [files, parsedRepo, secrets, selectedAssets.length]);

  const missingCount = preflightItems.filter((item) => !item.ready).length;

  // Derived or freshly pushed release URLs
  const releaseLinks = useMemo(() => {
    if (pushResult?.ok) {
      return {
        pagesUrl: pushResult.pagesUrl,
        adminUrl: pushResult.adminUrl,
        actionsUrl: pushResult.actionsUrl,
        apkReleaseUrl: pushResult.apkReleaseUrl,
        commitSha: pushResult.commitSha,
      };
    }
    if (parsedRepo) {
      const base = `https://${parsedRepo.owner.toLowerCase()}.github.io/${parsedRepo.repo}`;
      return {
        pagesUrl: `${base}/`,
        adminUrl: `${base}/admin.html`,
        actionsUrl: `https://github.com/${parsedRepo.owner}/${parsedRepo.repo}/actions`,
        apkReleaseUrl: `https://github.com/${parsedRepo.owner}/${parsedRepo.repo}/releases`,
        commitSha: '',
      };
    }
    return null;
  }, [parsedRepo, pushResult]);

  const activeQrUrl = useMemo(() => {
    if (!releaseLinks) return '';
    if (qrTarget === 'admin') return releaseLinks.adminUrl;
    if (qrTarget === 'apk') return releaseLinks.apkReleaseUrl;
    return releaseLinks.pagesUrl;
  }, [qrTarget, releaseLinks]);

  const qrImageSrc = activeQrUrl
    ? `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(
        activeQrUrl
      )}`
    : '';

  useEffect(() => {
    setQrImgFailed(false);
    setCopiedUrl(false);
  }, [activeQrUrl, qrOpen]);

  if (!open) return null;

  const pinValid = /^\d{4,6}$/.test(ownerPin.trim());
  const errorMemoryCount = loadErrorMemory().length;

  const handleBuildAndPush = async () => {
    if (isPushing) return;
    if (!pinValid) {
      setPushResult({
        ok: false,
        commitSha: '',
        repo: targetRepo,
        branch: 'main',
        pagesUrl: '',
        adminUrl: '',
        actionsUrl: '',
        apkReleaseUrl: '',
        filesPushed: 0,
        error: 'Enter a 4–6 digit Owner Admin PIN before pushing.',
      });
      return;
    }

    setIsPushing(true);
    setPushResult(null);
    try {
      const res = await atomicPushToGitHub({
        files,
        appName: appName.trim() || 'Sarfealam App',
        version: version.trim() || '1.0.0',
        ownerPin: ownerPin.trim(),
        secrets,
      });
      setPushResult(res);
      onPushComplete(res);
    } finally {
      setIsPushing(false);
    }
  };

  const handleCheckAndHeal = async () => {
    if (isHealing) return;
    setIsHealing(true);
    setHealResult(null);
    try {
      const res = await checkAndHealGitHubRun({
        targetRepo,
        githubPat: secrets.githubToken,
        files,
        state: world,
      });
      setHealResult(res);
      onHealComplete(res);
    } finally {
      setIsHealing(false);
    }
  };

  const handleDownloadLocalHtml = () => {
    const htmlFile = resolveActiveHtmlFile(files);
    if (!htmlFile) {
      setDownloadNote('No index.html found in virtual workspace.');
      return;
    }
    const slug =
      (appName.trim() || 'sarfealam-app')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '') || 'sarfealam-app';
    const fileName = `${slug}-v${(version.trim() || '1.0.0').replace(/[^a-zA-Z0-9._-]/g, '')}.html`;
    try {
      const blob = new Blob([htmlFile.content], {
        type: 'text/html;charset=utf-8',
      });
      const blobUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = fileName;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1500);
      setDownloadNote(`Downloaded ${fileName} (${htmlFile.path}).`);
    } catch {
      setDownloadNote('Unable to trigger local .html download on this device.');
    }
  };

  const handleDownloadProjectZip = () => {
    const res = downloadProjectZip(
      appName.trim() || projectName || 'sarfealam-app',
      files
    );
    if (res.ok) {
      setZipJustSaved(true);
      window.setTimeout(() => setZipJustSaved(false), 2000);
      setDownloadNote(
        `Downloaded ${res.fileName} (${res.fileCount} file${
          res.fileCount === 1 ? '' : 's'
        }).`
      );
    } else {
      setDownloadNote(res.error || 'Unable to generate project .ZIP.');
    }
  };

  const handleCopyQrUrl = async () => {
    if (!activeQrUrl) return;
    try {
      await navigator.clipboard.writeText(activeQrUrl);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 1800);
    } catch {
      // Ignore clipboard permission errors
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Owner Admin and APK Release Hub"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-lg mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[90dvh] sm:max-h-[86dvh] overflow-hidden"
      >
        {/* Drag Handle (mobile) */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#5856D6] via-[#007AFF] to-[#10B981] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                Admin &amp; APK Release Hub
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate tabular-nums">
                1-Commit GitHub Exporter · {files.length} files · {errorMemoryCount} error_memory
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Admin and APK Release Hub"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Sheet Body */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3.5 sm:px-5 pt-3 pb-8 flex flex-col gap-3">
          {/* Resume Last Job Banner (if unfinished job detected) */}
          {recoverableJob && (
            <div
              role="status"
              className="rounded-2xl bg-gradient-to-r from-[#007AFF]/10 via-[#5856D6]/10 to-[#10B981]/10 border border-[#007AFF]/30 p-2.5 flex flex-wrap items-center justify-between gap-2"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[11.5px] font-bold text-[#0F172A] truncate">
                  {language === 'hi'
                    ? `अधूरा जॉब: ${recoverableJob.title}`
                    : `Resume Last Job: ${recoverableJob.title}`}
                </p>
                <p className="text-[10.5px] text-[#475569] truncate">
                  {recoverableJob.stage} · {recoverableJob.status}
                  {recoverableJob.targetRepo ? ` · ${recoverableJob.targetRepo}` : ''}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={onAutoResumeJob}
                  disabled={isAutoResuming}
                  className="h-7 px-2.5 rounded-lg bg-[#007AFF] hover:brightness-105 disabled:opacity-55 text-white text-[10.5px] font-bold inline-flex items-center gap-1 cursor-pointer active:scale-95 whitespace-nowrap"
                >
                  {isAutoResuming ? (
                    <Loader2 className="w-3 h-3 animate-spin" aria-hidden="true" />
                  ) : (
                    <RotateCcw className="w-3 h-3" aria-hidden="true" />
                  )}
                  <span>{isAutoResuming ? 'Resuming...' : 'Resume'}</span>
                </button>
                <button
                  type="button"
                  onClick={onDismissRecoverableJob}
                  aria-label="Dismiss unfinished job"
                  className="w-7 h-7 rounded-lg bg-white/80 hover:bg-white text-[#64748B] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-3 h-3" aria-hidden="true" />
                </button>
              </div>
            </div>
          )}

          {/* 1. Pre-Flight Readiness Check (5-Pill Strip) */}
          <section
            aria-label="Pre-Flight Readiness Check"
            className="rounded-2xl bg-white/90 border border-slate-200/85 shadow-[0_3px_14px_rgba(15,23,42,0.04)] p-3 flex flex-col gap-2"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[12px] font-bold text-[#0F172A]">
                Pre-Flight Readiness Check
              </span>
              {missingCount > 0 ? (
                <button
                  type="button"
                  onClick={onOpenSecrets}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-[#F59E0B]/14 hover:bg-[#F59E0B]/22 text-[#B45309] border border-[#F59E0B]/30 text-[10.5px] font-bold transition-all cursor-pointer active:scale-95 whitespace-nowrap shrink-0"
                >
                  <KeyRound className="w-3 h-3 shrink-0" aria-hidden="true" />
                  <span>Open Secrets</span>
                </button>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#10B981]/12 text-[#047857] text-[10.5px] font-bold whitespace-nowrap shrink-0">
                  <CheckCircle2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                  <span>All 5 Ready</span>
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {preflightItems.map((item) => (
                <span
                  key={item.id}
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-full border text-[10.5px] font-semibold whitespace-nowrap ${
                    item.ready
                      ? 'bg-[#10B981]/12 text-[#047857] border-[#10B981]/30'
                      : 'bg-[#F59E0B]/14 text-[#B45309] border-[#F59E0B]/30'
                  }`}
                >
                  {item.ready ? (
                    <CheckCircle2 className="w-3 h-3 shrink-0 text-[#10B981]" aria-hidden="true" />
                  ) : (
                    <AlertTriangle className="w-3 h-3 shrink-0 text-[#D97706]" aria-hidden="true" />
                  )}
                  <span>{item.label}</span>
                  <span className="opacity-80">
                    · {item.ready ? 'Ready' : 'Missing'}
                  </span>
                </span>
              ))}
            </div>
          </section>

          {/* 2. App Release & Owner PIN Form */}
          <section
            aria-label="App Release and Owner PIN"
            className="rounded-2xl bg-white/90 border border-slate-200/85 shadow-[0_3px_14px_rgba(15,23,42,0.04)] p-3 flex flex-col gap-2.5"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[12px] font-bold text-[#0F172A]">
                App Release &amp; Owner PIN
              </span>
              <span className="text-[10.5px] font-mono text-[#64748B] truncate max-w-[165px]">
                {parsedRepo ? parsedRepo.normalized : 'Set Repo in Secrets'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="sm:col-span-2 flex flex-col gap-1">
                <label
                  htmlFor="admin-release-appname"
                  className="text-[10.5px] font-semibold text-[#64748B]"
                >
                  App Name
                </label>
                <input
                  id="admin-release-appname"
                  type="text"
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  placeholder="Sarfealam App"
                  className="w-full h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12.5px] font-medium text-[#0F172A] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label
                  htmlFor="admin-release-version"
                  className="text-[10.5px] font-semibold text-[#64748B]"
                >
                  Version
                </label>
                <input
                  id="admin-release-version"
                  type="text"
                  value={version}
                  onChange={(e) => setVersion(e.target.value)}
                  placeholder="1.0.0"
                  className="w-full h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12.5px] font-mono text-[#0F172A] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="admin-owner-pin"
                  className="text-[10.5px] font-semibold text-[#64748B] inline-flex items-center gap-1"
                >
                  <Lock className="w-3 h-3 text-[#5856D6]" aria-hidden="true" />
                  <span>Owner Admin PIN (4–6 digits · locks docs/admin.html)</span>
                </label>
                {!pinValid && (
                  <span className="text-[10px] font-semibold text-[#FF3B30]">
                    4–6 digits required
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  id="admin-owner-pin"
                  type={showPin ? 'text' : 'password'}
                  inputMode="numeric"
                  maxLength={6}
                  value={ownerPin}
                  onChange={(e) =>
                    setOwnerPin(e.target.value.replace(/\D/g, '').slice(0, 6))
                  }
                  placeholder="2026"
                  className="flex-1 min-w-0 h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[13px] font-mono tracking-widest text-[#0F172A] focus:outline-none focus:border-[#5856D6] focus:ring-2 focus:ring-[#5856D6]/15"
                />
                <button
                  type="button"
                  onClick={() => setShowPin((prev) => !prev)}
                  aria-label={showPin ? 'Hide Owner PIN' : 'Show Owner PIN'}
                  className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-[#475569] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                >
                  {showPin ? (
                    <EyeOff className="w-4 h-4" aria-hidden="true" />
                  ) : (
                    <Eye className="w-4 h-4" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>

            {/* 3. Primary Action Buttons: Build & Push APK + Download Project .ZIP side by side */}
            <div className="grid grid-cols-2 gap-1.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  void handleBuildAndPush();
                }}
                disabled={isPushing || isHealing}
                className="h-10 px-2.5 rounded-xl bg-gradient-to-r from-[#007AFF] via-[#5856D6] to-[#10B981] hover:brightness-105 disabled:opacity-55 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1 shadow-[0_4px_14px_rgba(0,122,255,0.26)] transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap min-w-0"
              >
                {isPushing ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Rocket className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span className="truncate">
                  {isPushing ? 'Pushing...' : 'Build & Push APK'}
                </span>
              </button>

              <button
                type="button"
                onClick={handleDownloadProjectZip}
                disabled={files.length === 0}
                className="h-10 px-2.5 rounded-xl bg-white hover:bg-slate-50 disabled:opacity-45 text-[#0F172A] border border-[#007AFF]/30 text-[11.5px] font-bold inline-flex items-center justify-center gap-1 shadow-2xs transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap min-w-0"
              >
                {zipJustSaved ? (
                  <Check className="w-3.5 h-3.5 text-[#10B981] shrink-0" aria-hidden="true" />
                ) : (
                  <Archive className="w-3.5 h-3.5 text-[#007AFF] shrink-0" aria-hidden="true" />
                )}
                <span className="truncate">
                  {zipJustSaved ? 'ZIP Saved ✓' : 'Download Project .ZIP'}
                </span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => {
                  void handleCheckAndHeal();
                }}
                disabled={isHealing || isPushing}
                className="h-9 px-2.5 rounded-xl bg-[#5856D6]/12 hover:bg-[#5856D6]/20 disabled:opacity-55 text-[#5856D6] border border-[#5856D6]/30 text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap min-w-0"
              >
                {isHealing ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Wrench className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span className="truncate">
                  {isHealing ? 'Checking...' : 'Check & Self-Heal'}
                </span>
              </button>

              <button
                type="button"
                onClick={handleDownloadLocalHtml}
                className="h-9 px-2.5 rounded-xl bg-slate-100/90 hover:bg-slate-200/80 text-[#0F172A] border border-slate-200/85 text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap min-w-0"
              >
                <Download className="w-3.5 h-3.5 text-[#007AFF] shrink-0" aria-hidden="true" />
                <span className="truncate">Download Local .html</span>
              </button>
            </div>

            {/* Feedback Status Banners */}
            {pushResult && (
              <div
                className={`rounded-xl border px-2.5 py-2 text-[11px] font-semibold flex items-start gap-1.5 ${
                  pushResult.ok
                    ? 'bg-[#10B981]/10 border-[#10B981]/30 text-[#047857]'
                    : 'bg-[#FF3B30]/10 border-[#FF3B30]/25 text-[#DC2626]'
                }`}
              >
                {pushResult.ok ? (
                  <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" aria-hidden="true" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" aria-hidden="true" />
                )}
                <span className="break-words">
                  {pushResult.ok
                    ? `Atomic commit ${pushResult.commitSha.slice(0, 7)} pushed (${pushResult.filesPushed} files) to ${pushResult.repo}@${pushResult.branch}.`
                    : pushResult.error || 'GitHub export failed.'}
                </span>
              </div>
            )}

            {healResult && (
              <div
                className={`rounded-xl border px-2.5 py-2 text-[11px] font-semibold flex items-start gap-1.5 ${
                  healResult.status === 'success' || healResult.status === 'healed'
                    ? 'bg-[#10B981]/10 border-[#10B981]/30 text-[#047857]'
                    : healResult.status === 'in_progress' || healResult.status === 'no_runs'
                      ? 'bg-[#007AFF]/10 border-[#007AFF]/25 text-[#0369A1]'
                      : 'bg-[#F59E0B]/14 border-[#F59E0B]/30 text-[#B45309]'
                }`}
              >
                <Wrench className="w-3.5 h-3.5 mt-0.5 shrink-0" aria-hidden="true" />
                <span className="break-words">{healResult.summary}</span>
              </div>
            )}

            {downloadNote && (
              <p className="text-[11px] font-semibold text-[#007AFF] px-1">
                {downloadNote}
              </p>
            )}
          </section>

          {/* 4. Release Links & Live QR Code */}
          <section
            aria-label="Release Links and Live QR Code"
            className="rounded-2xl bg-white/90 border border-slate-200/85 shadow-[0_3px_14px_rgba(15,23,42,0.04)] p-3 flex flex-col gap-2.5"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[12px] font-bold text-[#0F172A]">
                Release Links &amp; Live QR
              </span>
              <button
                type="button"
                onClick={() => setQrOpen((prev) => !prev)}
                disabled={!releaseLinks}
                className={`inline-flex items-center gap-1 px-2.5 h-7 rounded-lg border text-[10.5px] font-bold transition-all cursor-pointer active:scale-95 disabled:opacity-45 whitespace-nowrap shrink-0 ${
                  qrOpen
                    ? 'bg-[#007AFF] text-white border-[#007AFF]'
                    : 'bg-[#007AFF]/10 text-[#007AFF] border-[#007AFF]/25 hover:bg-[#007AFF]/16'
                }`}
              >
                <QrCode className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{qrOpen ? 'Hide QR' : 'QR Code'}</span>
              </button>
            </div>

            {!releaseLinks ? (
              <p className="text-[11.5px] text-[#64748B] leading-relaxed">
                {language === 'hi'
                  ? 'Live Web, PIN-Locked Owner Admin, Actions और APK Release लिंक देखने के लिए Secrets में Target Repo जोड़ें।'
                  : 'Configure a GitHub Target Repo in Secrets (and tap Build & Push APK) to generate Live Web, Owner Admin, Actions, and APK Release links.'}
              </p>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-1.5">
                  <a
                    href={releaseLinks.pagesUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl bg-[#007AFF]/8 hover:bg-[#007AFF]/14 border border-[#007AFF]/25 px-2.5 py-2 flex items-center justify-between gap-1.5 text-[11px] font-bold text-[#007AFF] transition-colors min-w-0"
                  >
                    <span className="truncate">Live Web Test</span>
                    <ExternalLink className="w-3 h-3 shrink-0" aria-hidden="true" />
                  </a>

                  <a
                    href={releaseLinks.adminUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl bg-[#5856D6]/8 hover:bg-[#5856D6]/14 border border-[#5856D6]/25 px-2.5 py-2 flex items-center justify-between gap-1.5 text-[11px] font-bold text-[#5856D6] transition-colors min-w-0"
                  >
                    <span className="truncate">PIN Owner Admin</span>
                    <ExternalLink className="w-3 h-3 shrink-0" aria-hidden="true" />
                  </a>

                  <a
                    href={releaseLinks.actionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl bg-[#F59E0B]/10 hover:bg-[#F59E0B]/18 border border-[#F59E0B]/30 px-2.5 py-2 flex items-center justify-between gap-1.5 text-[11px] font-bold text-[#B45309] transition-colors min-w-0"
                  >
                    <span className="truncate">GitHub Actions</span>
                    <ExternalLink className="w-3 h-3 shrink-0" aria-hidden="true" />
                  </a>

                  <a
                    href={releaseLinks.apkReleaseUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl bg-[#10B981]/10 hover:bg-[#10B981]/18 border border-[#10B981]/30 px-2.5 py-2 flex items-center justify-between gap-1.5 text-[11px] font-bold text-[#047857] transition-colors min-w-0"
                  >
                    <span className="truncate">APK Release</span>
                    <ExternalLink className="w-3 h-3 shrink-0" aria-hidden="true" />
                  </a>
                </div>

                {/* Toggleable QR Code Card with Offline Fallback */}
                {qrOpen && (
                  <div className="rounded-2xl bg-[#F6F9FE] border border-slate-200/85 p-3 flex flex-col items-center gap-2.5">
                    <div className="flex items-center gap-1 flex-wrap justify-center">
                      {(
                        [
                          { id: 'web', label: 'Live Web' },
                          { id: 'admin', label: 'Owner Admin' },
                          { id: 'apk', label: 'APK Release' },
                        ] as { id: QrTarget; label: string }[]
                      ).map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setQrTarget(tab.id)}
                          className={`px-2 py-0.5 rounded-lg text-[10.5px] font-semibold transition-all cursor-pointer ${
                            qrTarget === tab.id
                              ? 'bg-[#0F172A] text-white'
                              : 'bg-white text-[#64748B] border border-slate-200/80 hover:text-[#0F172A]'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>

                    {!qrImgFailed && qrImageSrc ? (
                      <div className="p-2 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
                        <img
                          src={qrImageSrc}
                          alt={`QR code for ${activeQrUrl}`}
                          width={160}
                          height={160}
                          loading="lazy"
                          onError={() => setQrImgFailed(true)}
                          className="w-40 h-40 rounded-lg block"
                        />
                      </div>
                    ) : (
                      <div className="w-full rounded-xl bg-white border border-dashed border-slate-300 p-3 text-center flex flex-col items-center gap-1">
                        <QrCode className="w-7 h-7 text-[#64748B]" aria-hidden="true" />
                        <p className="text-[11.5px] font-bold text-[#0F172A]">
                          Offline QR Fallback
                        </p>
                        <p className="text-[10.5px] text-[#64748B]">
                          Scan service unavailable offline — copy or open the URL below on your phone.
                        </p>
                      </div>
                    )}

                    <div className="w-full flex items-center gap-1.5">
                      <code className="flex-1 min-w-0 px-2 py-1.5 rounded-lg bg-white border border-slate-200/80 text-[10px] font-mono text-[#334155] truncate">
                        {activeQrUrl}
                      </code>
                      <button
                        type="button"
                        onClick={() => {
                          void handleCopyQrUrl();
                        }}
                        className="h-7 px-2 rounded-lg bg-white hover:bg-slate-100 border border-slate-200/85 text-[#0F172A] text-[10.5px] font-semibold inline-flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        {copiedUrl ? (
                          <Check className="w-3 h-3 text-[#10B981]" aria-hidden="true" />
                        ) : (
                          <Copy className="w-3 h-3" aria-hidden="true" />
                        )}
                        <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
