import { useEffect, useRef, useState, type FormEvent } from 'react';
import {
  Package,
  Code2,
  Eye,
  GitBranch,
  Send,
  Volume2,
  VolumeX,
  Mic,
  Pause,
  SlidersHorizontal,
  Loader2,
  Zap,
  AudioLines,
  Radio,
  Square,
  Brain,
  Cpu,
  RotateCcw,
  Repeat,
  X,
  Copy,
  Check,
  Rocket,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import type { ActiveStudioJob } from '../services/jobPersistenceService';
import {
  VOICE_PERSONAS,
  VOICE_SPEEDS,
  type BotId,
  type BotState,
  type Language,
  type LockedStepPlanItem,
  type PreferredBrain,
  type StudioMessage,
  type StudioMode,
  type VoicePersona,
  type VoicePhase,
} from '../types/studio';

const BRAIN_OPTIONS: {
  value: PreferredBrain;
  label: string;
  activeClass: string;
}[] = [
  {
    value: 'auto',
    label: 'Auto',
    activeClass: 'bg-gradient-to-r from-[#007AFF] to-[#5856D6] text-white border-transparent shadow-xs',
  },
  {
    value: 'groq',
    label: 'Groq',
    activeClass: 'bg-[#F59E0B] text-white border-[#F59E0B] shadow-xs',
  },
  {
    value: 'nvidia',
    label: 'NVIDIA',
    activeClass: 'bg-[#10B981] text-white border-[#10B981] shadow-xs',
  },
  {
    value: 'cloudflare',
    label: 'Cloudflare',
    activeClass: 'bg-[#F97316] text-white border-[#F97316] shadow-xs',
  },
  {
    value: 'gemini',
    label: 'Gemini',
    activeClass: 'bg-[#007AFF] text-white border-[#007AFF] shadow-xs',
  },
];

interface CommandCenterProps {
  language: Language;
  mode: StudioMode;
  paused: boolean;
  liveActive: boolean;
  voicePhase: VoicePhase;
  liveModel: string | null;
  isThinking: boolean;
  voiceReplyEnabled: boolean;
  handsFreeLoop: boolean;
  isDictating: boolean;
  interimTranscript: string;
  isCloudSpeaking: boolean;
  memoryCount: number;
  skillsCount: number;
  preferredBrain: PreferredBrain;
  recoverableJob?: ActiveStudioJob | null;
  isAutoResuming?: boolean;
  bots: Record<BotId, BotState>;
  voicePersona: VoicePersona;
  voiceSpeed: number;
  messages: StudioMessage[];
  onToggleLive: () => void;
  onToggleVoiceReply: () => void;
  onToggleHandsFreeLoop: () => void;
  onStopSpeech: () => void;
  onToggleDictation: () => void;
  onOpenMemory: () => void;
  onOpenBotMesh: () => void;
  onPreferredBrainChange: (brain: PreferredBrain) => void;
  onAutoResumeJob?: () => void;
  onDismissRecoverableJob?: () => void;
  onBotTap: (botId: BotId) => void;
  onVoiceChange: (persona: VoicePersona, speed: number) => void;
  onSendMessage: (text: string) => void;
  onSendStepToBuilder?: (step: LockedStepPlanItem) => void;
  onReplayMessage?: (text: string) => void;
  onApproveGate?: (msgId: string, nextPrompt: string) => void;
  onRequestGateChange?: (msgId: string) => void;
}

const BOT_META: {
  id: BotId;
  label: string;
  Icon: typeof Package;
  idleBg: string;
  activeBg: string;
  iconColor: string;
  ringColor: string;
}[] = [
  {
    id: 'asset',
    label: 'Asset',
    Icon: Package,
    idleBg: 'bg-[#10B981]/8 border-[#10B981]/25 hover:bg-[#10B981]/14',
    activeBg: 'bg-[#10B981] border-[#10B981] text-white',
    iconColor: 'text-[#10B981]',
    ringColor: 'focus-visible:ring-[#10B981]/40',
  },
  {
    id: 'code',
    label: 'Code',
    Icon: Code2,
    idleBg: 'bg-[#007AFF]/8 border-[#007AFF]/25 hover:bg-[#007AFF]/14',
    activeBg: 'bg-[#007AFF] border-[#007AFF] text-white',
    iconColor: 'text-[#007AFF]',
    ringColor: 'focus-visible:ring-[#007AFF]/40',
  },
  {
    id: 'vision',
    label: 'Vision',
    Icon: Eye,
    idleBg: 'bg-[#5856D6]/8 border-[#5856D6]/25 hover:bg-[#5856D6]/14',
    activeBg: 'bg-[#5856D6] border-[#5856D6] text-white',
    iconColor: 'text-[#5856D6]',
    ringColor: 'focus-visible:ring-[#5856D6]/40',
  },
  {
    id: 'github',
    label: 'GitHub',
    Icon: GitBranch,
    idleBg: 'bg-[#F59E0B]/10 border-[#F59E0B]/30 hover:bg-[#F59E0B]/16',
    activeBg: 'bg-[#F59E0B] border-[#F59E0B] text-white',
    iconColor: 'text-[#D97706]',
    ringColor: 'focus-visible:ring-[#F59E0B]/40',
  },
];

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatSpeed(speed: number): string {
  if (Number.isInteger(speed) || Math.round(speed * 10) === speed * 10) {
    return `${speed.toFixed(1)}x`;
  }
  return `${speed.toFixed(2)}x`;
}

function getProviderPillClass(provider: string): string {
  const lower = provider.toLowerCase();
  if (lower.includes('live')) {
    return 'bg-gradient-to-r from-[#10B981]/14 to-[#007AFF]/14 text-[#047857] border-[#10B981]/30';
  }
  if (lower.includes('gemini')) {
    return 'bg-[#007AFF]/10 text-[#007AFF] border-[#007AFF]/25';
  }
  if (lower.includes('groq')) {
    return 'bg-[#F59E0B]/12 text-[#B45309] border-[#F59E0B]/25';
  }
  if (lower.includes('nvidia')) {
    return 'bg-[#10B981]/12 text-[#047857] border-[#10B981]/25';
  }
  if (lower.includes('cloudflare')) {
    return 'bg-[#F97316]/12 text-[#C2410C] border-[#F97316]/25';
  }
  if (lower.includes('openrouter')) {
    return 'bg-[#5856D6]/10 text-[#5856D6] border-[#5856D6]/25';
  }
  if (lower.includes('cohere')) {
    return 'bg-[#FF3B30]/10 text-[#DC2626] border-[#FF3B30]/25';
  }
  return 'bg-slate-100 text-[#475569] border-slate-200/80';
}

export function CommandCenter({
  language,
  mode,
  paused,
  liveActive,
  voicePhase,
  liveModel,
  isThinking,
  voiceReplyEnabled,
  handsFreeLoop,
  isDictating,
  interimTranscript,
  isCloudSpeaking,
  memoryCount,
  skillsCount,
  preferredBrain,
  recoverableJob,
  isAutoResuming,
  bots,
  voicePersona,
  voiceSpeed,
  messages,
  onToggleLive,
  onToggleVoiceReply,
  onToggleHandsFreeLoop,
  onStopSpeech,
  onToggleDictation,
  onOpenMemory,
  onOpenBotMesh,
  onPreferredBrainChange,
  onAutoResumeJob,
  onDismissRecoverableJob,
  onBotTap,
  onVoiceChange,
  onSendMessage,
  onSendStepToBuilder,
  onReplayMessage,
  onApproveGate,
  onRequestGateChange,
}: CommandCenterProps) {
  const [input, setInput] = useState('');
  const [voiceMenuOpen, setVoiceMenuOpen] = useState(false);
  const [copiedStepKey, setCopiedStepKey] = useState<string | null>(null);
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({});
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);

  const handleCopyStepPrompt = async (stepKey: string, promptText: string) => {
    try {
      await navigator.clipboard.writeText(promptText);
    } catch {
      const el = document.createElement('textarea');
      el.value = promptText;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
    setCopiedStepKey(stepKey);
    window.setTimeout(() => {
      setCopiedStepKey((prev) => (prev === stepKey ? null : prev));
    }, 1800);
  };

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, isThinking]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isThinking) return;
    onSendMessage(trimmed);
    setInput('');
  };

  const effectivePhase: VoicePhase = isThinking
    ? 'thinking'
    : isCloudSpeaking
      ? 'speaking'
      : isDictating
        ? 'listening'
        : liveActive
          ? voicePhase === 'idle'
            ? 'listening'
            : voicePhase
          : voicePhase;

  const orbStateLabel =
    effectivePhase === 'speaking'
      ? language === 'hi'
        ? 'JARVIS बोल रहा है...'
        : 'JARVIS Speaking...'
      : effectivePhase === 'thinking'
        ? language === 'hi'
          ? 'JARVIS सोच रहा है...'
          : 'JARVIS Thinking...'
        : effectivePhase === 'listening'
          ? isDictating
            ? language === 'hi'
              ? 'डिक्टेशन चालू · बोलें...'
              : 'Dictating · Speak now...'
            : paused
              ? language === 'hi'
                ? 'रुका हुआ · वॉइस लाइव है'
                : 'Paused · Voice Live'
              : language === 'hi'
                ? 'सुन रहा है · कभी भी बोलें'
                : 'Listening · Speak anytime'
          : paused
            ? language === 'hi'
              ? 'इंस्पेक्ट मोड (रुका हुआ)'
              : 'Paused · Inspect Mode'
            : mode === 'jarvis'
              ? language === 'hi'
                ? 'JARVIS तैयार है'
                : 'JARVIS Ready'
              : language === 'hi'
                ? 'मैनुअल मोड'
                : 'Manual Standby';

  const displayedInputValue =
    isDictating && interimTranscript ? interimTranscript : input;

  return (
    <section
      aria-label="JARVIS Signal Hub and Command Center"
      className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_8px_30px_rgba(15,23,42,0.06)] rounded-2xl p-3 sm:p-4 flex flex-col gap-2.5 sm:gap-3"
    >
      {/* Top Signal Hub: Colorful Apple-Gradient JARVIS Core Orb + Status */}
      <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
        {/* JARVIS Core Orb — distinct animations for listening, thinking, speaking */}
        <button
          type="button"
          onClick={isCloudSpeaking ? onStopSpeech : onToggleLive}
          aria-label={
            isCloudSpeaking
              ? 'Stop voice playback'
              : liveActive
                ? 'Stop Gemini Live Voice'
                : 'Start Gemini Live Voice'
          }
          aria-pressed={liveActive}
          className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center shrink-0 cursor-pointer group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#007AFF] focus-visible:ring-offset-2 active:scale-95 transition-transform"
        >
          {/* Outer ambient halo */}
          <span
            aria-hidden="true"
            className={`absolute -inset-1 rounded-full blur-md transition-all duration-300 ${
              effectivePhase === 'speaking'
                ? 'orb-speak-pulse bg-gradient-to-tr from-[#007AFF]/70 via-[#5856D6]/70 to-[#10B981]/70 opacity-100'
                : effectivePhase === 'thinking'
                  ? 'bg-gradient-to-tr from-[#5856D6]/65 via-[#007AFF]/65 to-[#10B981]/55 opacity-100 scale-105'
                  : effectivePhase === 'listening'
                    ? 'orb-listen-pulse bg-gradient-to-tr from-[#10B981]/60 via-[#007AFF]/55 to-[#5856D6]/45 opacity-100'
                    : paused
                      ? 'bg-[#F59E0B]/30 opacity-60'
                      : 'bg-gradient-to-tr from-[#007AFF]/35 via-[#5856D6]/35 to-[#10B981]/35 opacity-80 group-hover:opacity-100'
            }`}
          />
          {/* Spinning Apple multi-color gradient ring */}
          <span
            aria-hidden="true"
            className={`absolute inset-0 rounded-full p-[3px] ${
              effectivePhase === 'thinking' || effectivePhase === 'speaking'
                ? 'orb-conic-spin-fast'
                : paused && !liveActive
                  ? ''
                  : 'orb-conic-spin'
            }`}
            style={{
              background:
                paused && !liveActive && effectivePhase === 'idle'
                  ? 'linear-gradient(135deg, #F59E0B, #FBBF24)'
                  : effectivePhase === 'listening'
                    ? 'conic-gradient(from 0deg, #10B981, #007AFF, #5856D6, #10B981)'
                    : 'conic-gradient(from 0deg, #007AFF, #5856D6, #FF3B30, #F59E0B, #10B981, #007AFF)',
            }}
          >
            <span className="block w-full h-full rounded-full bg-white/90" />
          </span>
          {/* Inner frosted glossy core */}
          <span
            className={`relative z-10 w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-white shadow-inner transition-colors ${
              effectivePhase === 'speaking'
                ? 'bg-gradient-to-br from-[#007AFF] via-[#5856D6] to-[#10B981]'
                : effectivePhase === 'thinking'
                  ? 'bg-gradient-to-br from-[#5856D6] via-[#007AFF] to-[#10B981]'
                  : effectivePhase === 'listening'
                    ? 'bg-gradient-to-br from-[#10B981] to-[#007AFF]'
                    : paused
                      ? 'bg-gradient-to-br from-[#F59E0B] to-[#D97706]'
                      : 'bg-gradient-to-br from-[#007AFF] via-[#5856D6] to-[#10B981]'
            }`}
          >
            {effectivePhase === 'speaking' ? (
              <AudioLines className="w-4 h-4 sm:w-5 sm:h-5" />
            ) : effectivePhase === 'thinking' ? (
              <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
            ) : paused && !liveActive ? (
              <Pause className="w-4 h-4 sm:w-5 sm:h-5" />
            ) : (
              <Mic className="w-4 h-4 sm:w-5 sm:h-5" />
            )}
          </span>
        </button>

        {/* Hub Title, State & Connected Gemini Live Badge */}
        <div className="min-w-0 flex-1">
          <h2 className="text-[14px] sm:text-[15px] font-bold tracking-tight text-[#0F172A] truncate">
            {mode === 'jarvis' ? 'JARVIS Signal Hub' : 'Manual Command Hub'}
          </h2>
          <p
            className={`text-[11.5px] font-medium truncate mt-0.5 ${
              effectivePhase === 'speaking'
                ? 'text-[#5856D6] font-semibold'
                : effectivePhase === 'thinking'
                  ? 'text-[#007AFF] font-semibold'
                  : effectivePhase === 'listening'
                    ? 'text-[#047857] font-semibold'
                    : 'text-[#64748B]'
            }`}
          >
            {orbStateLabel}
          </p>
          {liveActive && liveModel && (
            <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#10B981]/12 to-[#007AFF]/12 border border-[#10B981]/30 text-[#047857] text-[10px] font-mono font-semibold max-w-full">
              <Radio className="w-2.5 h-2.5 shrink-0 text-[#007AFF]" aria-hidden="true" />
              <span className="truncate">Gemini Live ({liveModel})</span>
            </div>
          )}
        </div>
      </div>

      {/* Compact Frosted Resume Last Job Banner (Auto-Resume Persistence) */}
      {recoverableJob && onAutoResumeJob && (
        <div
          role="status"
          className="rounded-xl bg-gradient-to-r from-[#007AFF]/10 via-[#5856D6]/10 to-[#10B981]/10 border border-[#007AFF]/30 px-2.5 py-2 flex flex-wrap items-center justify-between gap-2"
        >
          <div className="min-w-0 flex-1">
            <p className="text-[11.5px] font-bold text-[#0F172A] truncate">
              {language === 'hi'
                ? `अधूरा जॉब: ${recoverableJob.title}`
                : `Resume Last Job · ${recoverableJob.title}`}
            </p>
            <p className="text-[10.5px] font-medium text-[#64748B] truncate">
              {recoverableJob.stage} · {recoverableJob.status}
              {recoverableJob.targetRepo ? ` · ${recoverableJob.targetRepo}` : ''}
            </p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={onAutoResumeJob}
              disabled={isAutoResuming}
              className="h-7 px-2.5 rounded-lg bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-55 text-white text-[10.5px] font-bold inline-flex items-center gap-1 shadow-xs transition-all cursor-pointer active:scale-95 whitespace-nowrap"
            >
              {isAutoResuming ? (
                <Loader2 className="w-3 h-3 animate-spin shrink-0" aria-hidden="true" />
              ) : (
                <RotateCcw className="w-3 h-3 shrink-0" aria-hidden="true" />
              )}
              <span>
                {isAutoResuming
                  ? 'Resuming...'
                  : language === 'hi'
                    ? 'जारी रखें'
                    : 'Resume Last Job'}
              </span>
            </button>
            {onDismissRecoverableJob && (
              <button
                type="button"
                onClick={onDismissRecoverableJob}
                aria-label="Dismiss unfinished job banner"
                className="w-7 h-7 rounded-lg bg-white/80 hover:bg-white text-[#64748B] hover:text-[#0F172A] flex items-center justify-center transition-colors cursor-pointer shrink-0"
              >
                <X className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Compact Voice Controls Row: Persona/Speed Pill + Voice Reply ON/OFF + Tap-to-Stop */}
      <div className="flex flex-wrap items-center gap-1.5 w-full">
        {/* Voice Persona / Speed Pill */}
        <button
          type="button"
          onClick={() => setVoiceMenuOpen((prev) => !prev)}
          aria-expanded={voiceMenuOpen}
          className={`inline-flex items-center gap-1.5 px-2.5 h-8 rounded-full border text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
            voiceMenuOpen
              ? 'bg-[#5856D6] text-white border-[#5856D6] shadow-xs'
              : 'bg-[#5856D6]/8 text-[#5856D6] border-[#5856D6]/25 hover:bg-[#5856D6]/14'
          }`}
        >
          <Volume2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span className="tabular-nums">
            {voicePersona} · {formatSpeed(voiceSpeed)}
          </span>
          <SlidersHorizontal className="w-3 h-3 opacity-80 shrink-0" aria-hidden="true" />
        </button>

        {/* Voice Reply ON/OFF Pill (Neural Cloud TTS for non-Live replies) */}
        <button
          type="button"
          onClick={onToggleVoiceReply}
          aria-pressed={voiceReplyEnabled}
          className={`inline-flex items-center gap-1 px-2.5 h-8 rounded-full border text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
            voiceReplyEnabled
              ? 'bg-[#10B981]/12 text-[#047857] border-[#10B981]/30 hover:bg-[#10B981]/18'
              : 'bg-slate-100/90 text-[#64748B] border-slate-200/80 hover:text-[#0F172A]'
          }`}
        >
          {voiceReplyEnabled ? (
            <Volume2 className="w-3.5 h-3.5 shrink-0 text-[#10B981]" aria-hidden="true" />
          ) : (
            <VolumeX className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          )}
          <span>{voiceReplyEnabled ? 'Voice Reply ON' : 'Voice Reply OFF'}</span>
        </button>

        {/* Hands-Free Loop Toggle Pill (Auto re-arms Mic ~300ms after Aoede finishes speaking) */}
        <button
          type="button"
          onClick={onToggleHandsFreeLoop}
          aria-pressed={handsFreeLoop}
          title={
            language === 'hi'
              ? 'हैंड्स-फ्री लूप: Aoede के बोलने के बाद Mic अपने-आप चालू होगा'
              : 'Hands-Free Loop: auto re-arms Mic after Aoede finishes speaking on any AI brain'
          }
          className={`inline-flex items-center gap-1 px-2.5 h-8 rounded-full border text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
            handsFreeLoop
              ? 'bg-gradient-to-r from-[#007AFF] to-[#5856D6] text-white border-transparent shadow-xs'
              : 'bg-slate-100/90 text-[#64748B] border-slate-200/80 hover:text-[#0F172A]'
          }`}
        >
          <Repeat className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{handsFreeLoop ? 'Hands-Free ON' : 'Hands-Free'}</span>
        </button>

        {/* Permanent Memory (N) Pill */}
        <button
          type="button"
          onClick={onOpenMemory}
          className="inline-flex items-center gap-1 px-2.5 h-8 rounded-full border bg-[#F59E0B]/12 text-[#B45309] border-[#F59E0B]/30 hover:bg-[#F59E0B]/20 text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
        >
          <Brain className="w-3.5 h-3.5 shrink-0 text-[#D97706]" aria-hidden="true" />
          <span className="tabular-nums">Memory ({memoryCount})</span>
        </button>

        {/* Bot Mesh & Dynamic Skills (N) Pill */}
        <button
          type="button"
          onClick={onOpenBotMesh}
          className="inline-flex items-center gap-1 px-2.5 h-8 rounded-full border bg-[#0EA5E9]/12 text-[#0369A1] border-[#0EA5E9]/30 hover:bg-[#0EA5E9]/20 text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
        >
          <Cpu className="w-3.5 h-3.5 shrink-0 text-[#0284C7]" aria-hidden="true" />
          <span className="tabular-nums">Skills ({skillsCount})</span>
        </button>

        {/* Tap-to-Stop Speaking Indicator */}
        {isCloudSpeaking && (
          <button
            type="button"
            onClick={onStopSpeech}
            className="inline-flex items-center gap-1 px-2.5 h-8 rounded-full bg-[#FF3B30] hover:bg-[#DC2626] text-white border border-[#FF3B30] text-[11px] font-semibold shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
          >
            <Square className="w-3 h-3 fill-current shrink-0" aria-hidden="true" />
            <span>{language === 'hi' ? 'रोकें' : 'Stop'}</span>
          </button>
        )}
      </div>

      {/* Compact Scrollable 1-Tap Brain Selector Pill (Fits 360px Cleanly) */}
      <div
        role="group"
        aria-label="Preferred AI Brain"
        className="w-full min-w-0 overflow-x-auto studio-scroll pb-0.5"
      >
        <div className="inline-flex items-center gap-1 p-1 rounded-full bg-[#F6F9FE] border border-slate-200/85 min-w-max">
          <span className="pl-2 pr-1 text-[10.5px] font-bold text-[#64748B] whitespace-nowrap">
            Brain:
          </span>
          {BRAIN_OPTIONS.map((opt) => {
            const active = preferredBrain === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => onPreferredBrainChange(opt.value)}
                aria-pressed={active}
                className={`h-6 px-2.5 rounded-full border text-[10.5px] font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                  active
                    ? opt.activeClass
                    : 'bg-white/90 text-[#475569] border-slate-200/80 hover:text-[#0F172A] hover:border-slate-300'
                }`}
              >
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Compact Frosted Popover for Voice Persona & Speed */}
      {voiceMenuOpen && (
        <div className="rounded-2xl bg-white/95 backdrop-blur-xl border border-[#5856D6]/20 shadow-[0_8px_24px_rgba(88,86,214,0.1)] p-2.5 flex flex-col gap-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-semibold text-[#64748B] shrink-0">
              Voice Persona
            </span>
            <div className="flex items-center gap-1 flex-wrap justify-end">
              {VOICE_PERSONAS.map((persona) => (
                <button
                  key={persona}
                  type="button"
                  onClick={() => onVoiceChange(persona, voiceSpeed)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    voicePersona === persona
                      ? 'bg-[#5856D6] text-white shadow-xs'
                      : 'bg-[#F6F9FE] text-[#0F172A] border border-slate-200/80 hover:border-[#5856D6]/40'
                  }`}
                >
                  {persona}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-semibold text-[#64748B] shrink-0">
              Speed {liveActive || isCloudSpeaking ? '(Live)' : ''}
            </span>
            <div className="flex items-center gap-1 flex-wrap justify-end">
              {VOICE_SPEEDS.map((speed) => (
                <button
                  key={speed}
                  type="button"
                  onClick={() => onVoiceChange(voicePersona, speed)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-semibold font-mono tabular-nums transition-all cursor-pointer whitespace-nowrap ${
                    Math.abs(voiceSpeed - speed) < 0.01
                      ? 'bg-[#007AFF] text-white shadow-xs'
                      : 'bg-[#F6F9FE] text-[#0F172A] border border-slate-200/80 hover:border-[#007AFF]/40'
                  }`}
                >
                  {formatSpeed(speed)}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4 Crisp Colorful Bot Status Pills */}
      <div className="grid grid-cols-4 gap-1.5 w-full" role="group" aria-label="Studio Bots">
        {BOT_META.map(({ id, label, Icon, idleBg, activeBg, iconColor, ringColor }) => {
          const bot = bots[id];
          const isWorking = bot.status === 'working';
          const isReady = bot.status === 'ready';
          const statusText = paused
            ? 'Paused'
            : isWorking
              ? `${bot.progress}%`
              : isReady
                ? 'Ready'
                : 'Idle';

          return (
            <button
              key={id}
              type="button"
              onClick={() => onBotTap(id)}
              title={`${label}: ${bot.message}`}
              className={`min-h-[48px] px-1 py-1.5 rounded-xl border flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer active:scale-[0.97] focus:outline-none focus-visible:ring-2 ${ringColor} ${
                isWorking ? activeBg : idleBg
              }`}
            >
              <div className="flex items-center justify-center gap-1 min-w-0">
                <Icon
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isWorking ? 'text-white' : iconColor
                  }`}
                  aria-hidden="true"
                />
                <span
                  className={`text-[11.5px] font-bold tracking-tight whitespace-nowrap ${
                    isWorking ? 'text-white' : 'text-[#0F172A]'
                  }`}
                >
                  {label}
                </span>
              </div>
              <span
                className={`text-[10px] font-medium tabular-nums whitespace-nowrap ${
                  isWorking ? 'text-white/90' : 'text-[#64748B]'
                }`}
              >
                {statusText}
              </span>
            </button>
          );
        })}
      </div>

      {/* Scrollable Chat Transcript */}
      <div
        className="rounded-xl bg-[#F6F9FE] border border-slate-200/75 p-2.5 h-[210px] sm:h-[240px] lg:h-[270px] overflow-y-auto studio-scroll flex flex-col gap-2"
        role="log"
        aria-live="polite"
        aria-label="Command Transcript"
      >
        {messages.map((msg) => {
          if (msg.role === 'system') {
            const lowerSys = msg.text.toLowerCase();
            const isPauseChip =
              lowerSys.includes('paused at stage') ||
              lowerSys.includes('इंस्पेक्ट मोड');
            const isResumeChip =
              lowerSys.includes('resumed at stage') ||
              lowerSys.includes('जारी हुआ');

            if (isPauseChip || isResumeChip) {
              return (
                <div key={msg.id} className="flex justify-center py-0.5">
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10.5px] font-semibold max-w-full text-center ${
                      isPauseChip
                        ? 'bg-[#F59E0B]/14 border-[#F59E0B]/35 text-[#B45309]'
                        : 'bg-[#10B981]/12 border-[#10B981]/30 text-[#047857]'
                    }`}
                  >
                    <span className="break-words">{msg.text}</span>
                  </span>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                className="text-center text-[11px] font-medium text-[#64748B] px-2 py-0.5"
              >
                {msg.text}
              </div>
            );
          }

          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`${
                  !isUser && msg.stepPlan && msg.stepPlan.length > 0
                    ? 'w-full max-w-full'
                    : 'max-w-[88%]'
                } rounded-2xl px-3 py-2 text-[12.5px] sm:text-[13px] leading-snug break-words ${
                  isUser
                    ? 'bg-[#007AFF] text-white rounded-br-md shadow-[0_2px_10px_rgba(0,122,255,0.2)]'
                    : 'bg-white text-[#0F172A] border border-slate-200/80 rounded-bl-md shadow-xs'
                }`}
              >
                <p className="whitespace-pre-wrap break-words">{msg.text}</p>

                {/* JARVIS Architect Locked Step Cards */}
                {!isUser && msg.stepPlan && msg.stepPlan.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-200/75 flex flex-col gap-2 w-full min-w-0">
                    {msg.stepPlan.map((step) => {
                      const stepKey = `${msg.id}-step-${step.stepNumber}`;
                      const isExpanded = Boolean(expandedSteps[stepKey]);
                      const isCopied = copiedStepKey === stepKey;

                      return (
                        <div
                          key={stepKey}
                          className="rounded-xl bg-[#F8FAFE]/95 backdrop-blur-md border border-[#007AFF]/20 p-2 flex flex-col gap-1.5 shadow-[0_2px_10px_rgba(15,23,42,0.04)] min-w-0"
                        >
                          <div className="flex items-center justify-between gap-1.5 min-w-0">
                            <div className="flex items-center gap-1.5 min-w-0 flex-1">
                              <span className="px-1.5 py-0.5 rounded-md bg-gradient-to-r from-[#007AFF] to-[#5856D6] text-white text-[9.5px] font-bold whitespace-nowrap shrink-0 tabular-nums">
                                Step {step.stepNumber}
                              </span>
                              <span className="text-[11.5px] font-bold text-[#0F172A] truncate">
                                {step.title}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedSteps((prev) => ({
                                  ...prev,
                                  [stepKey]: !prev[stepKey],
                                }))
                              }
                              aria-expanded={isExpanded}
                              aria-label={isExpanded ? 'Collapse step prompt' : 'Expand step prompt'}
                              className="w-6 h-6 rounded-lg bg-white border border-slate-200/80 text-[#64748B] hover:text-[#0F172A] flex items-center justify-center shrink-0 cursor-pointer"
                            >
                              {isExpanded ? (
                                <ChevronUp className="w-3.5 h-3.5" aria-hidden="true" />
                              ) : (
                                <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                              )}
                            </button>
                          </div>

                          <pre
                            className={`m-0 p-2 rounded-lg bg-white/95 border border-slate-200/75 font-mono text-[10px] leading-relaxed text-[#334155] whitespace-pre-wrap break-words overflow-y-auto studio-scroll ${
                              isExpanded ? 'max-h-56' : 'max-h-20'
                            }`}
                          >
                            {step.lockedPrompt}
                          </pre>

                          <div className="grid grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                void handleCopyStepPrompt(stepKey, step.lockedPrompt);
                              }}
                              className={`h-7 px-2 rounded-lg border text-[10.5px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                                isCopied
                                  ? 'bg-[#10B981] border-[#10B981] text-white shadow-2xs'
                                  : 'bg-white border-slate-200/90 text-[#0F172A] hover:border-[#007AFF]/45 hover:text-[#007AFF]'
                              }`}
                            >
                              {isCopied ? (
                                <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
                              ) : (
                                <Copy className="w-3 h-3 shrink-0" aria-hidden="true" />
                              )}
                              <span>{isCopied ? 'Copied ✓' : 'Copy'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => onSendStepToBuilder?.(step)}
                              className="h-7 px-2 rounded-lg bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 text-white text-[10.5px] font-bold inline-flex items-center justify-center gap-1 shadow-2xs transition-all whitespace-nowrap cursor-pointer active:scale-95"
                            >
                              <Rocket className="w-3 h-3 shrink-0" aria-hidden="true" />
                              <span>Send to Builder</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Approve Gate Buttons (Step-by-Step Auto-Pilot) */}
                {!isUser && msg.approveGate && (
                  <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
                    {msg.approveGate.resolved ? (
                      <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-[#047857]">
                        <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
                        <span>{language === 'hi' ? 'Approved ✓ अगला स्टेप चालू' : 'Approved ✓ Next step triggered'}</span>
                      </span>
                    ) : (
                      <>
                        <button
                          type="button"
                          onClick={() => onApproveGate?.(msg.id, msg.approveGate!.nextPrompt)}
                          className="flex-1 min-w-[140px] h-8 px-2.5 rounded-xl bg-gradient-to-r from-[#10B981] to-[#059669] hover:brightness-105 text-white text-[11px] font-bold inline-flex items-center justify-center gap-1 shadow-xs transition-all cursor-pointer active:scale-95 whitespace-nowrap"
                        >
                          <Check className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                          <span>{msg.approveGate.label}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onRequestGateChange?.(msg.id)}
                          className="h-8 px-2.5 rounded-xl bg-[#F59E0B]/12 border border-[#F59E0B]/35 text-[#B45309] hover:bg-[#F59E0B]/20 text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap"
                        >
                          <RotateCcw className="w-3 h-3 shrink-0" aria-hidden="true" />
                          <span>{language === 'hi' ? 'बदलो' : 'Change'}</span>
                        </button>
                      </>
                    )}
                  </div>
                )}

                {/* Executed Robot UI Action Chips */}
                {!isUser && msg.actionLabels && msg.actionLabels.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1 mt-2 pt-1.5 border-t border-slate-100">
                    {msg.actionLabels.map((label, idx) => (
                      <span
                        key={`${msg.id}-act-${idx}`}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#10B981]/10 border border-[#10B981]/25 text-[#047857] text-[10px] font-semibold whitespace-nowrap"
                      >
                        <Zap className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
                        <span>{label}</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-1.5 mt-1 px-1">
                <span className="text-[10px] text-[#64748B] tabular-nums">
                  {isUser ? (language === 'hi' ? 'आप' : 'You') : 'JARVIS'} ·{' '}
                  {formatTime(msg.timestamp)}
                </span>

                {/* Compact Provider Pill */}
                {!isUser && msg.providerUsed && (
                  <span
                    className={`px-1.5 py-[1px] rounded-full border text-[9.5px] font-semibold whitespace-nowrap ${getProviderPillClass(
                      msg.providerUsed
                    )}`}
                  >
                    {msg.providerUsed}
                  </span>
                )}

                {/* Per-Message Replay Audio Pill */}
                {!isUser && onReplayMessage && (
                  <button
                    type="button"
                    onClick={() => onReplayMessage(msg.text)}
                    aria-label={language === 'hi' ? 'इस संदेश को फिर से सुनें' : 'Replay message audio'}
                    className="inline-flex items-center gap-1 px-2 py-[1px] rounded-full bg-[#007AFF]/10 hover:bg-[#007AFF]/18 border border-[#007AFF]/25 text-[#007AFF] text-[9.5px] font-bold whitespace-nowrap cursor-pointer active:scale-95 transition-all"
                  >
                    <Volume2 className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
                    <span>{language === 'hi' ? 'सुनें' : 'Listen'}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {/* Active Thinking Bubble */}
        {isThinking && (
          <div className="flex flex-col items-start">
            <div className="rounded-2xl rounded-bl-md bg-white border border-[#007AFF]/25 px-3 py-2 text-[12px] text-[#007AFF] font-semibold inline-flex items-center gap-2 shadow-xs">
              <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
              <span>
                {language === 'hi'
                  ? 'JARVIS कमांड राउट कर रहा है...'
                  : 'Routing command via Multi-AI...'}
              </span>
            </div>
          </div>
        )}
        <div ref={transcriptEndRef} />
      </div>

      {/* Chat Input Strip with Compact Colorful Mic (Dictate) Button */}
      <form onSubmit={handleSubmit} className="flex items-center gap-1.5 w-full">
        <button
          type="button"
          onClick={onToggleDictation}
          disabled={isThinking}
          aria-pressed={isDictating}
          aria-label={isDictating ? 'Stop voice dictation' : 'Tap to dictate command'}
          title={isDictating ? 'Stop dictation' : 'Tap to dictate'}
          className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 transition-all active:scale-95 cursor-pointer disabled:opacity-45 ${
            isDictating
              ? 'bg-[#FF3B30] border-[#FF3B30] text-white shadow-[0_3px_12px_rgba(255,59,48,0.3)]'
              : 'bg-gradient-to-br from-[#10B981]/14 to-[#007AFF]/14 border-[#007AFF]/30 text-[#007AFF] hover:from-[#10B981]/22 hover:to-[#007AFF]/22'
          }`}
        >
          {isDictating ? (
            <Square className="w-4 h-4 fill-current" aria-hidden="true" />
          ) : (
            <Mic className="w-4 h-4" aria-hidden="true" />
          )}
        </button>

        <label htmlFor="studio-command-input" className="sr-only">
          Command input
        </label>
        <input
          id="studio-command-input"
          type="text"
          value={displayedInputValue}
          onChange={(e) => setInput(e.target.value)}
          disabled={isThinking || isDictating}
          placeholder={
            isDictating
              ? language === 'hi'
                ? 'सुन रहा है... अभी बोलें'
                : 'Listening... speak now'
              : language === 'hi'
                ? 'कोई भी कमांड बोलें या टाइप करें...'
                : 'Speak or type any command...'
          }
          className="flex-1 min-w-0 h-11 px-3 rounded-xl bg-white border border-slate-200/90 text-[13px] text-[#0F172A] placeholder:text-[#64748B] shadow-xs focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 transition-all disabled:opacity-70"
        />
        <button
          type="submit"
          disabled={isThinking || isDictating || !input.trim()}
          className="h-11 px-3 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 active:scale-[0.98] disabled:opacity-45 disabled:active:scale-100 text-white text-[12.5px] font-semibold inline-flex items-center justify-center gap-1 shadow-[0_4px_14px_rgba(0,122,255,0.28)] transition-all whitespace-nowrap shrink-0 cursor-pointer"
        >
          {isThinking ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
          ) : (
            <Send className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          )}
          <span>{language === 'hi' ? 'भेजें' : 'Send'}</span>
        </button>
      </form>
    </section>
  );
}
