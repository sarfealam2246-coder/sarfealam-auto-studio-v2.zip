import { useState, type FormEvent } from 'react';
import {
  Cpu,
  Globe,
  Play,
  Trash2,
  X,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  Plus,
  Bot,
  PauseCircle,
} from 'lucide-react';
import type { Language, StudioSecrets } from '../types/studio';
import {
  syncDynamicSkillsWithSupabase,
  type DynamicSkill,
  type DynamicSkillsSyncResult,
  type FetchAnyApiResult,
  type SubBotRun,
} from '../services/botMeshService';

interface BotMeshModalProps {
  open: boolean;
  language: Language;
  paused: boolean;
  secrets: StudioSecrets;
  skills: DynamicSkill[];
  subBotRuns: SubBotRun[];
  isSpawningSubBot: boolean;
  isFetchingApi: boolean;
  lastApiResult: FetchAnyApiResult | null;
  onSpawnSubBot: (role: string, task: string) => Promise<void> | void;
  onFetchApi: (opts: {
    name: string;
    url: string;
    method: 'GET' | 'POST';
    saveSkill: boolean;
  }) => Promise<void> | void;
  onDeleteSkill: (id: string) => void;
  onSyncSkillsComplete: (skills: DynamicSkill[]) => void;
  onClose: () => void;
}

const SUB_BOT_PRESETS: {
  role: string;
  task: string;
  pillClass: string;
}[] = [
  {
    role: 'QA Reviewer',
    task: 'Audit 360px mobile overflow, touch targets, and error edge cases.',
    pillClass: 'bg-[#10B981]/12 text-[#047857] border-[#10B981]/30 hover:bg-[#10B981]/20',
  },
  {
    role: 'Physics Tuner',
    task: 'Tune 3D vehicle steering damping, R/N/1/2/3 gear torque, and frame stability.',
    pillClass: 'bg-[#007AFF]/12 text-[#007AFF] border-[#007AFF]/30 hover:bg-[#007AFF]/20',
  },
  {
    role: 'UI Polish',
    task: 'Refine frosted-glass spacing, visual contrast, and crisp micro-interactions.',
    pillClass: 'bg-[#5856D6]/12 text-[#5856D6] border-[#5856D6]/30 hover:bg-[#5856D6]/20',
  },
  {
    role: 'API Architect',
    task: 'Check Studio vs Apps Supabase isolation and 5s timeout safety.',
    pillClass: 'bg-[#F59E0B]/14 text-[#B45309] border-[#F59E0B]/30 hover:bg-[#F59E0B]/22',
  },
];

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function BotMeshModal({
  open,
  language,
  paused,
  secrets,
  skills,
  subBotRuns,
  isSpawningSubBot,
  isFetchingApi,
  lastApiResult,
  onSpawnSubBot,
  onFetchApi,
  onDeleteSkill,
  onSyncSkillsComplete,
  onClose,
}: BotMeshModalProps) {
  const [roleInput, setRoleInput] = useState('QA Reviewer');
  const [taskInput, setTaskInput] = useState(
    'Audit 360px mobile overflow, touch targets, and error edge cases.'
  );
  const [skillName, setSkillName] = useState('');
  const [skillUrl, setSkillUrl] = useState('');
  const [skillMethod, setSkillMethod] = useState<'GET' | 'POST'>('GET');
  const [syncing, setSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<DynamicSkillsSyncResult | null>(
    null
  );

  if (!open) return null;

  const handleSubBotSubmit = (e: FormEvent) => {
    e.preventDefault();
    const role = roleInput.trim();
    const task = taskInput.trim();
    if (!role || !task || isSpawningSubBot) return;
    void onSpawnSubBot(role, task);
  };

  const handleApiSubmit = (e: FormEvent) => {
    e.preventDefault();
    const url = skillUrl.trim();
    if (!url || isFetchingApi) return;
    setSyncStatus(null);
    void onFetchApi({
      name: skillName.trim(),
      url,
      method: skillMethod,
      saveSkill: true,
    });
  };

  const handleRunSavedSkill = (skill: DynamicSkill) => {
    if (isFetchingApi) return;
    setSkillName(skill.name);
    setSkillUrl(skill.url);
    setSkillMethod(skill.method);
    setSyncStatus(null);
    void onFetchApi({
      name: skill.name,
      url: skill.url,
      method: skill.method,
      saveSkill: false,
    });
  };

  const handleSyncSupabase = async () => {
    setSyncing(true);
    setSyncStatus(null);
    const result = await syncDynamicSkillsWithSupabase(secrets, skills);
    setSyncStatus(result);
    if (result.ok) {
      onSyncSkillsComplete(result.skills);
    }
    setSyncing(false);
  };

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Bot Mesh and Dynamic Skills"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-lg mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[89dvh] sm:max-h-[85dvh] overflow-hidden"
      >
        {/* Drag Handle (mobile) */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#0EA5E9] via-[#007AFF] to-[#5856D6] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <Cpu className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                Bot Mesh &amp; Dynamic Skills
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate tabular-nums">
                {subBotRuns.length} sub-bot run{subBotRuns.length === 1 ? '' : 's'} · {skills.length} saved skill{skills.length === 1 ? '' : 's'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Bot Mesh and Dynamic Skills"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Sheet Body */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3.5 sm:px-5 pt-3 pb-8 flex flex-col gap-3">
          {/* Section 1: Quick Sub-Bot Mesh Launcher */}
          <section
            aria-label="Sub-Bot Launcher"
            className="rounded-2xl bg-white/90 border border-slate-200/85 shadow-[0_3px_14px_rgba(15,23,42,0.04)] p-3 flex flex-col gap-2.5"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <Bot className="w-4 h-4 text-[#007AFF] shrink-0" aria-hidden="true" />
                <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                  {language === 'hi' ? 'सब-बॉट मेश लॉन्चर' : 'Quick Sub-Bot Launcher'}
                </h3>
              </div>
              {paused && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#F59E0B]/15 text-[#B45309] border border-[#F59E0B]/30 text-[10px] font-semibold whitespace-nowrap shrink-0">
                  <PauseCircle className="w-3 h-3 shrink-0" aria-hidden="true" />
                  <span>Paused</span>
                </span>
              )}
            </div>

            {/* Preset Role Chips */}
            <div className="flex flex-wrap items-center gap-1.5">
              {SUB_BOT_PRESETS.map((preset) => (
                <button
                  key={preset.role}
                  type="button"
                  onClick={() => {
                    setRoleInput(preset.role);
                    setTaskInput(preset.task);
                  }}
                  className={`px-2 py-1 rounded-lg border text-[10.5px] font-semibold transition-all cursor-pointer whitespace-nowrap active:scale-95 ${preset.pillClass}`}
                >
                  {preset.role}
                </button>
              ))}
            </div>

            {/* Sub-Bot Role + Task Form */}
            <form onSubmit={handleSubBotSubmit} className="flex flex-col gap-2">
              <div className="flex flex-col sm:flex-row gap-1.5">
                <label htmlFor="subbot-role-input" className="sr-only">
                  Sub-Bot Role
                </label>
                <input
                  id="subbot-role-input"
                  type="text"
                  value={roleInput}
                  onChange={(e) => setRoleInput(e.target.value)}
                  placeholder="Role (e.g. QA Reviewer)"
                  className="w-full sm:w-36 h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12px] font-medium text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
                />
                <label htmlFor="subbot-task-input" className="sr-only">
                  Sub-Bot Task
                </label>
                <input
                  id="subbot-task-input"
                  type="text"
                  value={taskInput}
                  onChange={(e) => setTaskInput(e.target.value)}
                  placeholder={
                    language === 'hi'
                      ? 'कार्य लिखें (उदा. 360px मोबाइल लेआउट जाँचें)...'
                      : 'Task for helper bot...'
                  }
                  className="flex-1 min-w-0 h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
                />
              </div>

              <button
                type="submit"
                disabled={!roleInput.trim() || !taskInput.trim() || isSpawningSubBot}
                className="w-full h-9 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-50 text-white text-[12px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_12px_rgba(0,122,255,0.22)] transition-all cursor-pointer active:scale-[0.98]"
              >
                {isSpawningSubBot ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span>
                  {isSpawningSubBot
                    ? paused
                      ? 'Waiting for Resume...'
                      : 'Running Sub-Bot...'
                    : 'Spawn Sub-Bot'}
                </span>
              </button>
            </form>

            {/* Recent Sub-Bot Results */}
            {subBotRuns.length > 0 && (
              <div className="pt-1 border-t border-slate-100 flex flex-col gap-1.5">
                <span className="text-[10.5px] font-semibold text-[#64748B] uppercase tracking-wider">
                  Recent Sub-Bot Runs
                </span>
                {subBotRuns.slice(0, 3).map((run) => (
                  <div
                    key={run.id}
                    className="rounded-xl bg-[#F6F9FE] border border-slate-200/75 p-2 flex flex-col gap-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold text-[#0F172A] truncate">
                        {run.role}
                      </span>
                      <div className="flex items-center gap-1 shrink-0">
                        {run.providerUsed && (
                          <span className="px-1.5 py-[1px] rounded-full bg-[#007AFF]/10 text-[#007AFF] text-[9.5px] font-semibold">
                            {run.providerUsed}
                          </span>
                        )}
                        <span className="text-[9.5px] text-[#64748B] tabular-nums">
                          {formatTime(run.timestamp)}
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-[#334155] leading-snug whitespace-pre-wrap break-words">
                      {run.output}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Section 2: Dynamic API Skills (fetch_any_api) */}
          <section
            aria-label="Dynamic API Skills"
            className="rounded-2xl bg-white/90 border border-slate-200/85 shadow-[0_3px_14px_rgba(15,23,42,0.04)] p-3 flex flex-col gap-2.5"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <Globe className="w-4 h-4 text-[#0EA5E9] shrink-0" aria-hidden="true" />
                <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                  {language === 'hi'
                    ? 'डायनामिक API स्किल्स (5s टाइमआउट)'
                    : 'Dynamic API Skills (5s Timeout)'}
                </h3>
              </div>
              <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-[#0EA5E9]/10 text-[#0369A1] whitespace-nowrap shrink-0">
                Studio DB Only
              </span>
            </div>

            <form onSubmit={handleApiSubmit} className="flex flex-col gap-2">
              <div className="flex items-center gap-1.5">
                <label htmlFor="skill-name-input" className="sr-only">
                  Skill Name
                </label>
                <input
                  id="skill-name-input"
                  type="text"
                  value={skillName}
                  onChange={(e) => setSkillName(e.target.value)}
                  placeholder="Skill Name (e.g. GitHub Zen)"
                  className="flex-1 min-w-0 h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#0EA5E9] focus:ring-2 focus:ring-[#0EA5E9]/15"
                />
                <div className="inline-flex rounded-xl border border-slate-200/90 bg-[#F8FAFE] p-0.5 shrink-0">
                  {(['GET', 'POST'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setSkillMethod(m)}
                      className={`px-2 h-7 rounded-lg text-[10.5px] font-bold font-mono transition-all cursor-pointer ${
                        skillMethod === m
                          ? 'bg-[#0EA5E9] text-white shadow-xs'
                          : 'text-[#64748B] hover:text-[#0F172A]'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <label htmlFor="skill-url-input" className="sr-only">
                API Endpoint URL
              </label>
              <input
                id="skill-url-input"
                type="url"
                value={skillUrl}
                onChange={(e) => setSkillUrl(e.target.value)}
                placeholder="https://api.github.com/zen"
                className="w-full h-9 px-2.5 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12px] font-mono text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#0EA5E9] focus:ring-2 focus:ring-[#0EA5E9]/15"
              />

              <button
                type="submit"
                disabled={!skillUrl.trim() || isFetchingApi}
                className="w-full h-9 rounded-xl bg-gradient-to-r from-[#0EA5E9] to-[#10B981] hover:brightness-105 disabled:opacity-50 text-white text-[12px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_12px_rgba(14,165,233,0.22)] transition-all cursor-pointer active:scale-[0.98]"
              >
                {isFetchingApi ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Plus className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span>{isFetchingApi ? 'Fetching API (5s max)...' : 'Test & Save Skill'}</span>
              </button>
            </form>

            {/* Latest API Call Output Preview */}
            {lastApiResult && (
              <div
                className={`rounded-xl border p-2.5 flex flex-col gap-1.5 ${
                  lastApiResult.ok
                    ? 'bg-[#10B981]/6 border-[#10B981]/25'
                    : 'bg-[#FF3B30]/6 border-[#FF3B30]/25'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <span
                    className={`inline-flex items-center gap-1 text-[11px] font-bold ${
                      lastApiResult.ok ? 'text-[#047857]' : 'text-[#DC2626]'
                    }`}
                  >
                    {lastApiResult.ok ? (
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    ) : (
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    )}
                    <span>
                      {lastApiResult.name} ·{' '}
                      {lastApiResult.status > 0
                        ? `HTTP ${lastApiResult.status}`
                        : 'Failed'}
                    </span>
                  </span>
                  <span className="text-[10px] font-mono text-[#64748B] tabular-nums">
                    {lastApiResult.method} · {lastApiResult.durationMs}ms
                  </span>
                </div>

                {lastApiResult.error && (
                  <p className="text-[11px] font-medium text-[#DC2626] break-words">
                    {lastApiResult.error}
                  </p>
                )}

                {lastApiResult.preview && (
                  <pre className="max-h-32 overflow-auto studio-scroll rounded-lg bg-white/90 border border-slate-200/80 p-2 text-[10.5px] font-mono text-[#0F172A] whitespace-pre-wrap break-all">
                    {lastApiResult.preview}
                  </pre>
                )}

                {lastApiResult.supabaseMessage && (
                  <p className="text-[10.5px] font-medium text-[#475569] break-words">
                    {lastApiResult.supabaseMessage}
                  </p>
                )}
              </div>
            )}

            {/* Saved Skills List with 1-Tap Run & Delete */}
            <div className="flex flex-col gap-1.5 pt-1 border-t border-slate-100">
              <span className="text-[10.5px] font-semibold text-[#64748B] uppercase tracking-wider">
                Saved Dynamic Skills ({skills.length})
              </span>

              {skills.length === 0 ? (
                <div className="rounded-xl bg-[#F6F9FE] border border-dashed border-slate-300/90 p-3 text-center">
                  <p className="text-[11.5px] font-medium text-[#64748B]">
                    {language === 'hi'
                      ? 'अभी कोई API स्किल सेव नहीं है। ऊपर URL टेस्ट करें या "fetch api https://..." बोलें।'
                      : 'No saved API skills yet. Test any public JSON/REST URL above or say "fetch api https://...".'}
                  </p>
                </div>
              ) : (
                skills.map((skill) => (
                  <div
                    key={skill.id}
                    className="rounded-xl bg-[#F6F9FE] border border-slate-200/80 p-2 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="px-1.5 py-[1px] rounded bg-[#0EA5E9]/12 text-[#0369A1] text-[9.5px] font-mono font-bold shrink-0">
                          {skill.method}
                        </span>
                        <span className="text-[12px] font-bold text-[#0F172A] truncate">
                          {skill.name}
                        </span>
                      </div>
                      <p className="text-[10.5px] font-mono text-[#64748B] truncate mt-0.5">
                        {skill.url}
                      </p>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleRunSavedSkill(skill)}
                        disabled={isFetchingApi}
                        aria-label={`Run skill ${skill.name}`}
                        className="h-8 px-2.5 rounded-lg bg-[#10B981]/14 hover:bg-[#10B981]/24 text-[#047857] border border-[#10B981]/30 text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                      >
                        <Play className="w-3 h-3 fill-current shrink-0" aria-hidden="true" />
                        <span>Run</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteSkill(skill.id)}
                        aria-label={`Delete skill ${skill.name}`}
                        className="w-8 h-8 rounded-lg text-[#64748B] hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>

        {/* Sticky Footer: Studio Supabase Sync + Status Feedback */}
        <div className="px-3.5 sm:px-5 py-3 bg-white/92 backdrop-blur-xl border-t border-slate-200/80 flex flex-col gap-2 shrink-0 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          {syncStatus && (
            <div
              className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold flex items-center gap-1.5 ${
                syncStatus.ok
                  ? 'bg-[#10B981]/12 text-[#047857]'
                  : 'bg-[#F59E0B]/14 text-[#B45309]'
              }`}
            >
              {syncStatus.ok ? (
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )}
              <span className="break-words">{syncStatus.message}</span>
            </div>
          )}

          <button
            type="button"
            onClick={handleSyncSupabase}
            disabled={syncing}
            className="w-full h-10 rounded-xl bg-gradient-to-r from-[#0EA5E9] via-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-60 text-white text-[12.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_14px_rgba(0,122,255,0.25)] transition-all cursor-pointer active:scale-[0.98]"
          >
            {syncing ? (
              <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
            ) : (
              <RefreshCw className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            )}
            <span>
              {syncing ? 'Syncing Studio Supabase...' : 'Sync Studio Supabase'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
