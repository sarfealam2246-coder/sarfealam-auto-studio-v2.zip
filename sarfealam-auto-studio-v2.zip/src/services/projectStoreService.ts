import type {
  StudioAssetItem,
  StudioMessage,
  TargetEngine,
  VirtualFile,
} from '../types/studio';

export interface StudioProjectRecord {
  id: string;
  name: string;
  targetEngine: TargetEngine;
  currentStage: string;
  files: VirtualFile[];
  selectedAssets: StudioAssetItem[];
  messages: StudioMessage[];
  updatedAt: number;
}

const DB_NAME = 'sarfealam_projects_db_v1';
const DB_VERSION = 1;
const STORE_NAME = 'projects';
const FALLBACK_STORAGE_KEY = 'sarfealam_projects_fallback_v1';
const ACTIVE_PROJECT_ID_KEY = 'sarfealam_active_project_id_v1';

function hasIndexedDb(): boolean {
  try {
    return typeof window !== 'undefined' && 'indexedDB' in window && Boolean(window.indexedDB);
  } catch {
    return false;
  }
}

function openProjectsDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!hasIndexedDb()) {
      reject(new Error('IndexedDB is unavailable'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('updatedAt', 'updatedAt', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Failed to open IndexedDB'));
  });
}

function sanitizeRecord(raw: Partial<StudioProjectRecord>): StudioProjectRecord | null {
  if (!raw || typeof raw.id !== 'string' || !raw.id.trim()) return null;
  const now = typeof raw.updatedAt === 'number' && Number.isFinite(raw.updatedAt) ? raw.updatedAt : Date.now();
  const name = typeof raw.name === 'string' && raw.name.trim() ? raw.name.trim() : 'Untitled Project';
  const targetEngine: TargetEngine =
    raw.targetEngine === 'capacitor' ||
    raw.targetEngine === 'godot4' ||
    raw.targetEngine === 'flutter' ||
    raw.targetEngine === 'unity'
      ? raw.targetEngine
      : 'auto';
  const currentStage =
    typeof raw.currentStage === 'string' && raw.currentStage.trim()
      ? raw.currentStage
      : '1. Shell';
  const files = Array.isArray(raw.files) ? raw.files : [];
  const selectedAssets = Array.isArray(raw.selectedAssets) ? raw.selectedAssets : [];
  const messages = Array.isArray(raw.messages) ? raw.messages : [];

  return {
    id: raw.id.trim(),
    name,
    targetEngine,
    currentStage,
    files,
    selectedAssets,
    messages,
    updatedAt: now,
  };
}

function sortByUpdatedDesc(records: StudioProjectRecord[]): StudioProjectRecord[] {
  return [...records].sort((a, b) => b.updatedAt - a.updatedAt);
}

function loadFallbackProjects(): StudioProjectRecord[] {
  try {
    const raw = window.localStorage.getItem(FALLBACK_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const valid = parsed
      .map((item) => sanitizeRecord(item as Partial<StudioProjectRecord>))
      .filter((item): item is StudioProjectRecord => Boolean(item));
    return sortByUpdatedDesc(valid);
  } catch {
    return [];
  }
}

function saveFallbackProjects(records: StudioProjectRecord[]): void {
  try {
    window.localStorage.setItem(
      FALLBACK_STORAGE_KEY,
      JSON.stringify(sortByUpdatedDesc(records))
    );
  } catch {
    // Ignore localStorage quota errors when large VFS payloads live in IndexedDB
  }
}

export function getActiveProjectId(): string | null {
  try {
    const id = window.localStorage.getItem(ACTIVE_PROJECT_ID_KEY);
    return id && id.trim() ? id.trim() : null;
  } catch {
    return null;
  }
}

export function setActiveProjectId(id: string): void {
  try {
    window.localStorage.setItem(ACTIVE_PROJECT_ID_KEY, id);
  } catch {
    // Ignore storage write errors
  }
}

export function createStarterProjectFiles(now: number, projectName = 'Sarfealam Auto-Studio'): VirtualFile[] {
  const safeTitle = projectName.replace(/[<>]/g, '');
  return [
    {
      path: 'src/App.tsx',
      language: 'tsx',
      updatedAt: now,
      generatedBy: 'code',
      content: `import React from 'react';

export function StudioEntry() {
  return (
    <main className="min-h-screen bg-[#F3F6FB] text-[#0F172A] p-4">
      <h1 className="text-lg font-bold">${safeTitle}</h1>
      <p className="text-sm text-slate-500 mt-1">
        Zero-server Capacitor 6 mobile workspace ready.
      </p>
    </main>
  );
}
`,
    },
    {
      path: 'src/main.ts',
      language: 'ts',
      updatedAt: now,
      generatedBy: 'code',
      content: `export const STUDIO_CONFIG = {
  appId: 'com.sarfealam.autostudio',
  projectName: '${safeTitle.replace(/'/g, "\\'")}',
  version: '0.2.0',
  runtime: 'capacitor-6',
  targetViewport: 360,
} as const;

export function bootStudio(): string {
  return \`Booted \${STUDIO_CONFIG.appId} (\${STUDIO_CONFIG.runtime})\`;
}
`,
    },
    {
      path: 'assets/manifest.json',
      language: 'json',
      updatedAt: now,
      generatedBy: 'asset',
      content: `{
  "studio": "Sarfealam Auto-Studio",
  "project": "${safeTitle.replace(/"/g, '\\"')}",
  "schemaVersion": 1,
  "packs": [],
  "categories": [
    "vehicles",
    "characters",
    "village_world",
    "textures_pbr",
    "audio_sfx"
  ]
}
`,
    },
    {
      path: 'docs/index.html',
      language: 'html',
      updatedAt: now,
      generatedBy: 'code',
      content: `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${safeTitle} Preview</title>
  </head>
  <body>
    <div id="studio-stage">${safeTitle} · Display A Ready</div>
  </body>
</html>
`,
    },
  ];
}

export function createBlankProject(name?: string): StudioProjectRecord {
  const now = Date.now();
  const cleanName = name?.trim() || `Studio Project ${new Date(now).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  const id = `proj-${now}-${Math.random().toString(36).slice(2, 7)}`;

  return {
    id,
    name: cleanName,
    targetEngine: 'auto',
    currentStage: '1. Shell',
    files: createStarterProjectFiles(now, cleanName),
    selectedAssets: [],
    messages: [
      {
        id: `welcome-${id}`,
        role: 'jarvis',
        text: `Workspace "${cleanName}" initialized. Display A, File Drawer, and Offline IndexedDB VFS are ready.`,
        timestamp: now,
        language: 'en',
      },
    ],
    updatedAt: now,
  };
}

export async function loadAllProjects(): Promise<StudioProjectRecord[]> {
  const fallback = loadFallbackProjects();
  if (!hasIndexedDb()) {
    return fallback;
  }

  let db: IDBDatabase | null = null;
  try {
    db = await openProjectsDb();
    const records = await new Promise<StudioProjectRecord[]>((resolve, reject) => {
      const tx = db!.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = Array.isArray(req.result)
          ? req.result
              .map((item) => sanitizeRecord(item as Partial<StudioProjectRecord>))
              .filter((item): item is StudioProjectRecord => Boolean(item))
          : [];
        resolve(sortByUpdatedDesc(list));
      };
      req.onerror = () => reject(req.error ?? new Error('Failed to load projects'));
    });

    if (records.length > 0) {
      return records;
    }

    // Hydrate IndexedDB from localStorage fallback if IndexedDB was empty
    if (fallback.length > 0) {
      for (const item of fallback) {
        await saveProjectRecord(item);
      }
      return fallback;
    }

    return [];
  } catch {
    return fallback;
  } finally {
    db?.close();
  }
}

export async function saveProjectRecord(
  record: StudioProjectRecord
): Promise<StudioProjectRecord> {
  const normalized: StudioProjectRecord = {
    ...record,
    name: record.name.trim() || 'Untitled Project',
    updatedAt: record.updatedAt || Date.now(),
  };

  // Mirror cleanly into localStorage fallback
  const fallbackList = loadFallbackProjects();
  const nextFallback = [
    normalized,
    ...fallbackList.filter((item) => item.id !== normalized.id),
  ];
  saveFallbackProjects(nextFallback);

  if (!hasIndexedDb()) {
    return normalized;
  }

  let db: IDBDatabase | null = null;
  try {
    db = await openProjectsDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db!.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.put(normalized);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Failed to save project'));
    });
  } catch {
    // Fallback already updated
  } finally {
    db?.close();
  }

  return normalized;
}

export async function deleteProjectById(id: string): Promise<void> {
  const cleanId = id.trim();
  if (!cleanId) return;

  const fallbackList = loadFallbackProjects();
  saveFallbackProjects(fallbackList.filter((item) => item.id !== cleanId));

  if (!hasIndexedDb()) {
    return;
  }

  let db: IDBDatabase | null = null;
  try {
    db = await openProjectsDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db!.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.delete(cleanId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Failed to delete project'));
    });
  } catch {
    // Fallback already updated
  } finally {
    db?.close();
  }
}
