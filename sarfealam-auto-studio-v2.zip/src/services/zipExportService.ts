import type { VirtualFile } from '../types/studio';

export interface ZipDownloadResult {
  ok: boolean;
  fileName: string;
  fileCount: number;
  byteLength: number;
  error?: string;
}

// Precomputed IEEE 802.3 CRC32 lookup table (zero external dependencies)
const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function computeCrc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC32_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function toDosDateTime(timestamp: number): { time: number; date: number } {
  const d = new Date(timestamp || Date.now());
  const year = Math.max(1980, Math.min(2107, d.getFullYear()));
  const month = d.getMonth() + 1;
  const day = d.getDate();
  const hours = d.getHours();
  const minutes = d.getMinutes();
  const seconds = Math.floor(d.getSeconds() / 2);

  const time = ((hours & 0x1f) << 11) | ((minutes & 0x3f) << 5) | (seconds & 0x1f);
  const date = (((year - 1980) & 0x7f) << 9) | ((month & 0x0f) << 5) | (day & 0x1f);
  return { time, date };
}

function normalizeZipEntryPath(rawPath: string): string {
  const clean = rawPath
    .trim()
    .replace(/\\/g, '/')
    .replace(/^\/+/, '')
    .split('/')
    .filter((seg) => seg.length > 0 && seg !== '.' && seg !== '..')
    .join('/');
  return clean || 'file.txt';
}

export function sanitizeZipFileName(projectName: string): string {
  const slug = projectName
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 48);
  return `${slug || 'sarfealam-project'}.zip`;
}

export function buildProjectZipBytes(files: VirtualFile[]): Uint8Array {
  const encoder = new TextEncoder();
  const localChunks: Uint8Array[] = [];
  const centralChunks: Uint8Array[] = [];
  const seenPaths = new Set<string>();

  let offset = 0;
  let entryCount = 0;

  for (const file of files) {
    const entryPath = normalizeZipEntryPath(file.path);
    const dedupeKey = entryPath.toLowerCase();
    if (seenPaths.has(dedupeKey)) continue;
    seenPaths.add(dedupeKey);

    const nameBytes = encoder.encode(entryPath);
    const dataBytes = encoder.encode(file.content ?? '');
    const crc = computeCrc32(dataBytes);
    const { time, date } = toDosDateTime(file.updatedAt);

    // Local File Header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // Local file header signature
    lv.setUint16(4, 20, true); // Version needed to extract (2.0)
    lv.setUint16(6, 0x0800, true); // General purpose bit flag: UTF-8 filename
    lv.setUint16(8, 0, true); // Compression method: 0 (Store)
    lv.setUint16(10, time, true); // Last mod file time
    lv.setUint16(12, date, true); // Last mod file date
    lv.setUint32(14, crc, true); // CRC-32
    lv.setUint32(18, dataBytes.length, true); // Compressed size
    lv.setUint32(22, dataBytes.length, true); // Uncompressed size
    lv.setUint16(26, nameBytes.length, true); // File name length
    lv.setUint16(28, 0, true); // Extra field length
    localHeader.set(nameBytes, 30);

    // Central Directory File Header (46 bytes + filename)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true); // Central file header signature
    cv.setUint16(4, 20, true); // Version made by
    cv.setUint16(6, 20, true); // Version needed to extract
    cv.setUint16(8, 0x0800, true); // UTF-8 flag
    cv.setUint16(10, 0, true); // Compression method: Store
    cv.setUint16(12, time, true); // Mod time
    cv.setUint16(14, date, true); // Mod date
    cv.setUint32(16, crc, true); // CRC-32
    cv.setUint32(20, dataBytes.length, true); // Compressed size
    cv.setUint32(24, dataBytes.length, true); // Uncompressed size
    cv.setUint16(28, nameBytes.length, true); // File name length
    cv.setUint16(30, 0, true); // Extra field length
    cv.setUint16(32, 0, true); // File comment length
    cv.setUint16(34, 0, true); // Disk number start
    cv.setUint16(36, 0, true); // Internal file attributes
    cv.setUint32(38, 0, true); // External file attributes
    cv.setUint32(42, offset, true); // Relative offset of local header
    centralHeader.set(nameBytes, 46);

    localChunks.push(localHeader, dataBytes);
    centralChunks.push(centralHeader);

    offset += localHeader.length + dataBytes.length;
    entryCount += 1;
  }

  let centralDirSize = 0;
  for (const chunk of centralChunks) {
    centralDirSize += chunk.length;
  }

  // End of Central Directory Record (22 bytes)
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true); // EOCD signature
  ev.setUint16(4, 0, true); // Disk number
  ev.setUint16(6, 0, true); // Disk with central dir
  ev.setUint16(8, entryCount, true); // Entries on this disk
  ev.setUint16(10, entryCount, true); // Total entries
  ev.setUint32(12, centralDirSize, true); // Size of central directory
  ev.setUint32(16, offset, true); // Offset of start of central directory
  ev.setUint16(20, 0, true); // ZIP file comment length

  const totalSize = offset + centralDirSize + eocd.length;
  const output = new Uint8Array(totalSize);

  let cursor = 0;
  for (const chunk of localChunks) {
    output.set(chunk, cursor);
    cursor += chunk.length;
  }
  for (const chunk of centralChunks) {
    output.set(chunk, cursor);
    cursor += chunk.length;
  }
  output.set(eocd, cursor);

  return output;
}

export function downloadProjectZip(
  projectName: string,
  files: VirtualFile[]
): ZipDownloadResult {
  const fileName = sanitizeZipFileName(projectName);

  if (!files || files.length === 0) {
    return {
      ok: false,
      fileName,
      fileCount: 0,
      byteLength: 0,
      error: 'No workspace files available to package into .ZIP.',
    };
  }

  try {
    const zipBytes = buildProjectZipBytes(files);
    const bufferCopy = new ArrayBuffer(zipBytes.byteLength);
    new Uint8Array(bufferCopy).set(zipBytes);
    const blob = new Blob([bufferCopy], { type: 'application/zip' });
    const blobUrl = URL.createObjectURL(blob);

    const anchor = document.createElement('a');
    anchor.href = blobUrl;
    anchor.download = fileName;
    anchor.rel = 'noopener';
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);

    window.setTimeout(() => {
      URL.revokeObjectURL(blobUrl);
    }, 4000);

    return {
      ok: true,
      fileName,
      fileCount: files.length,
      byteLength: zipBytes.byteLength,
    };
  } catch (err) {
    return {
      ok: false,
      fileName,
      fileCount: 0,
      byteLength: 0,
      error: err instanceof Error ? err.message : 'ZIP download failed.',
    };
  }
}
