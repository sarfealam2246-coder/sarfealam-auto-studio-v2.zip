const WEB_RESEARCH_TIMEOUT_MS = 4500;

export function shouldRunLiveWebResearch(text: string): boolean {
  const clean = text.trim().toLowerCase();
  if (!clean || clean.length < 4) return false;

  const triggers: RegExp[] = [
    /\b(research|search|internet|google|web|latest|trending|news|compare|best|top\s+\d+|how\s+to|price|market|features?)\b/i,
    /(रिसर्च|सर्च|इंटरनेट|ताज़ा|ताजा|नेट\s*से|ढूंढ|खोज|मार्केट|ट्रेंडिंग|तुलना|जानकारी|डिटेल|विस्तार)/,
  ];
  return triggers.some((re) => re.test(clean));
}

async function fetchJsonWithTimeout(url: string): Promise<unknown | null> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), WEB_RESEARCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return null;
    return (await res.json()) as unknown;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

async function searchWikipedia(query: string): Promise<string[]> {
  const url = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(
    query
  )}&limit=3&namespace=0&format=json&origin=*`;
  const data = await fetchJsonWithTimeout(url);
  if (!Array.isArray(data) || data.length < 4) return [];
  const titles = Array.isArray(data[1]) ? (data[1] as string[]) : [];
  const descs = Array.isArray(data[2]) ? (data[2] as string[]) : [];
  const urls = Array.isArray(data[3]) ? (data[3] as string[]) : [];
  const out: string[] = [];
  for (let i = 0; i < Math.min(3, titles.length); i++) {
    const t = titles[i];
    const d = descs[i] || '';
    const u = urls[i] || '';
    if (t) {
      out.push(`Wikipedia: ${t}${d ? ` — ${d}` : ''}${u ? ` (${u})` : ''}`);
    }
  }
  return out;
}

async function searchDuckDuckGo(query: string): Promise<string[]> {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(
    query
  )}&format=json&no_html=1&skip_disambig=1`;
  const data = (await fetchJsonWithTimeout(url)) as Record<string, unknown> | null;
  if (!data || typeof data !== 'object') return [];
  const out: string[] = [];
  if (typeof data.AbstractText === 'string' && data.AbstractText.trim()) {
    out.push(`DuckDuckGo: ${data.AbstractText.trim()}`);
  }
  if (Array.isArray(data.RelatedTopics)) {
    for (const item of data.RelatedTopics.slice(0, 3)) {
      if (item && typeof item === 'object' && typeof (item as { Text?: unknown }).Text === 'string') {
        out.push(`Web: ${(item as { Text: string }).Text.trim()}`);
      }
    }
  }
  return out;
}

async function searchGitHubRepos(query: string): Promise<string[]> {
  const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(
    query
  )}&sort=stars&per_page=3`;
  const data = (await fetchJsonWithTimeout(url)) as {
    items?: { full_name?: string; description?: string; html_url?: string }[];
  } | null;
  if (!data || !Array.isArray(data.items)) return [];
  return data.items
    .filter((r) => typeof r.full_name === 'string')
    .slice(0, 3)
    .map(
      (r) =>
        `GitHub: ${r.full_name}${r.description ? ` — ${r.description.slice(0, 120)}` : ''}${
          r.html_url ? ` (${r.html_url})` : ''
        }`
    );
}

export async function fetchLiveWebResearchContext(rawQuery: string): Promise<string> {
  const cleaned = rawQuery
    .replace(/(रिसर्च करो|सर्च करो|इंटरनेट से|बताओ|research|search|please)/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
  const query = cleaned || rawQuery.trim().slice(0, 120);
  if (!query) return '';

  const [wiki, ddg, gh] = await Promise.all([
    searchWikipedia(query),
    searchDuckDuckGo(query),
    searchGitHubRepos(query),
  ]);

  const combined = [...ddg, ...wiki, ...gh].slice(0, 7);
  if (combined.length === 0) return '';
  return `LIVE WEB RESEARCH FINDINGS (synthesize naturally in the user's language):\n${combined
    .map((line) => `- ${line}`)
    .join('\n')}`;
}
