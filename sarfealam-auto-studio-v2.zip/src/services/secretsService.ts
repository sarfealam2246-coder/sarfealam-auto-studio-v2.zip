import type {
  ApiKeyProvider,
  PreferredBrain,
  StudioApiKeyEntry,
  StudioSecrets,
} from '../types/studio';

export const SECRETS_STORAGE_KEY = 'sarfealam_studio_secrets_v2';

export const DEFAULT_2026_MODELS = {
  gemini: 'gemini-3.8-flash',
  geminiFallback: 'gemini-3.5-flash-lite',
  geminiLive: 'gemini-3.8-live',
  geminiTts: 'gemini-3.8-flash-tts',
  nvidia: 'qwen/qwen3-next-80b-a3b-instruct',
  groq: 'openai/gpt-oss-120b',
  openRouter: 'qwen/qwen3-coder:free',
  cohere: 'command-a-03-2025',
  cloudflare: '@cf/meta/llama-3.3-70b-instruct-fp8-fast',
  custom: 'gpt-4o-mini',
} as const;

export const DEFAULT_NVIDIA_MODELS: string[] = [
  'qwen/qwen3-next-80b-a3b-instruct',
  'meta/llama-3.3-70b-instruct',
  'deepseek-ai/deepseek-r1',
  'nvidia/llama-3.1-nemotron-70b-instruct',
  'mistralai/mistral-large-2-instruct',
];

const VALID_PROVIDERS: ApiKeyProvider[] = [
  'gemini',
  'groq',
  'nvidia',
  'openrouter',
  'cohere',
  'cloudflare',
  'custom',
];

export function getProviderDisplayName(provider: ApiKeyProvider): string {
  switch (provider) {
    case 'gemini':
      return 'Gemini';
    case 'groq':
      return 'Groq';
    case 'nvidia':
      return 'NVIDIA NIM';
    case 'openrouter':
      return 'OpenRouter';
    case 'cohere':
      return 'Cohere';
    case 'cloudflare':
      return 'Cloudflare AI';
    case 'custom':
      return 'Custom /v1';
  }
}

export function getDefaultModelForProvider(provider: ApiKeyProvider): string {
  switch (provider) {
    case 'gemini':
      return DEFAULT_2026_MODELS.gemini;
    case 'groq':
      return DEFAULT_2026_MODELS.groq;
    case 'nvidia':
      return DEFAULT_2026_MODELS.nvidia;
    case 'openrouter':
      return DEFAULT_2026_MODELS.openRouter;
    case 'cohere':
      return DEFAULT_2026_MODELS.cohere;
    case 'cloudflare':
      return DEFAULT_2026_MODELS.cloudflare;
    case 'custom':
      return DEFAULT_2026_MODELS.custom;
  }
}

export function detectProviderFromKey(rawKey: string): ApiKeyProvider {
  const trimmed = rawKey.trim();
  if (!trimmed) return 'custom';
  if (/^(AIza|AQ\.)/i.test(trimmed)) return 'gemini';
  if (/^gsk_/i.test(trimmed)) return 'groq';
  if (/^nvapi-/i.test(trimmed)) return 'nvidia';
  if (/^sk-or-v1-/i.test(trimmed)) return 'openrouter';
  if (/^cfut_/i.test(trimmed)) return 'cloudflare';
  // Colon-separated AccountID:Token for Cloudflare Workers AI (ignore URLs)
  if (
    !/^https?:\/\//i.test(trimmed) &&
    /^[a-zA-Z0-9_-]{8,}:[^\s:]{8,}$/.test(trimmed)
  ) {
    return 'cloudflare';
  }
  // Cohere keys are typically 32-48 bare alphanumeric characters (no sk- prefix)
  if (!/^sk-/i.test(trimmed) && /^[a-zA-Z0-9]{32,48}$/.test(trimmed)) {
    return 'cohere';
  }
  return 'custom';
}

export function parseCloudflareCredential(
  rawKey: string,
  secondaryId?: string
): { accountId: string; apiToken: string } {
  const trimmed = rawKey.trim();
  const colonIdx = trimmed.indexOf(':');
  if (colonIdx > 0 && !/^https?:\/\//i.test(trimmed)) {
    return {
      accountId: trimmed.slice(0, colonIdx).trim(),
      apiToken: trimmed.slice(colonIdx + 1).trim(),
    };
  }
  return {
    accountId: secondaryId?.trim() ?? '',
    apiToken: trimmed,
  };
}

function normalizePreferredBrain(value: unknown): PreferredBrain {
  if (value === 'auto') return 'auto';
  if (typeof value === 'string' && VALID_PROVIDERS.includes(value as ApiKeyProvider)) {
    return value as ApiKeyProvider;
  }
  return 'auto';
}

function normalizeNvidiaModelsList(list: unknown): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  const pushUnique = (model: string) => {
    const trimmed = model.trim();
    if (trimmed && !seen.has(trimmed)) {
      seen.add(trimmed);
      out.push(trimmed);
    }
  };
  if (Array.isArray(list)) {
    for (const item of list) {
      if (typeof item === 'string') pushUnique(item);
    }
  }
  if (out.length === 0) {
    for (const m of DEFAULT_NVIDIA_MODELS) pushUnique(m);
  } else if (!seen.has(DEFAULT_2026_MODELS.nvidia)) {
    out.unshift(DEFAULT_2026_MODELS.nvidia);
  }
  return out;
}

export function hydrateKeyPool(
  secrets: Partial<StudioSecrets>,
  skipLegacyBackfill = false
): StudioApiKeyEntry[] {
  const pool: StudioApiKeyEntry[] = [];
  const seenIds = new Set<string>();
  const seenProviderKeys = new Set<string>();

  if (Array.isArray(secrets.keyPool)) {
    for (const raw of secrets.keyPool) {
      if (!raw || typeof raw !== 'object') continue;
      const provider: ApiKeyProvider = VALID_PROVIDERS.includes(raw.provider)
        ? raw.provider
        : detectProviderFromKey(raw.apiKey || '');
      const apiKey = typeof raw.apiKey === 'string' ? raw.apiKey.trim() : '';
      if (!apiKey) continue;

      let secondaryId =
        typeof raw.secondaryId === 'string' ? raw.secondaryId.trim() : undefined;
      if (provider === 'cloudflare' && !secondaryId) {
        const parsed = parseCloudflareCredential(apiKey);
        if (parsed.accountId) {
          secondaryId = parsed.accountId;
        }
      }

      const id =
        typeof raw.id === 'string' && raw.id.trim() && !seenIds.has(raw.id.trim())
          ? raw.id.trim()
          : `key-${provider}-${pool.length + 1}`;
      seenIds.add(id);

      const dedupeSignature = `${provider}::${apiKey}`;
      seenProviderKeys.add(dedupeSignature);

      pool.push({
        id,
        provider,
        label:
          typeof raw.label === 'string' && raw.label.trim()
            ? raw.label.trim()
            : getProviderDisplayName(provider),
        apiKey,
        ...(secondaryId ? { secondaryId } : {}),
        ...(typeof raw.baseUrl === 'string' && raw.baseUrl.trim()
          ? { baseUrl: raw.baseUrl.trim() }
          : {}),
        model:
          typeof raw.model === 'string' && raw.model.trim()
            ? raw.model.trim()
            : getDefaultModelForProvider(provider),
        enabled: raw.enabled !== false,
        ...(typeof raw.statusLabel === 'string' && raw.statusLabel.trim()
          ? { statusLabel: raw.statusLabel.trim() }
          : {}),
        ...(typeof raw.cooldownUntil === 'number' && Number.isFinite(raw.cooldownUntil)
          ? { cooldownUntil: raw.cooldownUntil }
          : {}),
      });
    }
  }

  if (!skipLegacyBackfill) {
    const legacyEntries: {
      id: string;
      provider: ApiKeyProvider;
      label: string;
      apiKey?: string;
      model?: string;
    }[] = [
      {
        id: 'legacy-gemini',
        provider: 'gemini',
        label: 'Gemini #1',
        apiKey: secrets.geminiApiKey,
        model: secrets.geminiModel || DEFAULT_2026_MODELS.gemini,
      },
      {
        id: 'legacy-nvidia',
        provider: 'nvidia',
        label: 'NVIDIA NIM',
        apiKey: secrets.nvidiaApiKey,
        model: secrets.nvidiaModel || DEFAULT_2026_MODELS.nvidia,
      },
      {
        id: 'legacy-groq',
        provider: 'groq',
        label: 'Groq',
        apiKey: secrets.groqApiKey,
        model: secrets.groqModel || DEFAULT_2026_MODELS.groq,
      },
      {
        id: 'legacy-openrouter',
        provider: 'openrouter',
        label: 'OpenRouter',
        apiKey: secrets.openRouterApiKey,
        model: secrets.openRouterModel || DEFAULT_2026_MODELS.openRouter,
      },
      {
        id: 'legacy-cohere',
        provider: 'cohere',
        label: 'Cohere',
        apiKey: secrets.cohereApiKey,
        model: secrets.cohereModel || DEFAULT_2026_MODELS.cohere,
      },
    ];

    for (const legacy of legacyEntries) {
      const key = legacy.apiKey?.trim() ?? '';
      if (!key) continue;
      const sig = `${legacy.provider}::${key}`;
      if (seenProviderKeys.has(sig)) continue;
      seenProviderKeys.add(sig);
      const id = seenIds.has(legacy.id)
        ? `${legacy.id}-${pool.length + 1}`
        : legacy.id;
      seenIds.add(id);
      pool.push({
        id,
        provider: legacy.provider,
        label: legacy.label,
        apiKey: key,
        model: legacy.model?.trim() || getDefaultModelForProvider(legacy.provider),
        enabled: true,
      });
    }
  }

  return pool;
}

export function syncLegacyFieldsFromKeyPool(
  secrets: StudioSecrets,
  pool: StudioApiKeyEntry[]
): StudioSecrets {
  const pickFirst = (provider: ApiKeyProvider): StudioApiKeyEntry | undefined =>
    pool.find((e) => e.provider === provider && e.enabled && e.apiKey.trim()) ??
    pool.find((e) => e.provider === provider && e.apiKey.trim());

  const gemini = pickFirst('gemini');
  const nvidia = pickFirst('nvidia');
  const groq = pickFirst('groq');
  const openrouter = pickFirst('openrouter');
  const cohere = pickFirst('cohere');

  return {
    ...secrets,
    geminiApiKey: gemini?.apiKey.trim() ?? '',
    geminiModel:
      gemini?.model?.trim() || secrets.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini,
    nvidiaApiKey: nvidia?.apiKey.trim() ?? '',
    nvidiaModel:
      nvidia?.model?.trim() || secrets.nvidiaModel?.trim() || DEFAULT_2026_MODELS.nvidia,
    groqApiKey: groq?.apiKey.trim() ?? '',
    groqModel:
      groq?.model?.trim() || secrets.groqModel?.trim() || DEFAULT_2026_MODELS.groq,
    openRouterApiKey: openrouter?.apiKey.trim() ?? '',
    openRouterModel:
      openrouter?.model?.trim() ||
      secrets.openRouterModel?.trim() ||
      DEFAULT_2026_MODELS.openRouter,
    cohereApiKey: cohere?.apiKey.trim() ?? '',
    cohereModel:
      cohere?.model?.trim() || secrets.cohereModel?.trim() || DEFAULT_2026_MODELS.cohere,
    keyPool: pool,
  };
}

export const DEFAULT_TARGET_REPO = 'sarfealam2246-coder/sarfealam-auto-studio-v2';

export const DEFAULT_ASSET_VAULT_URL =
  'https://raw.githubusercontent.com/sarfealam2246-coder/sarfealam-3d-assets/main/catalog.json';

export const STUDIO_SUPABASE_SQL = `-- Sarfealam Auto-Studio · Studio Supabase Schema (Memory & Skills Only)
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS public.studio_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_key TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'general',
  content TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.dynamic_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  trigger_keywords TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  instructions TEXT NOT NULL,
  engine_scope TEXT NOT NULL DEFAULT 'auto',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.error_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint TEXT NOT NULL,
  stage TEXT NOT NULL,
  error_message TEXT NOT NULL,
  resolution TEXT NOT NULL,
  hit_count INTEGER NOT NULL DEFAULT 1,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_studio_memory_category ON public.studio_memory (category);
CREATE INDEX IF NOT EXISTS idx_dynamic_skills_active ON public.dynamic_skills (active);
CREATE INDEX IF NOT EXISTS idx_error_memory_fingerprint ON public.error_memory (fingerprint);
`;

export function parseTargetRepo(targetRepo: string): {
  owner: string;
  repo: string;
  normalized: string;
} {
  const cleaned = targetRepo.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/^\/+|\/+$/g, '');
  const parts = cleaned.split('/').filter(Boolean);
  if (parts.length >= 2) {
    return {
      owner: parts[0],
      repo: parts[1],
      normalized: `${parts[0]}/${parts[1]}`,
    };
  }
  return {
    owner: 'sarfealam2246-coder',
    repo: 'sarfealam-auto-studio-v2',
    normalized: cleaned || DEFAULT_TARGET_REPO,
  };
}

export function createDefaultSecrets(): StudioSecrets {
  const { owner, repo, normalized } = parseTargetRepo(DEFAULT_TARGET_REPO);
  return {
    geminiApiKey: '',
    geminiModel: DEFAULT_2026_MODELS.gemini,
    geminiLiveModel: DEFAULT_2026_MODELS.geminiLive,
    geminiTtsModel: DEFAULT_2026_MODELS.geminiTts,
    nvidiaApiKey: '',
    nvidiaModel: DEFAULT_2026_MODELS.nvidia,
    groqApiKey: '',
    groqModel: DEFAULT_2026_MODELS.groq,
    openRouterApiKey: '',
    openRouterModel: DEFAULT_2026_MODELS.openRouter,
    cohereApiKey: '',
    cohereModel: DEFAULT_2026_MODELS.cohere,
    githubToken: '',
    githubOwner: owner,
    githubRepo: repo,
    targetRepo: normalized,
    assetVaultUrl: DEFAULT_ASSET_VAULT_URL,
    studioSupabaseUrl: '',
    studioSupabaseAnonKey: '',
    appsSupabaseUrl: '',
    appsSupabaseAnonKey: '',
    keyPool: [],
    nvidiaModelsList: [...DEFAULT_NVIDIA_MODELS],
    preferredBrain: 'auto',
  };
}

export function loadSecrets(): StudioSecrets {
  const defaults = createDefaultSecrets();
  try {
    const raw = window.localStorage.getItem(SECRETS_STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<StudioSecrets>;
    const repoSource =
      parsed.targetRepo ||
      (parsed.githubOwner && parsed.githubRepo
        ? `${parsed.githubOwner}/${parsed.githubRepo}`
        : DEFAULT_TARGET_REPO);
    const { owner, repo, normalized } = parseTargetRepo(repoSource);

    const hasExplicitPool = Array.isArray(parsed.keyPool);
    const hydratedPool = hydrateKeyPool(parsed, false);

    const base: StudioSecrets = {
      ...defaults,
      ...parsed,
      geminiModel: parsed.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini,
      geminiLiveModel: parsed.geminiLiveModel?.trim() || DEFAULT_2026_MODELS.geminiLive,
      geminiTtsModel: parsed.geminiTtsModel?.trim() || DEFAULT_2026_MODELS.geminiTts,
      nvidiaModel: parsed.nvidiaModel?.trim() || DEFAULT_2026_MODELS.nvidia,
      groqModel: parsed.groqModel?.trim() || DEFAULT_2026_MODELS.groq,
      openRouterModel: parsed.openRouterModel?.trim() || DEFAULT_2026_MODELS.openRouter,
      cohereModel: parsed.cohereModel?.trim() || DEFAULT_2026_MODELS.cohere,
      githubOwner: owner,
      githubRepo: repo,
      targetRepo: normalized,
      assetVaultUrl: parsed.assetVaultUrl?.trim() || DEFAULT_ASSET_VAULT_URL,
      nvidiaModelsList: normalizeNvidiaModelsList(parsed.nvidiaModelsList),
      preferredBrain: normalizePreferredBrain(parsed.preferredBrain),
      keyPool: hydratedPool,
    };

    return hasExplicitPool ? syncLegacyFieldsFromKeyPool(base, hydratedPool) : base;
  } catch {
    return defaults;
  }
}

export function saveSecrets(secrets: StudioSecrets): StudioSecrets {
  const defaults = createDefaultSecrets();
  const repoSource =
    secrets.targetRepo ||
    (secrets.githubOwner && secrets.githubRepo
      ? `${secrets.githubOwner}/${secrets.githubRepo}`
      : DEFAULT_TARGET_REPO);
  const { owner, repo, normalized } = parseTargetRepo(repoSource);

  const hasExplicitPool = Array.isArray(secrets.keyPool);
  const pool = hydrateKeyPool(secrets, hasExplicitPool);

  const base: StudioSecrets = {
    ...defaults,
    ...secrets,
    geminiApiKey: secrets.geminiApiKey.trim(),
    geminiModel: secrets.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini,
    geminiLiveModel: secrets.geminiLiveModel?.trim() || DEFAULT_2026_MODELS.geminiLive,
    geminiTtsModel: secrets.geminiTtsModel?.trim() || DEFAULT_2026_MODELS.geminiTts,
    nvidiaApiKey: secrets.nvidiaApiKey?.trim() ?? '',
    nvidiaModel: secrets.nvidiaModel?.trim() || DEFAULT_2026_MODELS.nvidia,
    groqApiKey: secrets.groqApiKey?.trim() ?? '',
    groqModel: secrets.groqModel?.trim() || DEFAULT_2026_MODELS.groq,
    openRouterApiKey: secrets.openRouterApiKey?.trim() ?? '',
    openRouterModel: secrets.openRouterModel?.trim() || DEFAULT_2026_MODELS.openRouter,
    cohereApiKey: secrets.cohereApiKey?.trim() ?? '',
    cohereModel: secrets.cohereModel?.trim() || DEFAULT_2026_MODELS.cohere,
    githubToken: secrets.githubToken.trim(),
    githubOwner: owner,
    githubRepo: repo,
    targetRepo: normalized,
    assetVaultUrl: secrets.assetVaultUrl?.trim() || DEFAULT_ASSET_VAULT_URL,
    studioSupabaseUrl: secrets.studioSupabaseUrl?.trim() ?? '',
    studioSupabaseAnonKey: secrets.studioSupabaseAnonKey?.trim() ?? '',
    appsSupabaseUrl: secrets.appsSupabaseUrl?.trim() ?? '',
    appsSupabaseAnonKey: secrets.appsSupabaseAnonKey?.trim() ?? '',
    nvidiaModelsList: normalizeNvidiaModelsList(secrets.nvidiaModelsList),
    preferredBrain: normalizePreferredBrain(secrets.preferredBrain),
    keyPool: pool,
  };

  const sanitized = hasExplicitPool ? syncLegacyFieldsFromKeyPool(base, pool) : base;

  try {
    window.localStorage.setItem(SECRETS_STORAGE_KEY, JSON.stringify(sanitized));
  } catch {
    // Ignore storage quota errors gracefully
  }

  return sanitized;
}

export interface VaultVerifyResult {
  ok: boolean;
  count: number;
  error?: string;
}

function countCatalogItems(data: unknown): number {
  if (Array.isArray(data)) {
    return data.length;
  }
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>;
    if (Array.isArray(obj.assets)) return obj.assets.length;
    if (Array.isArray(obj.items)) return obj.items.length;
    if (Array.isArray(obj.catalog)) return obj.catalog.length;
    if (Array.isArray(obj.models)) return obj.models.length;

    let total = 0;
    for (const value of Object.values(obj)) {
      if (Array.isArray(value)) {
        total += value.length;
      } else if (value && typeof value === 'object') {
        for (const nested of Object.values(value as Record<string, unknown>)) {
          if (Array.isArray(nested)) {
            total += nested.length;
          }
        }
      }
    }
    return total;
  }
  return 0;
}

export async function verifyAssetVault(url: string): Promise<VaultVerifyResult> {
  const trimmed = url.trim();
  if (!trimmed) {
    return { ok: false, count: 0, error: 'Enter a catalog.json URL first.' };
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(trimmed);
  } catch {
    return { ok: false, count: 0, error: 'Invalid URL format.' };
  }

  if (parsedUrl.protocol !== 'https:' && parsedUrl.protocol !== 'http:') {
    return { ok: false, count: 0, error: 'URL must start with https:// or http://' };
  }

  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch(parsedUrl.toString(), {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });

    if (!response.ok) {
      return {
        ok: false,
        count: 0,
        error: `Vault returned HTTP ${response.status}`,
      };
    }

    const json: unknown = await response.json();
    const count = countCatalogItems(json);
    return { ok: true, count };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return { ok: false, count: 0, error: 'Timed out after 5 seconds.' };
    }
    if (err instanceof Error) {
      return { ok: false, count: 0, error: err.message || 'Network verification failed.' };
    }
    return { ok: false, count: 0, error: 'Unable to reach Asset Vault.' };
  } finally {
    window.clearTimeout(timeoutId);
  }
}

export function countConfiguredKeys(secrets: StudioSecrets): number {
  const pool = hydrateKeyPool(secrets, Array.isArray(secrets.keyPool));
  const aiCount = pool.filter((e) => e.enabled && e.apiKey.trim().length > 0).length;
  const ghCount = secrets.githubToken?.trim() ? 1 : 0;
  return aiCount + ghCount;
}

export interface ApiKeyEntryTestResult {
  entryId: string;
  provider: ApiKeyProvider;
  label: string;
  configured: boolean;
  ok: boolean;
  statusLabel: string;
  modelCount: number;
  latencyMs: number;
  modelIds?: string[];
}

export interface ApiKeyPoolTestReport {
  entries: ApiKeyEntryTestResult[];
  byEntryId: Record<string, ApiKeyEntryTestResult>;
  nvidiaModelsList: string[];
  activeCount: number;
  totalCount: number;
}

const API_TEST_TIMEOUT_MS = 5000;

function extractModelIds(json: unknown): string[] {
  if (!json || typeof json !== 'object') return [];
  const obj = json as Record<string, unknown>;
  const list = Array.isArray(obj.data)
    ? obj.data
    : Array.isArray(obj.models)
      ? obj.models
      : Array.isArray(obj.result)
        ? obj.result
        : [];
  const ids: string[] = [];
  for (const item of list) {
    if (typeof item === 'string' && item.trim()) {
      ids.push(item.trim());
    } else if (item && typeof item === 'object') {
      const rec = item as Record<string, unknown>;
      const rawId =
        typeof rec.id === 'string'
          ? rec.id
          : typeof rec.name === 'string'
            ? rec.name
            : '';
      if (rawId.trim()) {
        ids.push(rawId.trim());
      }
    }
  }
  return Array.from(new Set(ids));
}

function formatHttpStatusLabel(status: number): string {
  if (status === 401 || status === 403) return `Invalid (${status})`;
  if (status === 429) return 'Rate Limit (429)';
  if (status === 503) return 'Overloaded (503)';
  return `HTTP ${status}`;
}

function normalizeCustomModelsEndpoint(baseUrl?: string): string | null {
  const trimmed = baseUrl?.trim() ?? '';
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
  } catch {
    return null;
  }
  const clean = trimmed.replace(/\/+$/, '');
  if (/\/chat\/completions$/i.test(clean)) {
    return clean.replace(/\/chat\/completions$/i, '/models');
  }
  if (/\/models$/i.test(clean)) {
    return clean;
  }
  if (/\/v\d+$/i.test(clean)) {
    return `${clean}/models`;
  }
  return `${clean}/v1/models`;
}

async function probeKeyPoolEntry(
  entry: StudioApiKeyEntry
): Promise<ApiKeyEntryTestResult> {
  const key = entry.apiKey.trim();
  if (!key) {
    return {
      entryId: entry.id,
      provider: entry.provider,
      label: entry.label,
      configured: false,
      ok: false,
      statusLabel: 'Not Set',
      modelCount: 0,
      latencyMs: 0,
    };
  }

  let url = '';
  const headers: Record<string, string> = { Accept: 'application/json' };

  switch (entry.provider) {
    case 'gemini':
      url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`;
      break;
    case 'nvidia':
      url = 'https://integrate.api.nvidia.com/v1/models';
      headers.Authorization = `Bearer ${key}`;
      break;
    case 'groq':
      url = 'https://api.groq.com/openai/v1/models';
      headers.Authorization = `Bearer ${key}`;
      break;
    case 'openrouter':
      url = 'https://openrouter.ai/api/v1/models';
      headers.Authorization = `Bearer ${key}`;
      break;
    case 'cohere':
      url = 'https://api.cohere.com/v1/models';
      headers.Authorization = `Bearer ${key}`;
      break;
    case 'cloudflare': {
      const { accountId, apiToken } = parseCloudflareCredential(
        key,
        entry.secondaryId
      );
      if (!accountId || !apiToken) {
        return {
          entryId: entry.id,
          provider: entry.provider,
          label: entry.label,
          configured: true,
          ok: false,
          statusLabel: 'Use AccountID:Token',
          modelCount: 0,
          latencyMs: 0,
        };
      }
      url = `https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(
        accountId
      )}/ai/models/search`;
      headers.Authorization = `Bearer ${apiToken}`;
      break;
    }
    case 'custom': {
      const modelsUrl = normalizeCustomModelsEndpoint(entry.baseUrl);
      if (!modelsUrl) {
        return {
          entryId: entry.id,
          provider: entry.provider,
          label: entry.label,
          configured: true,
          ok: false,
          statusLabel: 'Missing Base URL',
          modelCount: 0,
          latencyMs: 0,
        };
      }
      url = modelsUrl;
      headers.Authorization = `Bearer ${key}`;
      break;
    }
  }

  const startedAt = Date.now();
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), API_TEST_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers,
      signal: controller.signal,
    });
    const latencyMs = Date.now() - startedAt;

    if (!response.ok) {
      return {
        entryId: entry.id,
        provider: entry.provider,
        label: entry.label,
        configured: true,
        ok: false,
        statusLabel: formatHttpStatusLabel(response.status),
        modelCount: 0,
        latencyMs,
      };
    }

    let modelIds: string[] = [];
    try {
      const json: unknown = await response.json();
      modelIds = extractModelIds(json);
    } catch {
      modelIds = [];
    }

    return {
      entryId: entry.id,
      provider: entry.provider,
      label: entry.label,
      configured: true,
      ok: true,
      statusLabel: 'Active ✓',
      modelCount: modelIds.length,
      latencyMs,
      modelIds,
    };
  } catch (err) {
    const latencyMs = Date.now() - startedAt;
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    return {
      entryId: entry.id,
      provider: entry.provider,
      label: entry.label,
      configured: true,
      ok: false,
      statusLabel: isTimeout ? '5s Timeout' : 'Network / CORS',
      modelCount: 0,
      latencyMs,
    };
  } finally {
    window.clearTimeout(timeoutId);
  }
}

export async function testConfiguredApiKeys(
  secrets: StudioSecrets
): Promise<ApiKeyPoolTestReport> {
  const pool = hydrateKeyPool(secrets, Array.isArray(secrets.keyPool));
  const enabledEntries = pool.filter((e) => e.enabled && e.apiKey.trim().length > 0);

  const entries = await Promise.all(
    enabledEntries.map((entry) => probeKeyPoolEntry(entry))
  );

  const byEntryId: Record<string, ApiKeyEntryTestResult> = {};
  const nvidiaModelsSet = new Set<string>();

  for (const res of entries) {
    byEntryId[res.entryId] = res;
    if (res.provider === 'nvidia' && res.ok && res.modelIds && res.modelIds.length > 0) {
      for (const m of res.modelIds) {
        nvidiaModelsSet.add(m);
      }
    }
  }

  let nvidiaModelsList: string[];
  if (nvidiaModelsSet.size > 0) {
    const sorted = Array.from(nvidiaModelsSet).sort((a, b) => a.localeCompare(b));
    if (!nvidiaModelsSet.has(DEFAULT_2026_MODELS.nvidia)) {
      sorted.unshift(DEFAULT_2026_MODELS.nvidia);
    } else {
      const idx = sorted.indexOf(DEFAULT_2026_MODELS.nvidia);
      if (idx > 0) {
        sorted.splice(idx, 1);
        sorted.unshift(DEFAULT_2026_MODELS.nvidia);
      }
    }
    nvidiaModelsList = sorted;
  } else {
    nvidiaModelsList = normalizeNvidiaModelsList(secrets.nvidiaModelsList);
  }

  const activeCount = entries.filter((e) => e.ok).length;

  return {
    entries,
    byEntryId,
    nvidiaModelsList,
    activeCount,
    totalCount: entries.length,
  };
}


