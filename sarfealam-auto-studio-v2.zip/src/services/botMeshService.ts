import { studioBus } from './eventBus';
import { requestStudioAICompletion } from './aiRouter';
import { buildMemoryContext } from './memoryService';
import { waitIfPaused } from './pipelineController';
import type {
  StudioMessage,
  StudioSecrets,
  WorldState,
} from '../types/studio';

export const DYNAMIC_SKILLS_STORAGE_KEY = 'sarfealam_dynamic_skills_v2';
export const SUB_BOT_RUNS_STORAGE_KEY = 'sarfealam_sub_bot_runs_v2';

const API_FETCH_TIMEOUT_MS = 5000;
const MAX_SUB_BOT_RUNS = 20;

export interface DynamicSkill {
  id: string;
  name: string;
  description: string;
  url: string;
  method: 'GET' | 'POST';
  createdAt: number;
}

export interface SubBotRun {
  id: string;
  role: string;
  task: string;
  status: 'working' | 'ready' | 'error';
  output: string;
  timestamp: number;
  providerUsed?: string;
}

export interface SpawnSubBotOptions {
  role: string;
  task: string;
  state: WorldState;
  signal?: AbortSignal;
  onAppendMessage?: (msg: StudioMessage) => void;
}

export interface SpawnSubBotResult {
  run: SubBotRun;
  message: StudioMessage;
  providerUsed: string;
}

export interface FetchAnyApiOptions {
  name: string;
  url: string;
  method?: 'GET' | 'POST';
  description?: string;
  saveSkill?: boolean;
  secrets: StudioSecrets;
}

export interface FetchAnyApiResult {
  ok: boolean;
  name: string;
  url: string;
  method: 'GET' | 'POST';
  status: number;
  durationMs: number;
  contentType: string;
  preview: string;
  data?: unknown;
  savedSkill?: DynamicSkill;
  skills?: DynamicSkill[];
  supabaseSynced?: boolean;
  supabaseMessage?: string;
  error?: string;
}

export interface DynamicSkillsSyncResult {
  ok: boolean;
  skills: DynamicSkill[];
  syncedCount: number;
  message: string;
}

interface RemoteSkillRow {
  id?: string;
  name?: string;
  description?: string;
  url?: string;
  method?: string;
  created_at?: string;
}

function makeId(prefix: string): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}-${crypto.randomUUID()}`;
  }
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function normalizeMethod(method?: string): 'GET' | 'POST' {
  return method && method.toUpperCase() === 'POST' ? 'POST' : 'GET';
}

function normalizeUrlKey(url: string, method: 'GET' | 'POST'): string {
  return `${method}:${url.trim().toLowerCase().replace(/\/+$/, '')}`;
}

export function validateHttpUrl(rawUrl: string): { ok: boolean; url: string; error?: string } {
  const trimmed = rawUrl.trim();
  if (!trimmed) {
    return { ok: false, url: '', error: 'API URL is required.' };
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return {
        ok: false,
        url: trimmed,
        error: 'Only http:// and https:// URLs are supported.',
      };
    }
    return { ok: true, url: parsed.toString() };
  } catch {
    return {
      ok: false,
      url: trimmed,
      error: 'Please enter a valid http:// or https:// URL.',
    };
  }
}

export function loadDynamicSkills(): DynamicSkill[] {
  try {
    const raw = window.localStorage.getItem(DYNAMIC_SKILLS_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const valid: DynamicSkill[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== 'object') continue;
      const obj = item as Partial<DynamicSkill>;
      if (typeof obj.name !== 'string' || !obj.name.trim()) continue;
      if (typeof obj.url !== 'string' || !obj.url.trim()) continue;
      valid.push({
        id: typeof obj.id === 'string' && obj.id ? obj.id : makeId('skill'),
        name: obj.name.trim().slice(0, 64),
        description:
          typeof obj.description === 'string' && obj.description.trim()
            ? obj.description.trim().slice(0, 160)
            : `Live API skill for ${obj.name.trim()}`,
        url: obj.url.trim(),
        method: normalizeMethod(obj.method),
        createdAt:
          typeof obj.createdAt === 'number' && Number.isFinite(obj.createdAt)
            ? obj.createdAt
            : Date.now(),
      });
    }
    return valid;
  } catch {
    return [];
  }
}

export function saveDynamicSkills(skills: DynamicSkill[]): DynamicSkill[] {
  const cleaned = skills
    .filter(
      (s) =>
        typeof s.name === 'string' &&
        s.name.trim().length > 0 &&
        typeof s.url === 'string' &&
        s.url.trim().length > 0
    )
    .map((s) => ({
      ...s,
      name: s.name.trim().slice(0, 64),
      description: s.description.trim().slice(0, 160),
      url: s.url.trim(),
      method: normalizeMethod(s.method),
    }));

  try {
    window.localStorage.setItem(
      DYNAMIC_SKILLS_STORAGE_KEY,
      JSON.stringify(cleaned)
    );
  } catch {
    // Ignore storage quota errors gracefully
  }

  return cleaned;
}

export function upsertDynamicSkill(
  existing: DynamicSkill[],
  input: {
    name: string;
    description?: string;
    url: string;
    method?: 'GET' | 'POST';
  }
): { skills: DynamicSkill[]; skill: DynamicSkill } {
  const method = normalizeMethod(input.method);
  const url = input.url.trim();
  const cleanName = input.name.trim() || deriveSkillNameFromUrl(url);
  const key = normalizeUrlKey(url, method);
  const now = Date.now();

  const existingMatch = existing.find(
    (s) => normalizeUrlKey(s.url, s.method) === key
  );

  const skill: DynamicSkill = {
    id: existingMatch?.id ?? makeId('skill'),
    name: cleanName.slice(0, 64),
    description:
      input.description?.trim() ||
      existingMatch?.description ||
      `${method} ${safeHostLabel(url)}`,
    url,
    method,
    createdAt: existingMatch?.createdAt ?? now,
  };

  const next = saveDynamicSkills([
    skill,
    ...existing.filter((s) => s.id !== skill.id),
  ]);

  return { skills: next, skill };
}

export function deleteDynamicSkill(
  existing: DynamicSkill[],
  id: string
): DynamicSkill[] {
  return saveDynamicSkills(existing.filter((s) => s.id !== id));
}

export function loadSubBotRuns(): SubBotRun[] {
  try {
    const raw = window.localStorage.getItem(SUB_BOT_RUNS_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (item): item is SubBotRun =>
          Boolean(item) &&
          typeof item === 'object' &&
          typeof (item as SubBotRun).role === 'string' &&
          typeof (item as SubBotRun).task === 'string'
      )
      .slice(0, MAX_SUB_BOT_RUNS);
  } catch {
    return [];
  }
}

export function saveSubBotRuns(runs: SubBotRun[]): SubBotRun[] {
  const trimmed = runs.slice(0, MAX_SUB_BOT_RUNS);
  try {
    window.localStorage.setItem(
      SUB_BOT_RUNS_STORAGE_KEY,
      JSON.stringify(trimmed)
    );
  } catch {
    // Ignore storage quota errors gracefully
  }
  return trimmed;
}

function safeHostLabel(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url.slice(0, 32);
  }
}

export function deriveSkillNameFromUrl(url: string): string {
  try {
    const parsed = new URL(url);
    const seg = parsed.pathname
      .split('/')
      .filter(Boolean)
      .pop();
    if (seg && seg.length >= 2 && seg.length <= 24) {
      return `${parsed.hostname.replace(/^www\./, '').split('.')[0]}-${seg}`;
    }
    return parsed.hostname.replace(/^www\./, '');
  } catch {
    return 'custom-api';
  }
}

async function fetchWith5sTimeout(
  url: string,
  init: RequestInit
): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), API_FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
  }
}

function resolveStudioSupabaseEndpoint(secrets: StudioSecrets): {
  ok: boolean;
  endpoint: string;
  anonKey: string;
  error?: string;
} {
  // STRICT ISOLATION: Use ONLY Studio Supabase credentials (NEVER appsSupabaseUrl)
  const rawUrl = secrets.studioSupabaseUrl?.trim() ?? '';
  const anonKey = secrets.studioSupabaseAnonKey?.trim() ?? '';

  if (!rawUrl || !anonKey) {
    return {
      ok: false,
      endpoint: '',
      anonKey: '',
      error: 'Studio Supabase not configured — saved locally.',
    };
  }

  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return {
        ok: false,
        endpoint: '',
        anonKey: '',
        error: 'Invalid Studio Supabase URL — saved locally.',
      };
    }
    const baseUrl = parsed.origin + parsed.pathname.replace(/\/+$/, '');
    return {
      ok: true,
      endpoint: `${baseUrl}/rest/v1/dynamic_skills`,
      anonKey,
    };
  } catch {
    return {
      ok: false,
      endpoint: '',
      anonKey: '',
      error: 'Invalid Studio Supabase URL — saved locally.',
    };
  }
}

async function uploadSkillsToStudioSupabase(
  secrets: StudioSecrets,
  skillsToUpload: DynamicSkill[]
): Promise<{ ok: boolean; message: string }> {
  const resolved = resolveStudioSupabaseEndpoint(secrets);
  if (!resolved.ok) {
    return { ok: false, message: resolved.error || 'Studio Supabase unavailable.' };
  }

  if (skillsToUpload.length === 0) {
    return { ok: true, message: 'Studio Supabase dynamic_skills up to date.' };
  }

  const headers: Record<string, string> = {
    apikey: resolved.anonKey,
    Authorization: `Bearer ${resolved.anonKey}`,
    'Content-Type': 'application/json',
    Prefer: 'return=minimal',
  };

  const payload = skillsToUpload.map((s) => ({
    name: s.name,
    description: s.description,
    url: s.url,
    method: s.method,
  }));

  try {
    const res = await fetchWith5sTimeout(resolved.endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      return {
        ok: false,
        message: `Studio Supabase returned HTTP ${res.status} — saved locally.`,
      };
    }

    return {
      ok: true,
      message: `Synced ${skillsToUpload.length} skill${skillsToUpload.length === 1 ? '' : 's'} to Studio Supabase dynamic_skills.`,
    };
  } catch (err) {
    const reason =
      err instanceof DOMException && err.name === 'AbortError'
        ? 'Timed out after 5s'
        : err instanceof Error
          ? err.message
          : 'Network error';
    return {
      ok: false,
      message: `${reason} — saved locally.`,
    };
  }
}

export async function syncDynamicSkillsWithSupabase(
  secrets: StudioSecrets,
  localSkills: DynamicSkill[]
): Promise<DynamicSkillsSyncResult> {
  const resolved = resolveStudioSupabaseEndpoint(secrets);
  if (!resolved.ok) {
    return {
      ok: false,
      skills: localSkills,
      syncedCount: 0,
      message: resolved.error || 'Studio Supabase not configured — local skills active.',
    };
  }

  const headers: Record<string, string> = {
    apikey: resolved.anonKey,
    Authorization: `Bearer ${resolved.anonKey}`,
    'Content-Type': 'application/json',
  };

  try {
    const getRes = await fetchWith5sTimeout(
      `${resolved.endpoint}?select=id,name,description,url,method,created_at&order=created_at.desc`,
      { method: 'GET', headers }
    );

    if (!getRes.ok) {
      return {
        ok: false,
        skills: localSkills,
        syncedCount: 0,
        message: `Studio Supabase returned HTTP ${getRes.status} — local skills preserved.`,
      };
    }

    const remoteData: unknown = await getRes.json();
    const remoteRows: RemoteSkillRow[] = Array.isArray(remoteData)
      ? (remoteData as RemoteSkillRow[])
      : [];

    const mergedByKey = new Map<string, DynamicSkill>();
    const remoteKeys = new Set<string>();

    for (const row of remoteRows) {
      const url = (row.url || '').trim();
      const name = (row.name || '').trim();
      if (!url || !name) continue;
      const method = normalizeMethod(row.method);
      const key = normalizeUrlKey(url, method);
      remoteKeys.add(key);
      const parsedTs = row.created_at ? Date.parse(row.created_at) : Date.now();
      mergedByKey.set(key, {
        id: row.id || makeId('skill'),
        name: name.slice(0, 64),
        description: (row.description || `${method} ${safeHostLabel(url)}`).trim().slice(0, 160),
        url,
        method,
        createdAt: Number.isFinite(parsedTs) ? parsedTs : Date.now(),
      });
    }

    const toUpload: DynamicSkill[] = [];
    for (const local of localSkills) {
      const key = normalizeUrlKey(local.url, local.method);
      if (!remoteKeys.has(key)) {
        toUpload.push(local);
      }
      mergedByKey.set(key, local);
    }

    if (toUpload.length > 0) {
      const uploadRes = await uploadSkillsToStudioSupabase(secrets, toUpload);
      if (!uploadRes.ok) {
        return {
          ok: false,
          skills: localSkills,
          syncedCount: 0,
          message: uploadRes.message,
        };
      }
    }

    const mergedSkills = saveDynamicSkills(
      Array.from(mergedByKey.values()).sort((a, b) => b.createdAt - a.createdAt)
    );

    return {
      ok: true,
      skills: mergedSkills,
      syncedCount: mergedSkills.length,
      message: `Synced ${mergedSkills.length} dynamic skill${mergedSkills.length === 1 ? '' : 's'} with Studio Supabase.`,
    };
  } catch (err) {
    const reason =
      err instanceof DOMException && err.name === 'AbortError'
        ? 'Timed out after 5s'
        : err instanceof Error
          ? err.message
          : 'Network error';
    return {
      ok: false,
      skills: localSkills,
      syncedCount: 0,
      message: `${reason} — local skills preserved.`,
    };
  }
}

export async function fetchAnyApi(
  options: FetchAnyApiOptions
): Promise<FetchAnyApiResult> {
  const method = normalizeMethod(options.method);
  const urlCheck = validateHttpUrl(options.url);
  const skillName =
    options.name.trim() || deriveSkillNameFromUrl(options.url.trim());

  if (!urlCheck.ok) {
    return {
      ok: false,
      name: skillName,
      url: options.url.trim(),
      method,
      status: 0,
      durationMs: 0,
      contentType: '',
      preview: '',
      error: urlCheck.error || 'Invalid URL.',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 35,
    message: `Skill API (${method}) → ${safeHostLabel(urlCheck.url)}...`,
  });

  const startedAt = performance.now();

  try {
    const res = await fetchWith5sTimeout(urlCheck.url, {
      method,
      headers: {
        Accept: 'application/json, text/plain;q=0.9, */*;q=0.5',
      },
    });

    const durationMs = Math.max(1, Math.round(performance.now() - startedAt));
    const contentType = res.headers.get('content-type') || 'text/plain';
    const rawText = await res.text();

    let parsedData: unknown = undefined;
    let preview = rawText.trim();

    if (
      contentType.toLowerCase().includes('json') ||
      preview.startsWith('{') ||
      preview.startsWith('[')
    ) {
      try {
        parsedData = JSON.parse(rawText);
        preview = JSON.stringify(parsedData, null, 2);
      } catch {
        // Keep safe raw text fallback if JSON is malformed
      }
    }

    if (preview.length > 1200) {
      preview = `${preview.slice(0, 1200)}\n... [truncated ${preview.length - 1200} chars]`;
    }
    if (!preview) {
      preview = `(Empty response body · HTTP ${res.status})`;
    }

    let savedSkill: DynamicSkill | undefined;
    let skills: DynamicSkill[] | undefined;
    let supabaseSynced: boolean | undefined;
    let supabaseMessage: string | undefined;

    if (options.saveSkill) {
      const currentSkills = loadDynamicSkills();
      const upserted = upsertDynamicSkill(currentSkills, {
        name: skillName,
        description:
          options.description?.trim() ||
          `${method} ${safeHostLabel(urlCheck.url)} (HTTP ${res.status})`,
        url: urlCheck.url,
        method,
      });
      savedSkill = upserted.skill;
      skills = upserted.skills;

      const supaRes = await uploadSkillsToStudioSupabase(options.secrets, [
        upserted.skill,
      ]);
      supabaseSynced = supaRes.ok;
      supabaseMessage = supaRes.message;
    }

    studioBus.emit('bot:progress', {
      botId: 'code',
      status: res.ok ? 'ready' : 'error',
      progress: 100,
      message: res.ok
        ? `API Skill "${skillName}" HTTP ${res.status} (${durationMs}ms)`
        : `API Skill "${skillName}" returned HTTP ${res.status}`,
    });

    return {
      ok: res.ok,
      name: skillName,
      url: urlCheck.url,
      method,
      status: res.status,
      durationMs,
      contentType,
      preview,
      data: parsedData,
      savedSkill,
      skills,
      supabaseSynced,
      supabaseMessage,
      error: res.ok ? undefined : `Endpoint returned HTTP ${res.status}`,
    };
  } catch (err) {
    const durationMs = Math.max(1, Math.round(performance.now() - startedAt));
    const reason =
      err instanceof DOMException && err.name === 'AbortError'
        ? 'Request timed out after 5s'
        : err instanceof Error
          ? err.message
          : 'Network or CORS error';

    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'error',
      progress: 0,
      message: `API Skill failed: ${reason}`,
    });

    return {
      ok: false,
      name: skillName,
      url: urlCheck.url,
      method,
      status: 0,
      durationMs,
      contentType: '',
      preview: '',
      error: reason,
    };
  }
}

function buildLocalSubBotFallback(
  role: string,
  task: string,
  state: WorldState
): string {
  const fileCount = state.files.length;
  const assetCount = state.selectedAssets.length;
  const lowerRole = role.toLowerCase();

  if (state.language === 'hi') {
    return `[${role} · Local Check] कार्य: "${task}"। प्रोजेक्ट "${state.projectName}" (${state.currentStage}, ${fileCount} फ़ाइलें, ${assetCount} एसेट) की जाँच पूरी हुई। गहरे AI विश्लेषण के लिए Secrets में कोई API Key जोड़ें।`;
  }

  if (lowerRole.includes('qa') || lowerRole.includes('review')) {
    return `QA Snapshot for "${state.projectName}" (${state.currentStage}):\n• Files tracked: ${fileCount} | Kept assets: ${assetCount} | Engine: ${state.targetEngine}.\n• Verify 360px viewport wrap, touch controls, and Secrets isolation before Stage 5 packaging.\n• Task noted: ${task} (Add an AI key in Secrets for deep multi-file AI review).`;
  }
  if (lowerRole.includes('physics') || lowerRole.includes('tuner')) {
    return `Physics Tuning Checklist (${task}):\n• Recommended damping: 0.92 lateral grip, smooth gear torque curve (R/1/2/3), clamped delta-time <= 0.05s.\n• Active workspace files: ${fileCount} | Kept 3D/audio assets: ${assetCount}.\n• Add an AI key in Secrets for automated code-level parameter tuning.`;
  }
  if (lowerRole.includes('ui') || lowerRole.includes('polish')) {
    return `UI Polish Checklist (${task}):\n• Enforce Apple White Frosted-Glass (#F3F6FB, bg-white/85), >=44px mobile touch targets, and zero horizontal overflow at 360px.\n• Current Display Mode: ${state.displayMode} | Stage: ${state.currentStage}.\n• Add an AI key in Secrets for custom layout suggestions.`;
  }

  return `[${role}] Reviewed "${state.projectName}" (${fileCount} files, ${assetCount} assets, stage ${state.currentStage}) for task: "${task}". Add an AI key in Secrets for full Multi-AI sub-bot reasoning.`;
}

function extractSubBotText(rawText: string): string {
  const trimmed = rawText.trim();
  if (!trimmed) return '';
  // If provider returned JSON because of Gemini responseMimeType: application/json
  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;
  try {
    const parsed: unknown = JSON.parse(candidate);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      const obj = parsed as Record<string, unknown>;
      if (typeof obj.output === 'string' && obj.output.trim()) {
        return obj.output.trim();
      }
      if (typeof obj.reply === 'string' && obj.reply.trim()) {
        return obj.reply.trim();
      }
      if (typeof obj.summary === 'string' && obj.summary.trim()) {
        return obj.summary.trim();
      }
    }
  } catch {
    // Plain text response
  }
  return trimmed;
}

export async function spawnSubBot({
  role,
  task,
  state,
  signal,
  onAppendMessage,
}: SpawnSubBotOptions): Promise<SpawnSubBotResult> {
  const cleanRole = role.trim() || 'Specialist Sub-Bot';
  const cleanTask = task.trim() || 'Inspect active workspace and report quick wins.';

  // Cooperative pause checkpoint: respects WorldState.paused cleanly
  await waitIfPaused(signal);

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 25,
    message: `Sub-Bot [${cleanRole}] initializing...`,
  });

  const memoryBlock = buildMemoryContext(state.memoryRules);
  const filePaths = state.files.map((f) => f.path).slice(0, 20).join(', ') || 'none';
  const assetSummary =
    state.selectedAssets
      .slice(0, 8)
      .map((a) => `${a.name} (${a.category})`)
      .join(', ') || 'none';
  const langLine =
    state.language === 'hi'
      ? 'Respond concisely in natural Hindi / Hinglish (max 4 short bullet points).'
      : 'Respond concisely in crisp English (max 4 short actionable bullet points).';

  const systemPrompt = [
    `You are a focused helper Sub-Bot inside Sarfealam Auto-Studio acting as: ${cleanRole}.`,
    langLine,
    `Project: "${state.projectName}", Engine: ${state.targetEngine}, Stage: ${state.currentStage}.`,
    `Virtual files: [${filePaths}].`,
    `Selected assets: [${assetSummary}].`,
    ...(memoryBlock ? [memoryBlock] : []),
    'Return strict JSON ONLY: {"output":"concise actionable findings from your specialist role"}',
  ].join('\n');

  const userPrompt = `Sub-Bot Role: ${cleanRole}\nAssigned Task: ${cleanTask}`;

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 65,
    message: `Sub-Bot [${cleanRole}] analyzing workspace...`,
  });

  const completion = await requestStudioAICompletion(
    systemPrompt,
    userPrompt,
    state
  );

  // Check pause gate again before committing output
  await waitIfPaused(signal);

  const now = Date.now();
  const outputText = completion.ok
    ? extractSubBotText(completion.rawText) ||
      buildLocalSubBotFallback(cleanRole, cleanTask, state)
    : buildLocalSubBotFallback(cleanRole, cleanTask, state);

  const providerUsed = completion.ok ? completion.providerUsed : 'Local';

  const run: SubBotRun = {
    id: makeId('subbot'),
    role: cleanRole,
    task: cleanTask,
    status: 'ready',
    output: outputText,
    timestamp: now,
    providerUsed,
  };

  const existingRuns = loadSubBotRuns();
  saveSubBotRuns([run, ...existingRuns]);

  const message: StudioMessage = {
    id: `subbot-msg-${now}`,
    role: 'jarvis',
    text: `[Sub-Bot · ${cleanRole}] ${outputText}`,
    timestamp: now,
    language: state.language,
    botRef: 'code',
    providerUsed: `${providerUsed} · Sub-Bot`,
    actionLabels: [`Sub-Bot → ${cleanRole}`],
  };

  if (onAppendMessage) {
    onAppendMessage(message);
  } else {
    studioBus.emit('world:update', {
      patch: {
        messages: [...state.messages, message],
      },
      source: 'bot-mesh-service',
    });
  }

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'ready',
    progress: 100,
    message: `Sub-Bot [${cleanRole}] finished via ${providerUsed}`,
  });

  return {
    run,
    message,
    providerUsed,
  };
}
