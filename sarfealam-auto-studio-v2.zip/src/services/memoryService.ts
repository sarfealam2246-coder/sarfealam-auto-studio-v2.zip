import type { StudioSecrets, UserMemoryRule } from '../types/studio';

export const MEMORY_STORAGE_KEY = 'sarfealam_studio_memory_v2';

const SUPABASE_SYNC_TIMEOUT_MS = 5000;

export interface MemorySyncResult {
  ok: boolean;
  rules: UserMemoryRule[];
  syncedCount: number;
  message: string;
}

interface RemoteMemoryRow {
  id?: string;
  rule_key?: string;
  category?: string;
  content?: string;
  enabled?: boolean;
  created_at?: string;
}

const VALID_CATEGORIES = new Set<UserMemoryRule['category']>([
  'style',
  'engine',
  'asset',
  'workflow',
  'general',
]);

function normalizeCategory(value?: string): UserMemoryRule['category'] {
  if (value && VALID_CATEGORIES.has(value as UserMemoryRule['category'])) {
    return value as UserMemoryRule['category'];
  }
  return 'general';
}

export function inferRuleCategory(text: string): UserMemoryRule['category'] {
  const lower = text.toLowerCase();
  if (/\b(color|ui|theme|font|apple|glass|rounded|hindi|english|hinglish|tone|style)\b/i.test(lower)) {
    return 'style';
  }
  if (/\b(unity|godot|flutter|capacitor|android|apk|engine|three\.?js|webgl)\b/i.test(lower)) {
    return 'engine';
  }
  if (/\b(asset|glb|gltf|3d|texture|audio|sfx|model|icon|vault)\b/i.test(lower)) {
    return 'asset';
  }
  if (/\b(git|github|commit|build|test|stage|step|deploy|workflow|pause|auto)\b/i.test(lower)) {
    return 'workflow';
  }
  return 'general';
}

function makeRuleId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `mem-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function normalizeRuleKey(ruleText: string): string {
  return ruleText
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

export function createMemoryRule(
  ruleText: string,
  category?: UserMemoryRule['category']
): UserMemoryRule {
  const cleaned = ruleText.trim();
  return {
    id: makeRuleId(),
    rule: cleaned,
    category: category ?? inferRuleCategory(cleaned),
    enabled: true,
    createdAt: Date.now(),
  };
}

export function loadMemoryRules(): UserMemoryRule[] {
  try {
    const raw = window.localStorage.getItem(MEMORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const valid: UserMemoryRule[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== 'object') continue;
      const obj = item as Partial<UserMemoryRule>;
      if (typeof obj.rule !== 'string' || !obj.rule.trim()) continue;
      valid.push({
        id: typeof obj.id === 'string' && obj.id ? obj.id : makeRuleId(),
        rule: obj.rule.trim(),
        category: normalizeCategory(obj.category),
        enabled: typeof obj.enabled === 'boolean' ? obj.enabled : true,
        createdAt:
          typeof obj.createdAt === 'number' && Number.isFinite(obj.createdAt)
            ? obj.createdAt
            : Date.now(),
      });
    }
    return valid;
  } catch {
    return [];
  }
}

export function saveMemoryRules(rules: UserMemoryRule[]): UserMemoryRule[] {
  const cleaned = rules
    .filter((r) => typeof r.rule === 'string' && r.rule.trim().length > 0)
    .map((r) => ({
      ...r,
      rule: r.rule.trim(),
      category: normalizeCategory(r.category),
    }));

  try {
    window.localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(cleaned));
  } catch {
    // Ignore storage quota errors gracefully
  }

  return cleaned;
}

export function addMemoryRuleUnique(
  existing: UserMemoryRule[],
  ruleText: string,
  category?: UserMemoryRule['category']
): { rules: UserMemoryRule[]; added: UserMemoryRule | null } {
  const cleaned = ruleText.trim();
  if (cleaned.length < 3) {
    return { rules: existing, added: null };
  }

  const key = normalizeRuleKey(cleaned);
  const duplicate = existing.find((r) => normalizeRuleKey(r.rule) === key);
  if (duplicate) {
    // Re-enable if it was disabled
    if (!duplicate.enabled) {
      const updated = saveMemoryRules(
        existing.map((r) => (r.id === duplicate.id ? { ...r, enabled: true } : r))
      );
      return { rules: updated, added: { ...duplicate, enabled: true } };
    }
    return { rules: existing, added: null };
  }

  const created = createMemoryRule(cleaned, category);
  const next = saveMemoryRules([created, ...existing]);
  return { rules: next, added: created };
}

export function buildMemoryContext(rules: UserMemoryRule[]): string {
  const active = rules.filter((r) => r.enabled && r.rule.trim().length > 0);
  if (active.length === 0) return '';

  const lines = active.map(
    (r, idx) => `${idx + 1}. [${r.category}] ${r.rule.trim()}`
  );

  return [
    'PERMANENT USER MEMORY RULES (STRICTLY OBEY ON EVERY RESPONSE):',
    ...lines,
  ].join('\n');
}

export function detectMemorySaveIntent(input: string): string | null {
  const trimmed = input.trim();
  if (trimmed.length < 6) return null;

  // 1. Direct EN/HI memory save prefixes
  const prefixPatterns: RegExp[] = [
    /^(?:please\s+)?remember\s+(?:that\s+|to\s+)?[:,-]?\s*(.+)$/i,
    /^(?:please\s+)?save\s+(?:this\s+)?(?:memory|rule)\s*[:,-]?\s*(.+)$/i,
    /^(?:please\s+)?add\s+(?:a\s+)?(?:memory|rule)\s*[:,-]?\s*(.+)$/i,
    /^(?:hamesha\s+)?yaad\s+rakh(?:na|o|iye)\s*(?:ki\s+|ke\s+)?[:,-]?\s*(.+)$/i,
    /^(?:ye|yeh)?\s*rule\s+save\s+kar(?:o|do|na)\s*[:,-]?\s*(.+)$/i,
    /^memory\s+(?:mein|me)\s+save\s+kar(?:o|do)\s*[:,-]?\s*(.+)$/i,
    /^याद\s+रख(?:ना|ो|िए)\s*(?:कि\s+)?[:,-]?\s*(.+)$/i,
  ];

  for (const pattern of prefixPatterns) {
    const match = trimmed.match(pattern);
    if (match && match[1]) {
      const extracted = match[1].trim().replace(/^[:"']+|[:"']+$/g, '').trim();
      if (extracted.length >= 3) {
        return extracted;
      }
    }
  }

  // 2. Suffix Hindi triggers (e.g. "... yaad rakhna" / "... rule save karo")
  const suffixPatterns: RegExp[] = [
    /^(.+?)\s+(?:hamesha\s+)?yaad\s+rakh(?:na|o|iye)\.?$/i,
    /^(.+?)\s+rule\s+save\s+kar(?:o|do)\.?$/i,
    /^(.+?)\s+याद\s+रख(?:ना|ो)\.?$/i,
  ];

  for (const pattern of suffixPatterns) {
    const match = trimmed.match(pattern);
    if (match && match[1]) {
      const extracted = match[1].trim();
      if (extracted.length >= 3) {
        return extracted;
      }
    }
  }

  // 3. Direct "always ..." / "never ..." imperative rules
  if (/^(?:always|never)\s+[a-z\u0900-\u097F].{3,}$/i.test(trimmed)) {
    return trimmed;
  }

  return null;
}

async function fetchWith5sTimeout(
  url: string,
  init: RequestInit
): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), SUPABASE_SYNC_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
  }
}

export async function syncMemoryWithSupabase(
  secrets: StudioSecrets,
  localRules: UserMemoryRule[]
): Promise<MemorySyncResult> {
  // STRICT ISOLATION: Use ONLY Studio Supabase credentials (NEVER appsSupabaseUrl)
  const rawUrl = secrets.studioSupabaseUrl?.trim() ?? '';
  const anonKey = secrets.studioSupabaseAnonKey?.trim() ?? '';

  if (!rawUrl || !anonKey) {
    return {
      ok: false,
      rules: localRules,
      syncedCount: 0,
      message: 'Studio Supabase not configured — local memory active.',
    };
  }

  let baseUrl: string;
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return {
        ok: false,
        rules: localRules,
        syncedCount: 0,
        message: 'Invalid Studio Supabase URL — local memory active.',
      };
    }
    baseUrl = parsed.origin + parsed.pathname.replace(/\/+$/, '');
  } catch {
    return {
      ok: false,
      rules: localRules,
      syncedCount: 0,
      message: 'Invalid Studio Supabase URL — local memory active.',
    };
  }

  const endpoint = `${baseUrl}/rest/v1/studio_memory`;
  const headers: Record<string, string> = {
    apikey: anonKey,
    Authorization: `Bearer ${anonKey}`,
    'Content-Type': 'application/json',
  };

  try {
    // 1. Fetch existing remote studio_memory rows
    const getRes = await fetchWith5sTimeout(
      `${endpoint}?select=id,rule_key,category,content,enabled,created_at&order=created_at.desc`,
      { method: 'GET', headers }
    );

    if (!getRes.ok) {
      return {
        ok: false,
        rules: localRules,
        syncedCount: 0,
        message: `Studio Supabase returned HTTP ${getRes.status} — local memory preserved.`,
      };
    }

    const remoteData: unknown = await getRes.json();
    const remoteRows: RemoteMemoryRow[] = Array.isArray(remoteData)
      ? (remoteData as RemoteMemoryRow[])
      : [];

    const mergedByKey = new Map<string, UserMemoryRule>();
    const remoteKeys = new Set<string>();

    for (const row of remoteRows) {
      const text = (row.content || '').trim();
      if (!text) continue;
      const key = normalizeRuleKey(text);
      remoteKeys.add(key);
      const parsedTs = row.created_at ? Date.parse(row.created_at) : Date.now();
      mergedByKey.set(key, {
        id: row.id || makeRuleId(),
        rule: text,
        category: normalizeCategory(row.category),
        enabled: typeof row.enabled === 'boolean' ? row.enabled : true,
        createdAt: Number.isFinite(parsedTs) ? parsedTs : Date.now(),
      });
    }

    // 2. Find local rules not yet in Studio Supabase & merge local state
    const toUpload: {
      rule_key: string;
      category: string;
      content: string;
      enabled: boolean;
    }[] = [];

    for (const local of localRules) {
      const key = normalizeRuleKey(local.rule);
      if (!key) continue;
      if (!remoteKeys.has(key)) {
        toUpload.push({
          rule_key: key.slice(0, 120),
          category: local.category,
          content: local.rule.trim(),
          enabled: local.enabled,
        });
      }
      // Prefer local toggle state for rules present locally
      mergedByKey.set(key, local);
    }

    if (toUpload.length > 0) {
      const postRes = await fetchWith5sTimeout(endpoint, {
        method: 'POST',
        headers: {
          ...headers,
          Prefer: 'return=minimal',
        },
        body: JSON.stringify(toUpload),
      });

      if (!postRes.ok) {
        return {
          ok: false,
          rules: localRules,
          syncedCount: 0,
          message: `Upload failed (HTTP ${postRes.status}) — local memory preserved.`,
        };
      }
    }

    const mergedRules = saveMemoryRules(
      Array.from(mergedByKey.values()).sort((a, b) => b.createdAt - a.createdAt)
    );

    return {
      ok: true,
      rules: mergedRules,
      syncedCount: mergedRules.length,
      message: `Synced ${mergedRules.length} rule${mergedRules.length === 1 ? '' : 's'} with Studio Supabase.`,
    };
  } catch (err) {
    const reason =
      err instanceof DOMException && err.name === 'AbortError'
        ? 'Timed out after 5s'
        : err instanceof Error
          ? err.message
          : 'Network error';
    return {
      ok: false,
      rules: localRules,
      syncedCount: 0,
      message: `${reason} — local memory preserved.`,
    };
  }
}
