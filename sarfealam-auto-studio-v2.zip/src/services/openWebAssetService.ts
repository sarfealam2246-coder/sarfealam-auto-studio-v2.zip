import type { AssetCategory, StudioAssetItem } from '../types/studio';

export const OPEN_WEB_TIMEOUT_MS = 5000;

export interface OpenWebSearchResult {
  items: StudioAssetItem[];
  timedOut: boolean;
  warnings: string[];
}

interface PolyHavenRawAsset {
  name?: string;
  type?: number; // 0 = hdri, 1 = texture, 2 = model
  categories?: string[];
  tags?: string[];
}

let polyHavenCatalogCache: {
  fetchedAt: number;
  entries: [string, PolyHavenRawAsset][];
} | null = null;

async function fetchOpenWebJson(
  url: string,
  timeoutMs = OPEN_WEB_TIMEOUT_MS
): Promise<unknown> {
  const controller = new AbortController();
  const timerId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } finally {
    window.clearTimeout(timerId);
  }
}

function tokenizeOpenWebQuery(query: string): string[] {
  const stopWords = new Set([
    'find',
    'search',
    'hunt',
    'get',
    'show',
    'asset',
    'assets',
    '3d',
    'model',
    'models',
    'for',
    'the',
    'a',
    'an',
    'me',
    'free',
    'dhoondo',
    'khojo',
    'dikhao',
    'lao',
  ]);

  return query
    .toLowerCase()
    .split(/[^a-z0-9]+/i)
    .map((t) => t.trim())
    .filter((t) => t.length >= 2 && !stopWords.has(t));
}

function mapPolyHavenCategory(
  raw: PolyHavenRawAsset,
  id: string
): AssetCategory {
  if (raw.type === 0) return 'hdri_sky';
  if (raw.type === 1) return 'textures_pbr';

  const haystack = [
    id,
    raw.name ?? '',
    ...(Array.isArray(raw.categories) ? raw.categories : []),
    ...(Array.isArray(raw.tags) ? raw.tags : []),
  ]
    .join(' ')
    .toLowerCase();

  if (/(car|truck|vehicle|bike|tractor|bus|boat|wheel|tire)/.test(haystack)) {
    return 'vehicles';
  }
  if (/(weapon|sword|gun|rifle|axe|shield|armor|helmet)/.test(haystack)) {
    return 'weapons_gear';
  }
  if (/(character|human|person|statue|bust|animal|creature)/.test(haystack)) {
    return 'characters';
  }
  return 'village_world';
}

async function searchPolyHavenLive(
  query: string,
  categories?: AssetCategory[]
): Promise<OpenWebSearchResult> {
  const warnings: string[] = [];
  let timedOut = false;

  try {
    let entries: [string, PolyHavenRawAsset][];
    if (
      polyHavenCatalogCache &&
      Date.now() - polyHavenCatalogCache.fetchedAt < 10 * 60_000
    ) {
      entries = polyHavenCatalogCache.entries;
    } else {
      const json = (await fetchOpenWebJson(
        'https://api.polyhaven.com/assets',
        OPEN_WEB_TIMEOUT_MS
      )) as Record<string, PolyHavenRawAsset>;

      entries =
        json && typeof json === 'object' && !Array.isArray(json)
          ? Object.entries(json)
          : [];
      polyHavenCatalogCache = {
        fetchedAt: Date.now(),
        entries,
      };
    }

    const tokens = tokenizeOpenWebQuery(query);
    const categorySet =
      categories && categories.length > 0 ? new Set(categories) : null;

    const scored: { item: StudioAssetItem; score: number }[] = [];
    const now = Date.now();

    for (const [assetId, meta] of entries) {
      if (!meta || typeof meta !== 'object') continue;
      const mappedCategory = mapPolyHavenCategory(meta, assetId);

      if (categorySet) {
        const allow3dFallback =
          mappedCategory === 'village_world' &&
          (categorySet.has('vehicles') ||
            categorySet.has('characters') ||
            categorySet.has('weapons_gear') ||
            categorySet.has('village_world'));
        if (!categorySet.has(mappedCategory) && !allow3dFallback) {
          continue;
        }
      }

      const displayName =
        typeof meta.name === 'string' && meta.name.trim()
          ? meta.name.trim()
          : assetId.replace(/[_-]+/g, ' ');
      const tags = [
        ...(Array.isArray(meta.categories) ? meta.categories : []),
        ...(Array.isArray(meta.tags) ? meta.tags : []),
      ]
        .filter((t): t is string => typeof t === 'string' && t.trim().length > 0)
        .map((t) => t.toLowerCase());

      const searchBlob = `${assetId} ${displayName} ${tags.join(' ')}`.toLowerCase();

      let score = 0;
      if (tokens.length === 0) {
        score = categorySet?.has(mappedCategory) ? 4 : 1;
      } else {
        for (const tok of tokens) {
          if (displayName.toLowerCase().includes(tok)) score += 8;
          else if (assetId.toLowerCase().includes(tok)) score += 7;
          else if (searchBlob.includes(tok)) score += 4;
        }
      }

      if (score <= 0) continue;

      const format =
        meta.type === 0 ? 'hdr' : meta.type === 1 ? 'pbr' : 'gltf';
      const thumbUrl = `https://cdn.polyhaven.com/asset_img/thumbs/${encodeURIComponent(
        assetId
      )}.png?width=320`;
      const pageUrl = `https://polyhaven.com/a/${encodeURIComponent(assetId)}`;

      scored.push({
        score,
        item: {
          id: `polyhaven:${assetId}`,
          name: displayName,
          category: mappedCategory,
          source: 'PolyHaven CC0',
          url: pageUrl,
          previewUrl: thumbUrl,
          format,
          license: 'CC0 Public Domain',
          tags: Array.from(new Set(tags)).slice(0, 8),
          selected: false,
          addedAt: now,
        },
      });
    }

    scored.sort((a, b) => b.score - a.score);
    return {
      items: scored.slice(0, 8).map((s) => s.item),
      timedOut: false,
      warnings,
    };
  } catch (err) {
    timedOut = err instanceof DOMException && err.name === 'AbortError';
    warnings.push(
      timedOut
        ? 'PolyHaven timed out after 5s'
        : err instanceof Error
          ? `PolyHaven: ${err.message}`
          : 'PolyHaven search failed'
    );
    return { items: [], timedOut, warnings };
  }
}

async function searchGitHubPublic3DAssets(
  query: string,
  categories?: AssetCategory[]
): Promise<OpenWebSearchResult> {
  const clean = query.trim() || '3d assets';
  const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(
    clean
  )}+glb+OR+3d&per_page=5`;

  try {
    const json = (await fetchOpenWebJson(url, OPEN_WEB_TIMEOUT_MS)) as {
      items?: {
        id?: number;
        full_name?: string;
        name?: string;
        description?: string | null;
        html_url?: string;
        topics?: string[];
        license?: { spdx_id?: string } | null;
        owner?: { avatar_url?: string } | null;
      }[];
    };

    const repos = Array.isArray(json?.items) ? json.items : [];
    const preferredCat: AssetCategory =
      categories?.find((c) =>
        [
          'vehicles',
          'characters',
          'weapons_gear',
          'village_world',
          'textures_pbr',
          'hdri_sky',
        ].includes(c)
      ) ?? 'village_world';

    const now = Date.now();
    const items: StudioAssetItem[] = [];

    for (const repo of repos) {
      if (!repo?.html_url) continue;
      const label =
        repo.name?.replace(/[-_]+/g, ' ').trim() ||
        repo.full_name ||
        'GitHub 3D Repo';
      const tags = Array.isArray(repo.topics)
        ? repo.topics.filter((t): t is string => typeof t === 'string').slice(0, 6)
        : ['github', '3d'];

      items.push({
        id: `github-openweb:${repo.id ?? repo.full_name ?? label}`,
        name: `${label} (GitHub)`,
        category: preferredCat,
        source: 'GitHub 3D',
        url: repo.html_url,
        previewUrl: repo.owner?.avatar_url,
        format: 'glb/repo',
        license: repo.license?.spdx_id || 'Open Source',
        tags: Array.from(new Set(['github', 'open-web', ...tags])),
        selected: false,
        addedAt: now,
      });
    }

    return { items, timedOut: false, warnings: [] };
  } catch (err) {
    const timedOut = err instanceof DOMException && err.name === 'AbortError';
    return {
      items: [],
      timedOut,
      warnings: [
        timedOut
          ? 'GitHub 3D search timed out after 5s'
          : err instanceof Error
            ? `GitHub 3D: ${err.message}`
            : 'GitHub 3D search failed',
      ],
    };
  }
}

async function searchOpenversePhotos(
  query: string
): Promise<OpenWebSearchResult> {
  const clean =
    tokenizeOpenWebQuery(query)
      .filter(
        (t) =>
          !['photo', 'photos', 'image', 'images', 'picture', 'wikimedia', 'openverse'].includes(t)
      )
      .join(' ') ||
    query.trim() ||
    'nature';

  const url = `https://api.openverse.org/v1/images/?q=${encodeURIComponent(
    clean
  )}&page_size=8`;

  try {
    const json = (await fetchOpenWebJson(url, OPEN_WEB_TIMEOUT_MS)) as {
      results?: {
        id?: string;
        title?: string;
        url?: string;
        thumbnail?: string;
        foreign_landing_url?: string;
        license?: string;
        filetype?: string;
        tags?: { name?: string }[];
      }[];
    };

    const hits = Array.isArray(json?.results) ? json.results : [];
    const now = Date.now();
    const items: StudioAssetItem[] = [];

    for (const hit of hits) {
      const targetUrl = (hit.url || hit.foreign_landing_url || '').trim();
      if (!targetUrl) continue;

      const tags = Array.isArray(hit.tags)
        ? hit.tags
            .map((t) => (typeof t?.name === 'string' ? t.name.toLowerCase().trim() : ''))
            .filter(Boolean)
            .slice(0, 6)
        : [];

      items.push({
        id: `openverse:${hit.id ?? targetUrl}`,
        name: (hit.title || clean || 'Openverse Photo').trim().slice(0, 72),
        category: 'wikimedia_photos',
        source: 'Openverse',
        url: targetUrl,
        previewUrl: (hit.thumbnail || hit.url || '').trim() || undefined,
        format: (hit.filetype || 'jpg').toLowerCase(),
        license: hit.license ? `CC ${hit.license.toUpperCase()}` : 'Creative Commons',
        tags: Array.from(new Set(['openverse', ...tags])),
        selected: false,
        addedAt: now,
      });
    }

    return { items, timedOut: false, warnings: [] };
  } catch (err) {
    const timedOut = err instanceof DOMException && err.name === 'AbortError';
    return {
      items: [],
      timedOut,
      warnings: [
        timedOut
          ? 'Openverse timed out after 5s'
          : err instanceof Error
            ? `Openverse: ${err.message}`
            : 'Openverse search failed',
      ],
    };
  }
}

export async function searchOpenWebAssets(
  query: string,
  categories?: AssetCategory[]
): Promise<OpenWebSearchResult> {
  const cleanQuery = query.trim();
  const catList = categories && categories.length > 0 ? categories : [];

  const want3DOrTextures =
    catList.length === 0 ||
    catList.some((c) =>
      [
        'vehicles',
        'characters',
        'weapons_gear',
        'village_world',
        'textures_pbr',
        'hdri_sky',
      ].includes(c)
    );

  const wantPhotos =
    catList.length === 0 || catList.includes('wikimedia_photos');

  const jobs: Promise<OpenWebSearchResult>[] = [];

  if (want3DOrTextures) {
    jobs.push(searchPolyHavenLive(cleanQuery, catList));
    jobs.push(searchGitHubPublic3DAssets(cleanQuery, catList));
  }
  if (wantPhotos) {
    jobs.push(searchOpenversePhotos(cleanQuery));
  }

  if (jobs.length === 0) {
    return { items: [], timedOut: false, warnings: [] };
  }

  const settled = await Promise.allSettled(jobs);
  const merged: StudioAssetItem[] = [];
  const warnings: string[] = [];
  let timedOut = false;

  for (const outcome of settled) {
    if (outcome.status === 'fulfilled') {
      merged.push(...outcome.value.items);
      warnings.push(...outcome.value.warnings);
      if (outcome.value.timedOut) timedOut = true;
    } else {
      const reason =
        outcome.reason instanceof Error
          ? outcome.reason.message
          : 'Open-web asset query failed';
      warnings.push(reason);
    }
  }

  // Deduplicate by id and url
  const seen = new Set<string>();
  const deduped: StudioAssetItem[] = [];
  for (const item of merged) {
    const key = `${item.id}|${item.url}`;
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(item);
  }

  return {
    items: deduped,
    timedOut,
    warnings,
  };
}
